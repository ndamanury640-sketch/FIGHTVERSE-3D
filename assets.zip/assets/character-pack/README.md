# Fighting Game Assets — 10 Original Characters

This package contains original placeholder-quality 2D arcade fighter sprite assets for prototyping.

## Characters
- **Inferno** (`inferno`): Fire brawler with flame gauntlets.
- **Frostbite** (`frostbite`): Ice swordsman with crystalline blade.
- **Volt** (`volt`): Electric speed fighter with lightning accents.
- **Shadow Reaper** (`shadow-reaper`): Masked shadow ninja with twin daggers.
- **Titan** (`titan`): Massive armored grappler.
- **Cyber-X** (`cyber-x`): Futuristic robot with glowing core.
- **Jade Monk** (`jade-monk`): Martial artist with jade energy.
- **Toxic Fang** (`toxic-fang`): Agile poison fighter with clawed gloves.
- **Storm Ronin** (`storm-ronin`): Wind samurai with katana.
- **Glitch** (`glitch`): Digital trickster with pixel-like accents.

## Included per character
- `sprites/*.png`: horizontal sprite strips with transparent RGBA background.
- `animations/<animation>/frame_XX.png`: individual frames.
- `animations/*.gif`: quick animation previews.
- `effects/special_effects.png`: simple effect sheet.
- `metadata.json`: frame dimensions, counts, and animation names.

## Technical standard
- Frame canvas: 96×96 pixels, RGBA PNG.
- Sprite sheets are horizontal strips: frame N starts at x = N × 96, y = 0.
- Default facing direction: right. For left-facing fighters, flip each frame horizontally.
- Suggested playback: 9 FPS; adjust per game feel.
- GIFs are previews, not necessarily optimized for final production.

## Quick integration
For a sprite sheet, crop frames using `frame_width` and `frame_height` from `metadata.json`.
Example logic: for frame index `i`, crop rectangle `(i*96, 0, (i+1)*96, 96)`.
Use the per-frame PNGs if your engine does not support sprite-sheet slicing.

## Important
These are generated starter sprites for prototyping, not polished hand-drawn commercial art. Review and refine animation timing, collision boxes, and visual consistency before shipping a game.
