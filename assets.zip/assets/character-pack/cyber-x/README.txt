CYBER-X CHARACTER PACK — FIGHTVERSE 3D
======================================

ISI PAKET
- concept/: papan konsep dan referensi desain CYBER-X.
- skills/: lima potongan referensi visual efek serangan.
- ../manifest.json: daftar roster game yang sudah berisi slug cyber-x.
- game/engine.js pada proyek utama sudah dimodifikasi untuk membuat model prosedural CYBER-X lebih khas:
  rambut perak, visor biru, emblem X bercahaya, bilah energi di lengan, dan reactor ring.

PENTING
File PNG di paket ini adalah referensi konsep, BUKAN model 3D GLB/GLTF atau animasi skeletal siap impor.
Karakter yang muncul dalam pertarungan dirender secara prosedural oleh Three.js dari game/engine.js.
Serangan Light/Heavy/Special/Ultimate memakai sistem efek partikel dan slash yang sudah ada; warna CYBER-X sekarang biru neon.

CARA PAKAI
1. Buat backup folder proyek lama.
2. Ekstrak FIGHTVERSE_3D_CYBERX_Updated.zip ke folder baru, atau salin folder assets/character-pack/cyber-x ke proyek lama.
3. Untuk mendapatkan model CYBER-X yang sudah ditingkatkan, salin game/engine.js dari ZIP ke folder game/ proyek lama (timpa file lama setelah backup).
4. Jalankan Apache dan MySQL di XAMPP, lalu buka proyek melalui http://localhost/NAMA_FOLDER/.
5. Login, buka menu Characters/Roster, pilih CYBER-X, lalu mulai pertarungan.

Jika ingin menerapkan hanya pada proyek lama:
- Salin assets/character-pack/cyber-x/ ke lokasi yang sama di proyek.
- Salin game/engine.js yang ada di ZIP ke folder game/ proyek lama.
- Jangan menimpa database/config jika tidak diperlukan.

CATATAN KOMPATIBILITAS
Proyek menggunakan Three.js dari CDN, jadi koneksi internet dibutuhkan untuk memuat modul Three.js.
Performa/WebGL tetap bergantung pada browser dan GPU. Model ini masih procedural, bukan mesh artist-authored atau model GLB eksternal.
