# Animation Reference

| Animation | Frames | Suggested use |
|---|---:|---|
| `idle` | 4 | Idle state |
| `walk_forward` | 6 | Walk forward state |
| `walk_backward` | 6 | Walk backward state |
| `jump` | 5 | Jump state |
| `crouch` | 2 | Crouch state |
| `light_attack` | 4 | Light attack state |
| `heavy_attack` | 6 | Heavy attack state |
| `special_attack` | 6 | Special attack state |
| `hit_reaction` | 3 | Hit reaction state |
| `block` | 3 | Block state |
| `knockdown` | 4 | Knockdown state |
| `victory` | 5 | Victory state |
| `defeat` | 4 | Defeat state |

All frames use a 96×96 canvas and horizontal sprite strips.
