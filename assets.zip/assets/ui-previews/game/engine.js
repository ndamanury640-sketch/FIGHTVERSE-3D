import * as THREE from 'https://cdn.jsdelivr.net/npm/three@0.169.0/build/three.module.js';
import { ROSTER, SLUGS } from './roster.js';
import { Fighter } from './fighter.js';
import { VFX, Trail } from './vfx.js';
import { buildArena as makeArena, arenaName } from './arenas.js';
import { Net } from './net.js';
import { sfx } from '../js/sfx.js';
import { STANCE, MOVES, LIGHT_CHAIN, POSES, GETUP_KEYS, mkPose, clonePose, copyPose, lerpPose, evalKeys, walkPose, TAU } from './rig.js';

const app = document.querySelector('#game-app');
if (!app) throw new Error('FIGHTVERSE 3D root not found');
const $ = s => document.querySelector(s);
const slug = ROSTER[app.dataset.character] ? app.dataset.character : 'inferno', csrf = app.dataset.csrf || '';
const mode = ['training', 'online', 'ranked'].includes(app.dataset.mode) ? app.dataset.mode : 'versus', online = mode === 'online' || mode === 'ranked';
const others = SLUGS.filter(s => s !== slug);
let enemySlug = others[Math.floor(Math.random() * others.length)], arenaId = app.dataset.arena || 'neon-rift', mySide = 0, matchInfo = null;
let renderer, scene, camera, clock, vfx, composer = null, fxPass = null, bloom = null, player, enemy, units = [];
let net = null, netGo = false, netEnded = false, lastSnapAt = 0, lastSnapKey = '', arena = null, envFlash = 0, baseExposure = 1.12, L = {}, clockT = 0, camYaw = 0, camYawT = 0, camKick = 0, camRoll = 0, camT2 = 0;
const touch = { mx: 0, mz: 0, block: false };
let started = false, paused = false, finished = false, elapsed = 0, timeLeft = 99, damageDealt = 0, successfulHits = 0, combo = 0, comboUntil = 0, quality = 'medium';
let hitStop = 0, timeScale = 1, timeScaleTarget = 1, shake = 0, zoomPunch = 0, camMode = 'normal', camFocus = null, camT = 0, exposure = 1.12, koT = -1, koResult = '', messageTimer = 0;
const keys = new Set(), projectiles = [], trailTip = new THREE.Vector3(), trailBase = new THREE.Vector3(), V1 = new THREE.Vector3(), V2 = new THREE.Vector3(), V3 = new THREE.Vector3();
const clamp = (v, a, b) => Math.max(a, Math.min(b, v)), lerp = (a, b, t) => a + (b - a) * t, ease = t => 1 - Math.pow(1 - clamp(t, 0, 1), 3);
const angLerp = (a, b, t) => { let d = ((b - a + Math.PI) % TAU + TAU) % TAU - Math.PI; return a + d * t; };
/* ------------------------------------------------------------------ arena ---- */
function applyEnv(env) {
  scene.background.set(env.bg); scene.fog.color.set(env.fog[0]); scene.fog.density = env.fog[1];
  L.hemi.color.set(env.hemi[0]); L.hemi.groundColor.set(env.hemi[1]); L.hemi.intensity = env.hemi[2]; L.key.color.set(env.key[0]); L.key.intensity = env.key[1];
  L.rim.color.set(env.rim1[0]); L.rim.intensity = env.rim1[1]; L.rim2.color.set(env.rim2[0]); L.rim2.intensity = env.rim2[1]; baseExposure = exposure = env.exposure;
}
function loadArena(id) { arena = makeArena(id, scene, { flash: v => { envFlash = Math.max(envFlash, v); } }); applyEnv(arena.env); }

/* ------------------------------------------------------------------- units ---- */
function makeUnit(sl, isPlayer) {
  const data = ROSTER[sl], f = new Fighter(scene, data, { isPlayer });
  const u = {
    f, data, isPlayer, slug: sl, pos: f.root.position, hp: 100, energy: 30, state: 'free', t: 0, mv: null, moveName: '', hitDone: false, connected: false, fxDone: false, fin: false,
    chain: 0, chainT: 0, queue: null, queueT: 0, kb: new THREE.Vector3(), y: 0, vy: 0, air: false, landT: 0, walk: 0, yaw: isPlayer ? Math.PI / 2 : -Math.PI / 2, viewYaw: 0,
    inp: { mx: 0, mz: 0, block: false }, jumpReq: false, dashReq: false, dashCd: 0, dashT: 0, invuln: 0, stunT: 0, hitType: 'light', blocking: false, dead: false, frozen: false,
    pose: clonePose(STANCE), ult: null, ghostT: 0, last: new THREE.Vector3(), wv: new THREE.Vector3(), ai: { t: 0, mx: 0, mz: 0, block: 0, burst: 0 }, downT: 0, comboCount: 0, winT: 0
  };
  u.trails = {
    handL: new Trail(scene, data.glow, data.glow2, 14, .28), handR: new Trail(scene, data.glow, data.glow2, 14, .28),
    footL: new Trail(scene, data.glow, data.glow2, 14, .28), footR: new Trail(scene, data.glow, data.glow2, 14, .28)
  };
  f.root.position.set(isPlayer ? -2.6 : 2.6, 0, 0); u.last.copy(f.root.position); f.setExpression('focus'); f.snapPose(STANCE);
  return u;
}
const foe = u => u === player ? enemy : player;
const dirTo = (a, b, out) => { out.set(b.pos.x - a.pos.x, 0, b.pos.z - a.pos.z); const l = out.length() || 1; return out.multiplyScalar(1 / l); };
const distXZ = (a, b) => Math.hypot(a.pos.x - b.pos.x, a.pos.z - b.pos.z);
const chestPos = (u, out) => out.set(u.pos.x, u.pos.y + u.y + 1.65, u.pos.z);

/* --------------------------------------------------------------- messages ---- */
function showMessage(txt, t = .8) { const el = $('#round-label'); el.textContent = txt; el.style.opacity = '1'; messageTimer = t; }
function showCombo() { const el = $('#combo-display'); if (combo > 1) { el.innerHTML = `${combo} <small>HIT COMBO</small>`; el.style.opacity = '1'; el.style.transform = `translateX(${Math.random() * 8 - 4}px) skew(-8deg) scale(${1 + Math.min(.5, combo * .04)})`; } else el.textContent = ''; }
function cutin(u) {
  const el = $('#ult-cutin'); if (!el) return;
  el.style.setProperty('--c', '#' + new THREE.Color(u.data.glow).getHexString()); el.querySelector('.cutin-name').textContent = u.data.name; el.querySelector('.cutin-skill').textContent = u.data.ult; el.querySelector('.cutin-title').textContent = u.data.title;
  el.classList.remove('show'); void el.offsetWidth; el.classList.add('show'); clearTimeout(cutin.t); cutin.t = setTimeout(() => el.classList.remove('show'), 1500);
}

/* ------------------------------------------------------------ combat core ---- */
const flashLight = { l: null, life: 0, base: 0 };
function flashAt(pos, color, intensity = 30, dur = .14) { const l = flashLight.l; l.position.copy(pos); l.color.set(color); flashLight.base = intensity; flashLight.life = dur; flashLight.max = dur; }

function impactFX(att, tgt, mv, pos, heavy) {
  camKick = Math.max(camKick, heavy ? .8 : .22);
  const c = att.data.glow, c2 = att.data.glow2, fx = att.data.fx;
  vfx.hitSpark(pos, c, heavy ? 1.55 : 1, c2);
  vfx.burst(pos, { n: heavy ? 34 : 14, color: c2, color2: c, speed: heavy ? 8 : 4.8, size: .11, life: .55 });
  flashAt(pos, c, heavy ? 45 : 22); shake = Math.max(shake, heavy ? .5 : .2); vfx.aberr = Math.max(vfx.aberr, heavy ? .012 : .005);
  if (heavy) { V1.set(tgt.pos.x, 0, tgt.pos.z); vfx.ring(V1, c, { radius: 2.4, dur: .45 }); vfx.flash(c, .16); zoomPunch = Math.max(zoomPunch, .6); }
  if (fx === 'spark') { for (let i = 0; i < 3; i++) { V2.set(pos.x + (Math.random() - .5) * 2.4, pos.y + (Math.random() - .3) * 1.8, pos.z + (Math.random() - .5) * 1.2); vfx.lightning(pos, V2, c2); } }
  if (fx === 'ice') vfx.burst(pos, { n: 18, color: 0xffffff, color2: c, speed: 5, size: .09, grav: 8, life: .8 });
  if (fx === 'flame') vfx.burst(pos, { n: 18, color: 0xffd27a, color2: 0xff3d00, speed: 4, up: 3, size: .16, grav: -2, life: .7 });
  if (fx === 'venom') vfx.burst(pos, { n: 14, color: 0xc8ff2a, color2: 0x2a7a00, speed: 3.5, size: .15, grav: 6, life: .8 });
  if (fx === 'glitch') for (let i = 0; i < 5; i++) vfx.burst(V2.set(pos.x + (Math.random() - .5), pos.y + (Math.random() - .5), pos.z), { n: 3, color: i % 2 ? 0xff4fd8 : 0x68f7ff, speed: 3, size: .22, life: .3, grav: 0 });
  if (fx === 'quake') { V1.set(tgt.pos.x, .05, tgt.pos.z); vfx.debris(V1, 6); }
}

// Apply a hit. returns 'hit' | 'block' | null
function hurt(att, tgt, mv, o = {}) {
  if (tgt.invuln > 0 || tgt.dead || ['down', 'getup', 'ult', 'locked'].includes(tgt.state) && !o.force) return null;
  const dir = dirTo(att, tgt, V3).clone(), heavy = !!(mv.heavyHit || mv.launch), pos = chestPos(tgt, new THREE.Vector3()).addScaledVector(dir, -.35);
  let dmg = o.dmg != null ? o.dmg : mv.dmg;
  if (tgt.remote) { // online: the victim's client is authoritative; we only show feedback and tell it about the hit
    const blocked = tgt.inp.block && tgt.state === 'free' && !tgt.air && !o.unblockable;
    if (net) net.send({ t: 'ev', k: 'hit', dmg, push: mv.push || 2, stun: mv.stun || .25, launch: mv.launch || 0, hv: heavy ? 1 : 0, en: mv.energy || 4, ub: o.unblockable ? 1 : 0, fc: o.force ? 1 : 0 });
    att.connected = true; att.energy = Math.min(100, att.energy + (mv.energy || 4));
    if (blocked) { vfx.burst(pos, { n: 12, color: 0xffffff, color2: tgt.data.glow, speed: 4, size: .09, life: .3 }); vfx.hitSpark(pos, 0x9fe7ff, .7); flashAt(pos, 0x9fe7ff, 14, .1); sfx.block(); showMessage('GUARD', .4); hitStop = Math.max(hitStop, .03); return 'block'; }
    if (att === player) { damageDealt += dmg; successfulHits++; combo++; comboUntil = elapsed + 1.3; showCombo(); }
    tgt.f.hitFlash = 1; tgt.f.setExpression('hurt'); if (!mv.launch && (tgt.state === 'free' || tgt.state === 'attack')) { tgt.state = 'hit'; tgt.t = 0; tgt.stunT = mv.stun || .25; tgt.hitType = heavy ? 'heavy' : 'light'; }
    impactFX(att, tgt, mv, pos, heavy); sfx.hit(heavy); hitStop = Math.max(hitStop, heavy ? .085 : .04); return 'hit';
  }
  if (tgt.inp.block && tgt.state === 'free' && !tgt.air && !o.unblockable) {
    dmg = Math.max(1, Math.round(dmg * .15)); tgt.hp = Math.max(1, tgt.hp - dmg); tgt.energy = Math.max(0, tgt.energy - 7); tgt.kb.addScaledVector(dir, 2.2); tgt.blockFlash = .16;
    vfx.burst(pos, { n: 12, color: 0xffffff, color2: tgt.data.glow, speed: 4, size: .09, life: .3 }); vfx.hitSpark(pos, 0x9fe7ff, .7); flashAt(pos, 0x9fe7ff, 14, .1);
    att.connected = true; sfx.block(); showMessage('GUARD', .4); hitStop = Math.max(hitStop, .03); return 'block';
  }
  tgt.hp = Math.max(0, tgt.hp - dmg); att.connected = true; att.energy = Math.min(100, att.energy + (mv.energy || 4)); tgt.energy = Math.min(100, tgt.energy + 5);
  tgt.f.hitFlash = 1; tgt.f.fxVel.addScaledVector(dir, 4); tgt.f.setExpression('hurt');
  tgt.kb.addScaledVector(dir, mv.push || 2); tgt.mvCancel = true;
  if (att === player) { damageDealt += dmg; successfulHits++; combo++; comboUntil = elapsed + 1.3; showCombo(); } else { combo = 0; $('#combo-display').textContent = ''; }
  tgt.hitType = heavy ? 'heavy' : 'light';
  if (tgt.hp <= 0) { koSequence(att, tgt, dir); }
  else if (mv.launch) { tgt.state = 'knock'; tgt.t = 0; tgt.vy = mv.launch; tgt.air = true; tgt.y = Math.max(tgt.y, .02); }
  else if (tgt.air) { tgt.state = 'knock'; tgt.t = 0; tgt.vy = Math.max(tgt.vy, 3); }
  else { tgt.state = 'hit'; tgt.t = 0; tgt.stunT = mv.stun || .25; }
  impactFX(att, tgt, mv, pos, heavy); sfx.hit(heavy);
  hitStop = Math.max(hitStop, heavy ? .085 : .04);
  return 'hit';
}

function koSequence(att, tgt, dir) {
  if (mode === 'training' && tgt === enemy) { tgt.hp = 100; return; }
  tgt.dead = true; tgt.state = 'knock'; tgt.t = 0; tgt.vy = 6.5; tgt.air = true; tgt.y = .02; tgt.kb.addScaledVector(dir, 7);
  sfx.ko(); koT = 0; koResult = tgt === enemy ? 'win' : 'loss'; timeScaleTarget = .22; timeScale = .22; showMessage('K.O.!', 2.2);
  vfx.flash(0xffffff, .8); camMode = 'ko'; camFocus = tgt; shake = 1.1; vfx.aberr = .03;
  att.f.setExpression('win'); att.winPending = true;
}

function canAct(u) { return u.state === 'free' && !u.air; }
function pickMove(u, type) { return type === 'light' ? LIGHT_CHAIN[u.chainT > 0 && u.lastTier === 'light' ? (u.chain + 1) % 3 : 0] : type === 'heavy' ? u.data.heavy : u.data.special; }
const TIER = { light: 0, heavy: 1, special: 2 };
function requestAttack(u, type) {
  if (!started || paused || finished || u.dead) return;
  u.queue = type; u.queueT = .28;
}
function tryQueue(u) {
  if (!u.queue) return;
  const type = u.queue;
  if (type === 'ultimate') { if (foe(u).state === 'ult' || foe(u).state === 'locked') { u.queue = null; return; } if (!(canAct(u) || (u.state === 'attack' && u.connected))) return; if (u.energy < 65) { if (u.isPlayer) showMessage('ENERGY TOO LOW', .7); u.queue = null; return; } u.queue = null; startUlt(u); return; }
  let ok = canAct(u);
  if (!ok && u.state === 'attack' && u.mv) {
    const curTier = TIER[u.mv.tier];
    if (u.connected && u.t >= u.mv.cancel && (TIER[type] > curTier || (type === 'light' && curTier === 0 && u.chain < 2))) ok = true;
    else if (u.t >= u.mv.dur * .9) ok = true;
  }
  if (!ok) return;
  if (type === 'special') { if (u.energy < 15) { if (u.isPlayer) showMessage('ENERGY TOO LOW', .7); u.queue = null; return; } u.energy -= 15; }
  u.queue = null; startMove(u, type);
}
function startMove(u, type) {
  const o = foe(u), name = pickMove(u, type);
  if (type === 'light') u.chain = (u.chainT > 0 && u.lastTier === 'light') ? (u.chain + 1) % 3 : 0;
  u.lastTier = type; u.chainT = .7; u.moveName = name; u.mv = MOVES[name]; u.state = 'attack'; u.t = 0; u.hitDone = false; u.connected = false; u.fxDone = false; u.fin = false; u.released = false; u.f.normalizeSpin();
  u.f.setExpression('attack'); u.f.fxVel.z += 2.5; sfx.swing(); if (u.moveName === 'dash') { sfx.dash(); camKick = Math.max(camKick, .5); }
  if (name === 'wave' || name === 'slam') vfx.burst(chestPos(u, V1), { n: 20, color: u.data.glow2, color2: u.data.glow, speed: 2, size: .1, life: .4 });
  if (name === 'dash') { vfx.speedLines(true); setTimeout(() => vfx.speedLines(false), 330); }
}

function spawnSlash(u, mv) {
  const s = mv.slash; if (!s) return; sfx.slash(); const d = dirTo(u, foe(u), V1).clone(), p = chestPos(u, V2).clone().addScaledVector(d, .35);
  if (mv.hand === 'footR') p.y = u.pos.y + u.y + 1.15;
  vfx.slash(p, d, { color: u.data.glow, color2: u.data.glow2, scale: s.scale * 1.25, roll: s.roll, flip: s.flip, arc: s.arc, horizontal: s.horizontal, dur: .32 });
  if (s.scale > 1.6) vfx.slash(p, d, { color: u.data.glow2, color2: 0xffffff, scale: s.scale * .95, roll: s.roll + .12, flip: s.flip, arc: s.arc * .85, horizontal: s.horizontal, dur: .26, thick: .3 });
}
function spawnProjectile(u, o) {
  const d = dirTo(u, o, new THREE.Vector3()), p = chestPos(u, new THREE.Vector3()).addScaledVector(d, 1.0);
  sfx.proj(); const vis = vfx.projectile(u.data.proj, u.data.glow, u.data.glow2, d); vis.group.position.copy(p); scene.add(vis.group);
  projectiles.push({ owner: u, pos: p, dir: d, vis, life: 1.15, t: 0, speed: 11.5 });
  vfx.ring3(p, u.data.glow, { n: 18, speed: 3, life: .4 }); flashAt(p, u.data.glow, 30, .2); shake = Math.max(shake, .25); u.f.fxVel.z -= 5;
}
function updateProjectiles(dt) {
  for (let i = projectiles.length - 1; i >= 0; i--) {
    const pr = projectiles[i]; pr.t += dt; pr.life -= dt; pr.pos.addScaledVector(pr.dir, pr.speed * dt); pr.vis.group.position.copy(pr.pos); pr.vis.tick(dt, pr.t);
    vfx.burst(pr.pos, { n: 3, color: pr.owner.data.glow2, color2: pr.owner.data.glow, speed: .8, size: .2, life: .35, grav: 0, dir: V1.copy(pr.dir).multiplyScalar(-1), cone: .6 });
    const t = foe(pr.owner); let hit = false;
    if (!pr.owner.remote && Math.hypot(t.pos.x - pr.pos.x, t.pos.z - pr.pos.z) < .95 && Math.abs(t.y + 1.2 - pr.pos.y) < 1.6 && !t.dead) {
      const r = hurt(pr.owner, t, { dmg: 15, push: 5, stun: .45, heavyHit: true, energy: 8 }); if (r) hit = true; else if (t.invuln > 0) hit = false;
    }
    if (hit || pr.life <= 0 || Math.abs(pr.pos.x) > 8.5) {
      if (hit) { vfx.ring(V1.set(pr.pos.x, 0, pr.pos.z), pr.owner.data.glow, { radius: 2 }); }
      scene.remove(pr.vis.group); pr.vis.dispose(); projectiles.splice(i, 1);
    }
  }
}

/* ----------------------------------------------------------------- ultimate ---- */
function startUlt(u) {
  const o = foe(u); if (online && !u.remote && net) net.send({ t: 'ev', k: 'ult' }); u.energy -= 65; u.state = 'ult'; u.t = 0; u.invuln = 99; u.ult = { phase: 'charge', t: 0, hits: 0, next: 0, start: new THREE.Vector3(), end: new THREE.Vector3(), gt: 0 };
  sfx.ult(); sfx.charge(); o.frozen = true; camMode = 'ult'; camFocus = u; camT = 0; cutin(u); showMessage(u.data.ult, 1.4);
  vfx.flash(u.data.glow, .6); exposure = .8; vfx.pillar(u.pos, u.data.glow, { h: 9, r: 1.1, dur: 1.2 }); vfx.ring(u.pos, u.data.glow, { radius: 4, dur: .8 }); u.f.setExpression('attack'); u.f.glowBoost = 3.2; vfx.aberr = .02;
}
function updateUlt(u, dt) {
  const U = u.ult, o = foe(u), d = dirTo(u, o, new THREE.Vector3()); U.t += dt;
  if (U.phase === 'charge') {
    const p = U.t < .45 ? POSES.ultCharge : POSES.ultRise; u.pose = p; u.poseRate = 14; u.y = U.t > .45 ? Math.min(.5, (U.t - .45) * 1.4) : 0;
    chestPos(u, V1); for (let i = 0; i < 3; i++) { const a = Math.random() * TAU, r = 2 + Math.random() * 1.5; V2.set(V1.x + Math.cos(a) * r, V1.y - 1 + Math.random() * 2.2, V1.z + Math.sin(a) * r); V3.copy(V1).sub(V2).multiplyScalar(2.2); vfx.particles.emit(V2, V3, new THREE.Color(u.data.glow2), new THREE.Color(u.data.glow), .55, .16, .03, 0, 0); }
    shake = Math.max(shake, .12 + U.t * .15);
    if (U.t >= 1.0) {
      U.phase = 'dash'; U.t = 0; U.start.copy(u.pos); U.end.set(o.pos.x - d.x * 1.5, 0, o.pos.z - d.z * 1.5); u.y = 0; o.frozen = false; o.state = 'locked'; o.t = 0; o.kb.set(0, 0, 0); o.queue = null; o.inp.block = false; o.air = true; camMode = 'ultStrike'; exposure = 1.25;
      vfx.flash(0xffffff, .8); vfx.speedLines(true); vfx.ring(u.pos, u.data.glow, { radius: 3.2, dur: .4 }); vfx.burst(chestPos(u, V1), { n: 60, color: u.data.glow2, color2: u.data.glow, speed: 9, size: .16, life: .6 }); u.f.fxVel.z += 6;
    }
  } else if (U.phase === 'dash') {
    u.pose = POSES.dashRun; u.poseRate = 30; U.gt -= dt; if (U.gt <= 0) { vfx.ghost(u.f, u.data.glow, .6, .3); U.gt = .03; }
    const k = ease(U.t / .2); u.pos.x = lerp(U.start.x, U.end.x, k); u.pos.z = lerp(U.start.z, U.end.z, k);
    if (U.t >= .2) { U.phase = 'barrage'; U.t = 0; U.next = 0; o.state = 'locked'; o.t = 0; o.kb.set(0, 0, 0); o.vy = 0; o.air = true; vfx.speedLines(false); }
  } else if (U.phase === 'barrage') {
    o.y = lerp(o.y, 1.15 + Math.sin(elapsed * 30) * .06, .3); o.pos.x += (U.end.x + d.x * 1.5 - o.pos.x) * .1;
    u.pose = U.hits % 2 ? POSES.ultSlashB : POSES.ultSlashA; u.poseRate = 50; U.next -= dt;
    if (U.next <= 0 && U.hits < 5) {
      U.hits++; U.next = .13; const p = chestPos(o, new THREE.Vector3());
      const roll = (U.hits % 2 ? 1 : -1) * (.5 + Math.random() * .8);
      vfx.slash(p.clone().addScaledVector(d, -.6), d, { color: u.data.glow, color2: u.data.glow2, scale: 2.1, roll, flip: U.hits % 2 ? 1 : -1, arc: 2.6, dur: .26 });
      vfx.hitSpark(p, u.data.glow, 1.2, u.data.glow2); vfx.burst(p, { n: 16, color: u.data.glow2, color2: u.data.glow, speed: 7, size: .12 }); flashAt(p, u.data.glow, 40, .1);
      o.hp = Math.max(0, o.hp - 4); o.f.hitFlash = 1; o.f.setExpression('hurt'); shake = .45; hitStop = .03; vfx.aberr = .015; u.f.fxVel.z += 3;
      if (u === player) { combo += 1; comboUntil = elapsed + 1.5; damageDealt += 4; successfulHits++; showCombo(); }
      if (U.hits === 5) { U.phase = 'finish'; U.t = 0; }
    }
  } else if (U.phase === 'finish') {
    o.y = lerp(o.y, 1.7, .15); u.pose = POSES.ultFinish; u.poseRate = 22; u.y = Math.min(.9, U.t * 3);
    if (U.t >= .38 && !U.fin) {
      U.fin = true; const p = chestPos(o, new THREE.Vector3());
      vfx.slash(p.clone().addScaledVector(d, -.4), d, { color: u.data.glow2, color2: 0xffffff, scale: 3.4, roll: -1.1, flip: -1, arc: 3, dur: .45 }); vfx.slash(p, d, { color: u.data.glow, color2: u.data.glow2, scale: 2.8, roll: 1.1, flip: 1, arc: 3, dur: .4 });
      V1.set(o.pos.x, 0, o.pos.z); vfx.ring(V1, u.data.glow, { radius: 6, dur: .7 }); vfx.ring(V1, 0xffffff, { radius: 4, dur: .5 }); vfx.cracks(V1, u.data.glow, 12, 4); vfx.debris(V1, 22);
      vfx.hitSpark(p, 0xffffff, 3, u.data.glow); vfx.burst(p, { n: 120, color: 0xffffff, color2: u.data.glow, speed: 14, size: .2, life: .9 });
      vfx.flash(0xffffff, .95); shake = 1.2; vfx.aberr = .04; hitStop = .12; timeScaleTarget = .3; setTimeout(() => { if (!finished) timeScaleTarget = 1; }, 450); zoomPunch = 1;
      o.hp = Math.max(0, o.hp - 10); o.f.hitFlash = 1; o.invuln = 0; o.state = 'knock'; o.t = 0; o.vy = 3.5; o.air = true; o.kb.copy(d).multiplyScalar(11); o.hitType = 'heavy';
      if (u === player) { damageDealt += 10; successfulHits++; combo++; comboUntil = elapsed + 1.5; showCombo(); }
      if (o.hp <= 0) { o.hp = 0.0001; koSequence(u, o, d); o.hp = 0; }
    }
    if (U.t >= .9) { U.phase = 'recover'; U.t = 0; vfx.speedLines(false); }
  } else if (U.phase === 'recover') {
    u.pose = STANCE; u.poseRate = 10; u.y = Math.max(0, u.y - dt * 4); u.f.glowBoost = lerp(u.f.glowBoost, 1, .1);
    if (U.t >= .5) { u.state = 'free'; u.ult = null; u.invuln = .2; u.f.glowBoost = 1; u.y = 0; camMode = o.dead ? 'ko' : 'normal'; exposure = baseExposure; u.f.setExpression('normal'); u.f.normalizeSpin(); }
  }
}

/* ----------------------------------------------------------- unit updating ---- */
const tmp = mkPose(), tmp2 = mkPose();
function trailsFor(u) {
  const act = new Set(); if (u.state === 'attack' && u.mv) {
    const mv = u.mv, a0 = mv.act ? mv.act[0] - .1 : 0, a1 = mv.act ? mv.act[1] + .1 : mv.dur;
    if (u.t >= a0 && u.t <= a1 + .12) { act.add(mv.hand === 'footR' ? 'footR' : 'hand' + (mv.hand || 'R')); if (mv.tier !== 'light') { act.add('handL'); act.add('handR'); } if (mv.hand === 'footR' && mv.id !== 'x') { /* leg only */ } }
    if (u.data.gear.includes('twinBlades') || u.data.gear.includes('daggers')) { act.add('handL'); act.add('handR'); }
    if (u.moveName === 'spin') { act.add('footR'); act.add('footL'); }
  }
  if (u.state === 'dash' || (u.state === 'ult' && u.ult && ['dash', 'barrage', 'finish'].includes(u.ult.phase))) { act.add('handL'); act.add('handR'); act.add('footL'); act.add('footR'); }
  return act;
}

function updateUnit(u, o, dt) {
  const f = u.f, mv = u.mv; u.t += dt; u.chainT = Math.max(0, u.chainT - dt); u.queueT -= dt; if (u.queueT <= 0) u.queue = null; u.invuln = Math.max(0, u.invuln - dt); u.dashCd = Math.max(0, u.dashCd - dt); u.blockFlash = Math.max(0, (u.blockFlash || 0) - dt);
  const toward = dirTo(u, o, new THREE.Vector3()); let vx = 0, vz = 0, moveAmt = 0, rate = 16;
  if (u.remote) { u.inp.mx = clamp(u.wv.x / 3.7, -1, 1); u.inp.mz = clamp(u.wv.z / 3.7, -1, 1); u.vy = u.wv.y; u.jumpReq = u.dashReq = false; }
  u.poseRate = 0; let pose = STANCE; let speedMul = 1;
  switch (u.state) {
    case 'free': {
      const inp = u.inp; u.blocking = inp.block && !u.air; if (u.blocking) f.setExpression('focus'); else if (f.expr.name === 'attack' || f.expr.name === 'hurt') f.setExpression('focus');
      let mx = inp.mx, mz = inp.mz; const l = Math.hypot(mx, mz); if (l > 1) { mx /= l; mz /= l; }
      speedMul = u.blocking ? .35 : u.air ? .8 : 1; vx = mx * 3.7 * speedMul; vz = mz * 3.7 * speedMul; moveAmt = Math.min(1, l);
      if (u.jumpReq && !u.air) { sfx.jump(); u.vy = 7.4; u.air = true; vfx.burst(V1.set(u.pos.x, .05, u.pos.z), { n: 8, color: 0x9fd8ff, speed: 2.5, size: .12, life: .4, grav: 0 }); f.fxVel.y += 3; }
      u.jumpReq = false;
      if (u.dashReq && u.dashCd <= 0 && !u.air) {
        let dx = mx, dz = mz; if (!l) { dx = -toward.x; dz = -toward.z; } else { dx /= l; dz /= l; }
        sfx.dash(); u.state = 'dash'; u.t = 0; u.dashDir = new THREE.Vector3(dx, 0, dz); u.dashCd = .65; u.invuln = .16; u.ghostT = 0; vfx.ring(V1.set(u.pos.x, .05, u.pos.z), u.data.glow, { radius: 1.6, dur: .3 }); vfx.burst(V1, { n: 14, color: u.data.glow2, color2: u.data.glow, speed: 3, size: .1, life: .4, grav: 0 });
      }
      u.dashReq = false; tryQueue(u);
      if (u.air) { pose = u.vy > 0 ? POSES.airUp : POSES.airDown; rate = 12; }
      else if (u.blocking) { pose = POSES.block; rate = 20; }
      else { u.walk += dt * (moveAmt > .01 ? 9.5 * Math.sign(mx * toward.x + mz * toward.z || 1) : 0); pose = walkPose(tmp, u.walk, moveAmt); rate = 14; const br = Math.sin(elapsed * 2.6 + u.t * 0) * .02 * (1 - moveAmt); copyPoseInto(tmp2, pose); tmp2.chest[0] += br; tmp2.spine[0] += br * .6; tmp2.uaL[0] += br; tmp2.uaR[0] -= br; tmp2.body[1] += br * .6; pose = tmp2; }
      if (u.landT > 0) { u.landT -= dt; copyPoseInto(tmp2, pose); const k = u.landT / .16; tmp2.body[1] -= .16 * k; tmp2.knL[0] += .5 * k; tmp2.knR[0] += .5 * k; tmp2.thL[0] -= .3 * k; tmp2.chest[0] += .2 * k; pose = tmp2; }
      break;
    }
    case 'dash': {
      const k = 1 - u.t / .22; if (u.dashDir && !u.remote) { vx = u.dashDir.x * 14 * Math.max(.25, k); vz = u.dashDir.z * 14 * Math.max(.25, k); } pose = POSES.dashRun; rate = 30;
      u.ghostT -= dt; if (u.ghostT <= 0) { vfx.ghost(f, u.data.glow, .45, .28); u.ghostT = .04; }
      vfx.burst(V1.set(u.pos.x, .1, u.pos.z), { n: 1, color: u.data.glow2, speed: 1, size: .12, life: .3, grav: 0 });
      if (u.t >= .22) { u.state = 'free'; u.t = 0; }
      break;
    }
    case 'attack': {
      pose = evalKeys(mv.keys, u.t, tmp); rate = 45;
      if (mv.lunge && u.t >= mv.lunge[0] && u.t <= mv.lunge[1]) { vx = toward.x * mv.lunge[2]; vz = toward.z * mv.lunge[2]; }
      if (mv.dashMove && u.t >= mv.dashMove[0] && u.t <= mv.dashMove[1]) { vx = toward.x * mv.dashMove[2]; vz = toward.z * mv.dashMove[2]; u.ghostT -= dt; if (u.ghostT <= 0) { vfx.ghost(f, u.data.glow, .5, .3); u.ghostT = .035; } }
      if (mv.act && !u.fxDone && u.t >= mv.act[0] - .02) { u.fxDone = true; if (mv.slash) spawnSlash(u, mv); if (mv.heavyHit && mv.tier === 'heavy') { shake = Math.max(shake, .15); } }
      if (mv.release && !u.released && u.t >= mv.release) { u.released = true; spawnProjectile(u, o); }
      if (mv.act && u.t >= mv.act[0] && u.t <= mv.act[1] + .02 && !u.hitDone && mv.range > 0 && !mv.release && !u.remote) {
        if (mv.aoe) { u.hitDone = true; V1.set(u.pos.x, 0, u.pos.z); vfx.ring(V1, u.data.glow, { radius: 5, dur: .6 }); vfx.ring(V1, 0xffffff, { radius: 3, dur: .4 }); vfx.cracks(V1, u.data.glow, 10, 3.4); vfx.debris(V1, 18); shake = 1; vfx.flash(u.data.glow, .25); hitStop = .08; zoomPunch = .8; if (distXZ(u, o) < mv.range && !o.air) hurt(u, o, mv); }
        else { const d = distXZ(u, o); if (d < mv.range && Math.abs(u.y - o.y) < 1.5) { const r = hurt(u, o, mv); u.hitDone = true; } }
        if (u.moveName === 'dash' && u.hitDone) u.dashHit = true;
      }
      if (u.moveName === 'dash' && u.t >= .4 && u.connected && !u.fin) { u.fin = true; const fm = MOVES.dash.finisher; if (o.state !== 'down') { const p = chestPos(o, new THREE.Vector3()); vfx.slash(p, toward, { color: u.data.glow2, color2: 0xffffff, scale: 2.8, roll: .9, flip: -1, arc: 2.8, dur: .38 }); hurt(u, o, { dmg: fm.dmg, push: fm.push, launch: fm.launch, heavyHit: true, stun: .5, energy: 6 }, { force: true }); } }
      if (u.mvCancel) u.mvCancel = false;
      if (u.t >= mv.dur) { u.state = 'free'; u.t = 0; u.mv = null; u.f.normalizeSpin(); f.setExpression('focus'); tryQueue(u); }
      break;
    }
    case 'hit': {
      pose = u.hitType === 'heavy' ? POSES.hitHeavy : POSES.hitLight; rate = 28; if (u.t > u.stunT * .5) { lerpPose(tmp, pose, STANCE, clamp((u.t - u.stunT * .5) / (u.stunT * .5), 0, 1)); pose = tmp; }
      u.queue = null; if (u.t >= u.stunT) { u.state = 'free'; u.t = 0; f.setExpression('focus'); }
      break;
    }
    case 'knock': {
      pose = u.t < .0 ? STANCE : POSES.knockAir; rate = 16; if (!u.air) { u.state = 'down'; u.t = 0; u.downT = u.dead ? 99 : .65; }
      break;
    }
    case 'locked': pose = POSES.knockAir; rate = 20; break;
    case 'down': {
      pose = POSES.down; rate = 22; f.setExpression(u.dead ? 'ko' : 'hurt'); u.invuln = Math.max(u.invuln, .05);
      if (!u.dead && u.t >= u.downT) { u.state = 'getup'; u.t = 0; f.setExpression('focus'); }
      break;
    }
    case 'getup': { pose = evalKeys(GETUP_KEYS, u.t, tmp); rate = 30; u.invuln = Math.max(u.invuln, .05); if (u.t >= .8) { u.state = 'free'; u.t = 0; u.invuln = .3; } break; }
    case 'win': { copyPoseInto(tmp, POSES.victory); const s = Math.sin(elapsed * 3); tmp.uaR[0] += s * .15; tmp.uaR[2] += s * .08; tmp.body[1] += Math.abs(s) * .03; pose = tmp; rate = 10; f.setExpression('win'); break; }
    case 'ult': updateUlt(u, dt); pose = u.pose || STANCE; rate = u.poseRate || 16; break;
  }
  if (u.state !== 'free') { u.jumpReq = false; u.dashReq = false; }
  // ----- physics -------------------------------------------------------------------------------------------
  if (u.state !== 'ult' && u.state !== 'locked' && !u.remote) {
    u.pos.x += (vx + u.kb.x) * dt; u.pos.z += (vz + u.kb.z) * dt; u.kb.multiplyScalar(Math.exp(-dt * (u.air ? 1.4 : 7)));
    if (u.air || u.y > 0) {
      u.y += u.vy * dt; u.vy -= (u.state === 'knock' ? 17 : 19) * dt;
      if (u.y <= 0) { u.y = 0; if (u.vy < -5 || u.state === 'knock') { V1.set(u.pos.x, .05, u.pos.z); vfx.ring(V1, 0x9fb8d8, { radius: 1.6, dur: .35 }); vfx.burst(V1, { n: 10, color: 0xb8c8e0, speed: 2.4, size: .16, life: .5, grav: -.5 }); if (u.state === 'knock') { shake = Math.max(shake, .35); vfx.debris(V1, 5); } u.landT = .16; } u.air = false; u.vy = 0; }
    }
  }
  if (u.remote && u.state !== 'ult' && u.state !== 'locked' && u.netT) { const k = 1 - Math.exp(-dt * 14); u.pos.x += (u.netT.x - u.pos.x) * k; u.pos.z += (u.netT.z - u.pos.z) * k; u.y += (u.netT.y - u.y) * k; }
  u.pos.x = clamp(u.pos.x, -6.2, 6.2); u.pos.z = clamp(u.pos.z, -3.8, 2.8);
  if (!u.remote && !o.frozen && u.state !== 'ult' && o.state !== 'ult' && o.state !== 'locked' && u.state !== 'locked') { const dd = distXZ(u, o); if (dd < .85 && dd > .001 && !u.air && !o.air) { const k = (.85 - dd) * .5; u.pos.x -= toward.x * k; u.pos.z -= toward.z * k; } }
  // ----- orientation -----------------------------------------------------------------------------------------
  if (u.state !== 'ult' || (u.ult && u.ult.phase !== 'barrage')) { const want = Math.atan2(toward.x, toward.z); u.yaw = angLerp(u.yaw, want, 1 - Math.exp(-dt * 18)); }
  else u.yaw = angLerp(u.yaw, Math.atan2(toward.x, toward.z), 1 - Math.exp(-dt * 30));
  f.root.rotation.y = u.yaw; f.root.position.y = u.y; f.shadow.position.y = .015 - u.y; f.shadow.scale.setScalar(1.15 / (1 + u.y * .4)); f.shadow.material.opacity = .55 / (1 + u.y * .6);
  f.viewYaw = angLerp(f.viewYaw, clamp(angDiff(u.yaw, camYaw), -.65, .65) * .72, 1 - Math.exp(-dt * 6));
  // ----- animation ---------------------------------------------------------------------------------------------
  if (pose !== STANCE || true) f.trackPose(pose, dt, rate);
  u.wv.set((u.pos.x - u.last.x) / Math.max(dt, 1e-4), (u.y - (u.lastY || 0)) / Math.max(dt, 1e-4), (u.pos.z - u.last.z) / Math.max(dt, 1e-4)); u.last.copy(u.pos); u.lastY = u.y;
  const th = u.yaw + f.viewYaw, lv = V1.set(u.wv.x * Math.cos(th) - u.wv.z * Math.sin(th), u.wv.y, u.wv.x * Math.sin(th) + u.wv.z * Math.cos(th)).clone();
  f.update(dt, lv);
  // ----- ambient & trails -----------------------------------------------------------------------------------------
  ambient(u, dt); const act = trailsFor(u); f.root.updateMatrixWorld(true);
  for (const n in u.trails) { const t = u.trails[n]; t.setActive(act.has(n)); if (act.has(n)) f.trailWorld(n, trailTip, trailBase); t.update(dt, act.has(n) ? trailTip : null, trailBase); }
}
function copyPoseInto(d, s) { return copyPose(d, s); }

function ambient(u, dt) {
  const f = u.f, rate = (u.state === 'ult' ? 80 : u.state === 'attack' ? 40 : 14) * dt; if (Math.random() > rate && rate < 1) return;
  const n = rate >= 1 ? Math.floor(rate) : 1; const c = new THREE.Color(u.data.glow), c2 = new THREE.Color(u.data.glow2), fx = u.data.fx;
  for (let i = 0; i < n; i++) {
    V1.set(u.pos.x + (Math.random() - .5) * .9, u.pos.y + u.y + .15 + Math.random() * 2.3, u.pos.z + (Math.random() - .5) * .9);
    let vel = V2.set((Math.random() - .5) * .4, .8 + Math.random() * .8, (Math.random() - .5) * .4), life = .9 + Math.random() * .6, size = .06 + Math.random() * .07, grav = -.3;
    if (fx === 'ice') { vel.y = -.5; grav = .3; size *= 1.1; V1.y += 1; } else if (fx === 'quake') { vel.y *= .5; } else if (fx === 'storm') { vel.x = (Math.random() - .5) * 3; vel.y *= .4; } else if (fx === 'glitch') { vel.set((Math.random() - .5) * 2, (Math.random() - .5) * 1.5, (Math.random() - .5) * 2); size *= 1.5; life *= .5; } else if (fx === 'flame') { vel.y += .8; }
    vfx.particles.emit(V1, vel, c2, c, life, size, .01, grav, .3);
  }
  if (fx === 'spark' && Math.random() < dt * 2.2) { V1.set(u.pos.x + (Math.random() - .5) * 1.4, u.pos.y + u.y + .4 + Math.random() * 2, u.pos.z + (Math.random() - .5) * .8); V2.copy(V1).add(V3.set((Math.random() - .5) * .9, (Math.random() - .5) * .9, (Math.random() - .5) * .5)); vfx.lightning(V1, V2, u.data.glow2, { n: 4, jit: .15, dur: .1 }); }
}

/* -------------------------------------------------------------------- AI ---- */
function aiUpdate(u, o, dt) {
  const ai = u.ai; ai.t -= dt; const d = distXZ(u, o), toward = dirTo(u, o, new THREE.Vector3());
  if (u.state !== 'free' && u.state !== 'attack') { u.inp.mx = u.inp.mz = 0; u.inp.block = false; return; }
  if (ai.t <= 0) {
    ai.t = .16 + Math.random() * .3; u.inp.block = false; ai.mx = ai.mz = 0;
    const r = Math.random();
    if (o.state === 'attack' && d < 3 && r < .5 && canAct(u)) { u.inp.block = true; ai.t = .3 + Math.random() * .3; }
    else if (d > 2.25) { ai.mx = toward.x; ai.mz = toward.z * .9; if (d > 5.5 && r < .25) u.dashReq = true; else if (r > .96) u.jumpReq = true; }
    else if (canAct(u)) {
      if (u.energy >= 65 && r < .35) requestAttack(u, 'ultimate');
      else if (r < .42) { requestAttack(u, 'light'); ai.burst = 1 + Math.floor(Math.random() * 2); }
      else if (r < .62) requestAttack(u, 'heavy');
      else if (r < .76 && u.energy >= 15) requestAttack(u, 'special');
      else if (r < .88) { ai.mx = -toward.x * .8; ai.mz = (Math.random() - .5); ai.t = .3; }
      else if (r < .93) u.dashReq = true;
    }
  }
  if (u.state === 'attack' && ai.burst > 0 && u.connected && u.t >= u.mv.cancel - .02 && !u.queue) { requestAttack(u, 'light'); ai.burst--; }
  if (u.state === 'free') { u.inp.mx = ai.mx; u.inp.mz = ai.mz; }
}

/* ------------------------------------------------------------------ camera ---- */
const angDiff = (a, b) => ((b - a + Math.PI) % TAU + TAU) % TAU - Math.PI;
function updateCamera(dt, raw) {
  const a = player.pos, b = enemy.pos, mx = (a.x + b.x) / 2, mz = (a.z + b.z) / 2, spread = Math.hypot(a.x - b.x, a.z - b.z); camT2 += raw;
  const dirx = (b.x - a.x) >= 0 ? 1 : -1; camKick = Math.max(0, camKick - raw * 1.5);
  // over-the-shoulder 3/4 view: slow sway + swing whenever something big happens
  const yawT = -.5 * dirx + Math.sin(camT2 * .33) * .14 - dirx * camKick * .5;
  let R = 9.4 + spread * .52 - zoomPunch * 1.5, h = 2.6 + spread * .12 + Math.sin(camT2 * .27) * .24 + camKick * .5, ly = 1.45, fovT = 40 - zoomPunch * 3.5 + camKick * 2, rate = 3.4;
  const asp = camera.aspect; if (asp < 1.5) R *= 1 + (1.5 - asp) * .5;
  let px = mx + Math.sin(yawT) * R, pz = mz + Math.cos(yawT) * R, py = h, lx = mx * .9, lz = mz * .9;
  if ((camMode === 'ult' || camMode === 'ultStrike' || camMode === 'ko') && camFocus) {
    const u = camFocus, o = foe(u), side = o.pos.x > u.pos.x ? 1 : -1; camT += raw;
    if (camMode === 'ult') { const ang = camT * .9; px = u.pos.x + Math.sin(ang) * 3.2 * side + side * 1.2; py = 1.7 + camT * .25; pz = u.pos.z + Math.cos(ang) * 3.6 + 1; lx = u.pos.x; ly = 1.9 + u.y; lz = u.pos.z; rate = 7; fovT = 34; }
    else if (camMode === 'ultStrike') { const ang = -.9 * side + Math.sin(camT * 3) * .15; px = (u.pos.x + o.pos.x) / 2 + Math.sin(ang) * 5.6; py = 2 + Math.sin(camT * 2) * .4; pz = (u.pos.z + o.pos.z) / 2 + Math.cos(ang) * 5.6 - zoomPunch * 1.2; lx = (u.pos.x + o.pos.x) / 2; ly = 1.7; lz = (u.pos.z + o.pos.z) / 2; rate = 9; fovT = 46; }
    else { px = u.pos.x * .8 + Math.sin(camT * .5) * 2; py = 2.1; pz = u.pos.z + 5.6; lx = u.pos.x; ly = 1.1; lz = u.pos.z; rate = 3.5; fovT = 34; }
  }
  V1.set(px, py, pz); camera.position.lerp(V1, 1 - Math.exp(-raw * rate)); camLook.lerp(V2.set(lx, ly, lz), 1 - Math.exp(-raw * rate * 1.2));
  camYaw = Math.atan2(camera.position.x - camLook.x, camera.position.z - camLook.z);
  const s = shake; shake = Math.max(0, shake - raw * 2.4); zoomPunch = Math.max(0, zoomPunch - raw * 2.2);
  camera.fov += (fovT - camera.fov) * Math.min(1, raw * 4); camera.updateProjectionMatrix(); camera.lookAt(camLook);
  camRoll += ((-dirx * camKick * .045 + Math.sin(camT2 * .4) * .012) - camRoll) * Math.min(1, raw * 4); camera.rotation.z += camRoll;
  if (s > 0) { camera.position.x += (Math.random() - .5) * s * .35; camera.position.y += (Math.random() - .5) * s * .25; camera.rotation.z += (Math.random() - .5) * s * .02; }
}
const camLook = new THREE.Vector3(0, 1.4, 0);

/* ---------------------------------------------------------------- lifecycle ---- */
async function setupPost() {
  try {
    const [A, B, C, S, O] = await Promise.all([import('three/addons/postprocessing/EffectComposer.js'), import('three/addons/postprocessing/RenderPass.js'), import('three/addons/postprocessing/UnrealBloomPass.js'), import('three/addons/postprocessing/ShaderPass.js'), import('three/addons/postprocessing/OutputPass.js')]);
    const m = $('#three-stage'), w = Math.max(1, m.clientWidth), h = Math.max(1, m.clientHeight);
    const c = new A.EffectComposer(renderer); c.addPass(new B.RenderPass(scene, camera));
    bloom = new C.UnrealBloomPass(new THREE.Vector2(w, h), .75, .55, .92); c.addPass(bloom);
    fxPass = new S.ShaderPass({ uniforms: { tDiffuse: { value: null }, uAb: { value: 0 }, uVig: { value: .32 } }, vertexShader: 'varying vec2 vUv; void main(){ vUv=uv; gl_Position=projectionMatrix*modelViewMatrix*vec4(position,1.0); }',
      fragmentShader: 'uniform sampler2D tDiffuse; uniform float uAb; uniform float uVig; varying vec2 vUv; void main(){ vec2 d=(vUv-0.5)*uAb; vec4 c=vec4(texture2D(tDiffuse,vUv+d).r,texture2D(tDiffuse,vUv).g,texture2D(tDiffuse,vUv-d).b,1.0); float v=smoothstep(0.85,0.25,length(vUv-0.5)); c.rgb*=mix(1.0-uVig,1.0,v); gl_FragColor=c; }' });
    c.addPass(fxPass); c.addPass(new O.OutputPass()); c.setPixelRatio(renderer.getPixelRatio()); c.setSize(w, h); composer = c;
  } catch (e) { console.warn('Post-processing unavailable, using direct render.', e); composer = null; }
}
function init() {
  const mount = $('#three-stage'); scene = new THREE.Scene(); scene.background = new THREE.Color(0x070b16); scene.fog = new THREE.FogExp2(0x070b16, .022);
  camera = new THREE.PerspectiveCamera(40, mount.clientWidth / Math.max(1, mount.clientHeight), .1,120); camera.position.set(0, 3.4, 10.5); camera.lookAt(0, 1.4, 0);
  renderer = new THREE.WebGLRenderer({ antialias: true, alpha: false, powerPreference: 'high-performance' });
  renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 1.65)); renderer.setSize(mount.clientWidth, mount.clientHeight); renderer.shadowMap.enabled = true; renderer.shadowMap.type = THREE.PCFSoftShadowMap;
  renderer.outputColorSpace = THREE.SRGBColorSpace; renderer.toneMapping = THREE.ACESFilmicToneMapping; renderer.toneMappingExposure = exposure; mount.appendChild(renderer.domElement);
  L.hemi = new THREE.HemisphereLight(0xa8c4ff, 0x1a1a2e, 1.5); scene.add(L.hemi);
  const key = L.key = new THREE.DirectionalLight(0xfff4ea, 2.7); key.position.set(-2.5, 9, 6); key.castShadow = true; key.shadow.mapSize.set(2048, 2048); Object.assign(key.shadow.camera, { left: -9, right: 9, top: 7, bottom: -5, near: 1, far: 30 }); key.shadow.bias = -.0004; scene.add(key);
  const rim = L.rim = new THREE.DirectionalLight(0x6fd8ff, 1.6); rim.position.set(6, 4, -6); scene.add(rim); const rim2 = L.rim2 = new THREE.DirectionalLight(0xff6f9a, 1.3); rim2.position.set(-6, 3, -5); scene.add(rim2);
  flashLight.l = new THREE.PointLight(0xffffff, 0, 9, 2); scene.add(flashLight.l);
  loadArena(arenaId); vfx = new VFX(scene, camera, $('.game3d-stage'));
  player = makeUnit(slug, true); enemy = makeUnit(enemySlug, false); units = [player, enemy]; clock = new THREE.Clock();
  if (mySide === 1) { player.pos.x = 2.6; enemy.pos.x = -2.6; player.last.copy(player.pos); enemy.last.copy(enemy.pos); player.yaw = -Math.PI / 2; enemy.yaw = Math.PI / 2; }
  if (online) { enemy.remote = true; enemy.netInit = false; $('#enemy-name').textContent = matchInfo ? matchInfo.opp.name.toUpperCase() : 'OPPONENT'; const bd = $('#enemy-badge'), sb = $('#enemy-sub'); if (bd) { bd.textContent = 'P2'; bd.classList.remove('cpu'); } if (sb && matchInfo) sb.textContent = `${ROSTER[enemySlug].name} · ELO ${matchInfo.opp.elo}`; app.classList.add('is-online'); }
  else $('#enemy-name').textContent = ROSTER[enemySlug].name;
  const an = $('#arena-name'); if (an) an.textContent = arenaName(arenaId); camera.position.set(Math.sin(-.5) * 11, 3, Math.cos(-.5) * 11);
  resize(); window.addEventListener('resize', resize); setQuality('medium'); setupPost().then(() => resize()); animate();
}
function resize() {
  if (!renderer) return; const m = $('#three-stage'), w = Math.max(1, m.clientWidth), h = Math.max(1, m.clientHeight);
  camera.aspect = w / h; camera.updateProjectionMatrix(); renderer.setSize(w, h);
  if (composer) { composer.setPixelRatio(renderer.getPixelRatio()); composer.setSize(w, h); } if (bloom) bloom.resolution.set(w, h);
  vfx.setScale(h * renderer.getPixelRatio(), camera.fov);
}
function setQuality(q) {
  quality = q; if (!renderer) return;
  renderer.setPixelRatio(q === 'low' ? 1 : q === 'ultra' ? Math.min(devicePixelRatio || 1, 2) : Math.min(devicePixelRatio || 1, 1.55)); renderer.shadowMap.enabled = q !== 'low'; vfx.setQuality(q);
  if (bloom) bloom.strength = q === 'ultra' ? .95 : .75; resize();
}
function updateHUD() {
  $('#hp-player').style.width = player.hp + '%'; $('#hp-enemy').style.width = enemy.hp + '%'; $('#energy-player').style.width = player.energy + '%'; $('#energy-enemy').style.width = enemy.energy + '%';
  $('#timer').textContent = String(Math.ceil(timeLeft)).padStart(2, '0');
  $('#energy-player').parentElement.classList.toggle('ready', player.energy >= 65); $('#energy-enemy').parentElement.classList.toggle('ready', enemy.energy >= 65);
  const tu = document.querySelector('[data-act="u"]'); if (tu) tu.classList.toggle('ready', player.energy >= 65);
}
function finish(result) {
  if (finished) return; finished = true; started = false; timeScaleTarget = 1; timeScale = 1;
  $('#result-title').textContent = result === 'win' ? 'VICTORY' : result === 'loss' ? 'DEFEAT' : 'DRAW'; $('#result-title').className = result === 'loss' ? 'loss' : '';
  $('#result-detail').textContent = `Damage dealt ${damageDealt} · Successful hits ${successfulHits} · Match duration ${Math.floor(elapsed)}s`;
  $('#result-overlay').classList.add('show'); $('#round-label').textContent = result === 'win' ? 'PLAYER WINS' : result === 'loss' ? (online ? 'OPPONENT WINS' : 'CPU WINS') : 'TIME UP';
  if (result === 'win') sfx.win(); else sfx.ui();
  if (online) { netEnded = true; if (net) net.send({ t: 'end', result }); $('#result-detail').textContent += ' · Menunggu hasil server…'; }
  if (!online) fetch('api/save-match.php', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ csrf, character: slug, opponent: enemySlug, result, mode, duration: Math.floor(elapsed), damage: damageDealt, hits: successfulHits, difficulty: 'normal' }) }).catch(() => {});
}
function resetUnit(u, x) {
  u.hp = 100; u.energy = 30; u.state = 'free'; u.t = 0; u.mv = null; u.queue = null; u.y = 0; u.vy = 0; u.air = false; u.dead = false; u.frozen = false; u.invuln = 0; u.ult = null; u.kb.set(0, 0, 0); u.winPending = false; u.winT = 0;
  u.pos.set(x, 0, 0); u.last.copy(u.pos); u.lastY = 0; u.f.snapPose(STANCE); u.f.setExpression('focus'); u.f.glowBoost = 1; u.inp.mx = u.inp.mz = 0; u.inp.block = false; u.chain = 0; u.chainT = 0; u.landT = 0; u.f.cur.lean[1] = 0;
}
function restart() {
  resetUnit(player, mySide ? 2.6 : -2.6); resetUnit(enemy, mySide ? -2.6 : 2.6); for (const p of projectiles) { scene.remove(p.vis.group); p.vis.dispose(); } projectiles.length = 0;
  elapsed = 0; timeLeft = 99; damageDealt = 0; successfulHits = 0; combo = 0; finished = false; paused = false; started = false; koT = -1; camMode = 'normal'; camFocus = null; timeScale = timeScaleTarget = 1; exposure = baseExposure; hitStop = 0;
  $('#result-overlay').classList.remove('show'); $('#pause-overlay').classList.remove('show'); $('#game-overlay').classList.remove('hidden'); $('#round-label').textContent = 'READY TO FIGHT'; $('#combo-display').textContent = ''; updateHUD();
}
function animate() {
  requestAnimationFrame(animate); const raw = Math.min(clock.getDelta(), .05); let dt = 0; clockT += raw;
  if (!paused) { timeScale += (timeScaleTarget - timeScale) * Math.min(1, raw * 6); dt = hitStop > 0 ? 0 : raw * timeScale; hitStop = Math.max(0, hitStop - raw); }
  if (started && !paused && !finished) {
    elapsed += dt;
    if (!player.frozen || true) { if (!player.frozen) { setPlayerInput(); updateUnit(player, enemy, dt); } else player.f.update(dt * .1); }
    if (online) { if (!enemy.frozen) updateUnit(enemy, player, dt); else enemy.f.update(dt * .1); }
    else if (mode !== 'training') { if (!enemy.frozen) { aiUpdate(enemy, player, dt); updateUnit(enemy, player, dt); } else enemy.f.update(dt * .1); } else { enemy.inp.mx = enemy.inp.mz = 0; enemy.inp.block = false; if (!enemy.frozen) updateUnit(enemy, player, dt); }
    updateProjectiles(dt); if (online) netTick();
    if (mode === 'training' && enemy.hp < 100 && enemy.state === 'free') enemy.hp = Math.min(100, enemy.hp + dt * 18);
    if (koT >= 0) {
      koT += raw; const w = foe(player.dead ? player : enemy); if (w.winPending && koT > 1.2 && w.state === 'free') { w.state = 'win'; }
      if (koT > 1.0) timeScaleTarget = Math.min(1, .22 + (koT - 1.0) * .5);
      if (koT > 2.4) finish(koResult);
    } else {
      if (!(player.state === 'ult' || enemy.state === 'ult')) timeLeft = Math.max(0, timeLeft - dt);
      if (timeLeft <= 0) finish(player.hp === enemy.hp ? 'draw' : player.hp > enemy.hp ? 'win' : 'loss');
    }
    if (comboUntil < elapsed && combo) { combo = 0; $('#combo-display').textContent = ''; }
  } else if (!started && !paused) { for (const u of units) { u.inp.mx = u.inp.mz = 0; u.inp.block = false; u.f.trackPose(STANCE, raw, 10); u.f.update(raw); u.f.setExpression('focus'); } }
  if (messageTimer > 0) { messageTimer -= raw; if (messageTimer <= 0) { $('#round-label').style.opacity = started ? '.0' : '1'; if (started && !finished) $('#round-label').textContent = ''; } }
  // flash light decay
  if (flashLight.life > 0) { flashLight.life -= raw; flashLight.l.intensity = Math.max(0, flashLight.base * flashLight.life / flashLight.max); } else flashLight.l.intensity = 0;
  if (arena) { arena.update(raw, clockT); envFlash = Math.max(0, envFlash - raw * 4.5); L.hemi.intensity = arena.env.hemi[2] + envFlash * 2.5; }
  vfx.update(paused ? 0 : raw * Math.max(.35, timeScale)); updateCamera(raw, raw);
  renderer.toneMappingExposure += (exposure + envFlash * .35 - renderer.toneMappingExposure) * Math.min(1, raw * 6);
  if (fxPass) { fxPass.uniforms.uAb.value = vfx.aberr; fxPass.uniforms.uVig.value = camMode === 'ult' ? .6 : .32; }
  if (composer && quality !== 'low') composer.render(); else renderer.render(scene, camera);
  updateHUD();
}
function setPlayerInput() {
  const p = player.inp; let ix = (keys.has('d') ? 1 : 0) - (keys.has('a') ? 1 : 0) + touch.mx, iz = (keys.has('s') ? 1 : 0) - (keys.has('w') ? 1 : 0) + touch.mz; const l = Math.hypot(ix, iz); if (l > 1) { ix /= l; iz /= l; }
  const c = Math.cos(camYaw), sn = Math.sin(camYaw); p.mx = ix * c + iz * sn; p.mz = -ix * sn + iz * c; p.block = keys.has('i') || touch.block; // camera-relative movement
}
function begin() { sfx.unlock(); sfx.start(); if (finished && !online) restart(); if (app.classList.contains('has-touch') && !app.classList.contains('fs')) setFS(true); started = true; paused = false; $('#game-overlay').classList.add('hidden'); $('#pause-overlay').classList.remove('show'); showMessage('FIGHT!', 1.0); }
function togglePause() { if (online) return; if (!started || finished) { if (!started && !finished) begin(); return; } paused = !paused; $('#pause-overlay').classList.toggle('show', paused); }
function press(k) {
  if (!started || paused || finished) return;
  if (k === 'j') requestAttack(player, 'light'); else if (k === 'k') requestAttack(player, 'heavy'); else if (k === 'l') requestAttack(player, 'special'); else if (k === 'u') requestAttack(player, 'ultimate');
  else if (k === 'shift') player.dashReq = true; else if (k === 'space') player.jumpReq = true;
}
window.addEventListener('keydown', e => {
  const k = e.key.toLowerCase(); if ([' ', 'arrowup', 'arrowdown', 'arrowleft', 'arrowright'].includes(k)) e.preventDefault();
  if (k === 'escape') { togglePause(); return; } if (k === 'enter' && !started && !finished) { begin(); return; }
  if (['w', 'a', 's', 'd', 'i'].includes(k)) keys.add(k);
  if (!e.repeat && ['j', 'k', 'l', 'u', 'shift', ' '].includes(k)) press(k === ' ' ? 'space' : k);
});
window.addEventListener('keyup', e => { keys.delete(e.key.toLowerCase()); });
window.addEventListener('blur', () => keys.clear());
$('#start-game').addEventListener('click', begin); $('#pause-game').addEventListener('click', togglePause); $('#resume-game').addEventListener('click', togglePause); $('#restart-game').addEventListener('click', restart);
$('#result-rematch').addEventListener('click', () => { if (online) { location.reload(); return; } restart(); begin(); }); $('#quality-select').addEventListener('change', e => setQuality(e.target.value));

/* ------------------------------------------------------- touch + fullscreen ---- */
function setFS(on) {
  app.classList.toggle('fs', on); document.body.classList.toggle('game-fs', on);
  if (on) { try { (app.requestFullscreen || app.webkitRequestFullscreen || (() => {})).call(app); } catch (e) {} try { screen.orientation.lock('landscape').catch(() => {}); } catch (e) {} }
  else { try { if (document.fullscreenElement) document.exitFullscreen(); } catch (e) {} try { screen.orientation.unlock(); } catch (e) {} }
  setTimeout(resize, 120); setTimeout(resize, 450);
}
document.addEventListener('fullscreenchange', () => { if (!document.fullscreenElement && app.classList.contains('fs') && app.classList.contains('has-touch')) { /* keep CSS fullscreen fallback */ } setTimeout(resize, 150); });
window.addEventListener('orientationchange', () => { setTimeout(resize, 250); });
function initTouch() {
  const ui = $('#touch-ui'); if (!ui) return;
  const isTouch = matchMedia('(pointer:coarse)').matches || /[?&]touch=1/.test(location.search) || navigator.maxTouchPoints > 1 && innerWidth < 1100;
  if (!isTouch) return; app.classList.add('has-touch');
  const joy = $('#joy'), knob = $('#joy-knob'); let jid = null, cx = 0, cy = 0; const R = 54;
  const move = e => { const dx = e.clientX - cx, dy = e.clientY - cy, l = Math.hypot(dx, dy) || 1, k = Math.min(1, l / R); touch.mx = dx / l * k; touch.mz = dy / l * k; if (Math.hypot(touch.mx, touch.mz) < .2) touch.mx = touch.mz = 0; const m = Math.min(l, R); knob.style.transform = `translate(${dx / l * m}px,${dy / l * m}px)`; };
  joy.addEventListener('pointerdown', e => { e.preventDefault(); sfx.unlock(); jid = e.pointerId; try { joy.setPointerCapture(jid); } catch (_) {} const r = joy.getBoundingClientRect(); cx = r.left + r.width / 2; cy = r.top + r.height / 2; move(e); });
  joy.addEventListener('pointermove', e => { if (e.pointerId === jid) { e.preventDefault(); move(e); } });
  const end = e => { if (e.pointerId !== jid) return; jid = null; touch.mx = touch.mz = 0; knob.style.transform = ''; };
  joy.addEventListener('pointerup', end); joy.addEventListener('pointercancel', end);
  ui.querySelectorAll('[data-act]').forEach(b => {
    const a = b.dataset.act;
    b.addEventListener('pointerdown', e => { e.preventDefault(); sfx.unlock(); b.classList.add('on'); try { b.setPointerCapture(e.pointerId); } catch (_) {} if (a === 'block') touch.block = true; else press(a); if (navigator.vibrate) navigator.vibrate(a === 'u' ? 30 : 8); });
    const up = () => { b.classList.remove('on'); if (a === 'block') touch.block = false; }; b.addEventListener('pointerup', up); b.addEventListener('pointercancel', up);
  });
  app.addEventListener('contextmenu', e => e.preventDefault());
  app.addEventListener('touchmove', e => { if (app.classList.contains('fs')) e.preventDefault(); }, { passive: false });
}
const fsBtn = $('#fs-btn'); if (fsBtn) fsBtn.addEventListener('click', () => setFS(!app.classList.contains('fs')));
const muteBtn = $('#mute-btn'); if (muteBtn) { const upd = () => { muteBtn.textContent = sfx.muted ? '🔇' : '🔊'; }; upd(); muteBtn.addEventListener('click', () => { sfx.unlock(); sfx.setMuted(!sfx.muted); upd(); }); }

/* ------------------------------------------------------------------ online ---- */
const lobbyEl = $('#lobby'), r3 = v => Math.round(v * 1000) / 1000, wait = ms => new Promise(r => setTimeout(r, ms));
function lobbyShow(step, msg) { if (!lobbyEl) return; lobbyEl.classList.add('show'); lobbyEl.dataset.step = step; if (msg != null) { const st = $('#lb-status'); if (st) st.textContent = msg; } }
function lobbyHide() { if (lobbyEl) lobbyEl.classList.remove('show'); }
function lobbyError(msg) { const e = $('#lb-error'); if (e) e.textContent = msg; lobbyShow('error'); }
function runLobby() {
  $('#game-overlay').classList.add('hidden'); lobbyShow('connect', 'MENGHUBUNGKAN KE SERVER…');
  const myArena = app.dataset.arena || 'neon-rift'; net = new Net(app.dataset.ws, app.dataset.token);
  const queue = m => { lobbyShow('search', 'MENCARI LAWAN…'); net.send({ t: 'queue', mode: m, char: slug, arena: myArena }); };
  return net.connect().then(me => new Promise(resolve => {
    const meEl = $('#lb-me'); if (meEl) meEl.textContent = `${me.name} · ELO ${me.elo}`;
    net.on('match', m => resolve(m)).on('queued', q => lobbyShow('search', `MENCARI LAWAN… ${q.wait}s · ${q.size} di antrean`)).on('room', r => { $('#lb-room').textContent = r.code; lobbyShow('room'); })
      .on('err', e => { const st = $('#lb-status'); if (lobbyEl.dataset.step === 'menu' || lobbyEl.dataset.step === 'join') { $('#lb-join-err').textContent = e.msg; } else lobbyError(e.msg); }).on('cancelled', () => lobbyShow('menu'))
      .on('close', () => { if (!matchInfo) lobbyError('Koneksi ke server terputus.'); });
    const on = (id, fn) => { const el = $(id); if (el) el.addEventListener('click', () => { sfx.click(); fn(); }); };
    on('#lb-quick', () => queue('casual')); on('#lb-create', () => net.send({ t: 'create', char: slug, arena: myArena }));
    on('#lb-join', () => { $('#lb-join-err').textContent = ''; net.send({ t: 'join', code: $('#lb-code').value, char: slug, arena: myArena }); });
    on('#lb-cancel', () => net.send({ t: 'cancel' })); on('#lb-cancel2', () => net.send({ t: 'cancel' }));
    if (mode === 'ranked') queue('ranked'); else lobbyShow('menu');
  })).catch(e => { lobbyError(`Tidak bisa terhubung ke server online (${e.message}). Jalankan server: node server/online-server.js (lihat README).`); return null; });
}
function showFound(m) {
  const set = (id, v) => { const el = $(id); if (el) el.textContent = v; };
  set('#vs-me', (net && $('#lb-me') ? $('#lb-me').textContent.split(' · ')[0] : 'YOU').toUpperCase()); set('#vs-me-char', ROSTER[slug].name); set('#vs-opp', m.opp.name.toUpperCase()); set('#vs-opp-char', ROSTER[m.opp.char] ? ROSTER[m.opp.char].name : '?'); set('#vs-opp-elo', `ELO ${m.opp.elo}`);
  set('#vs-mode', m.mode === 'ranked' ? 'RANKED MATCH' : 'ONLINE MATCH'); set('#vs-arena', arenaName(m.arena));
  const a = $('#vs-me-img'), b = $('#vs-opp-img'); if (a) a.src = `assets/ui-previews/cut/${slug}.png`; if (b) b.src = `assets/ui-previews/cut/${m.opp.char}.png`; lobbyShow('found'); sfx.select();
}
function wireOnline() {
  net.on('go', () => { lobbyHide(); netGo = true; lastSnapAt = 0; begin(); })
    .on('s', onSnap).on('ev', onEv)
    .on('opp_left', () => { if (!finished) { showMessage('LAWAN KELUAR', 2); $('#result-detail').textContent = 'Lawan memutus koneksi.'; finish('win'); } })
    .on('result', onResult)
    .on('close', () => { if (!finished && !netEnded) { $('#result-detail').textContent = 'Koneksi terputus.'; finish('loss'); } });
}
function netTick() {
  if (!net || !netGo || netEnded) return; const u = player, key = u.state + '|' + (u.moveName || '') + '|' + (u.blocking ? 'b' : '') + (u.air ? 'a' : ''), now = performance.now();
  if (key !== lastSnapKey || now - lastSnapAt >= 50) {
    lastSnapKey = key; lastSnapAt = now;
    net.send({ t: 's', x: r3(u.pos.x), z: r3(u.pos.z), y: r3(u.y), yaw: r3(u.yaw), st: u.state, mv: u.moveName || '', tt: r3(u.t), hp: Math.round(u.hp * 10) / 10, en: Math.round(u.energy), bl: u.blocking ? 1 : 0, ar: u.air ? 1 : 0, ht: u.hitType, sT: r3(u.stunT || 0), dd: u.dead ? 1 : 0 });
  }
}
function onSnap(s) {
  const u = enemy; if (!u || u.dead || finished || typeof s.x !== 'number') return;
  if (player.state === 'ult' || enemy.state === 'ult' || player.state === 'locked' || enemy.state === 'locked') return; // ultimate sequence is simulated locally on both sides
  u.netT = { x: clamp(s.x, -7, 7), z: clamp(s.z, -4.5, 3.5), y: clamp(s.y, 0, 6) }; if (!u.netInit) { u.pos.set(u.netT.x, 0, u.netT.z); u.y = u.netT.y; u.netInit = true; }
  u.hp = clamp(+s.hp || 0, 0, 100); u.energy = clamp(+s.en || 0, 0, 100); u.inp.block = !!s.bl; u.blocking = !!s.bl; u.air = !!s.ar; u.hitType = s.ht === 'heavy' ? 'heavy' : 'light'; u.stunT = clamp(+s.sT || .25, .1, 1);
  if (s.st !== 'ult' && s.st !== 'locked') {
    const chg = u.state !== s.st || (s.st === 'attack' && u.moveName !== s.mv);
    if (chg) {
      u.state = s.st; u.t = +s.tt || 0;
      if (s.st === 'attack' && MOVES[s.mv]) { u.moveName = s.mv; u.mv = MOVES[s.mv]; u.hitDone = true; u.connected = false; u.fxDone = false; u.released = false; u.fin = true; u.ghostT = 0; u.f.setExpression('attack'); u.f.normalizeSpin(); sfx.swing(); if (s.mv === 'dash') { sfx.dash(); camKick = Math.max(camKick, .4); } }
      else if (s.st === 'attack') u.state = 'free';
      else if (s.st === 'hit') u.f.setExpression('hurt'); else if (s.st === 'free') u.f.setExpression('focus');
    } else if (Math.abs(u.t - (+s.tt || 0)) > .12) u.t = +s.tt || 0;
  }
  if (u.hp <= 0 && !u.dead) { dirTo(player, u, V3); koSequence(player, u, V3.clone()); }
}
function onEv(e) {
  if (finished) return;
  if (e.k === 'hit') {
    if (player.dead || player.state === 'ult' || player.state === 'locked') return;
    const mv = { dmg: clamp(+e.dmg || 0, 0, 32), push: clamp(+e.push || 2, 0, 14), stun: clamp(+e.stun || .25, .1, 1), launch: clamp(+e.launch || 0, 0, 12), heavyHit: !!e.hv, energy: clamp(+e.en || 4, 0, 10) };
    hurt(enemy, player, mv, { unblockable: !!e.ub, force: !!e.fc });
  } else if (e.k === 'ult') {
    if (enemy.state !== 'ult' && player.state !== 'ult' && enemy.state !== 'locked' && player.state !== 'locked') { enemy.energy = 100; startUlt(enemy); }
  }
}
function onResult(r) {
  netEnded = true; const t = $('#result-title'), d = $('#result-detail');
  if (r.result) { t.textContent = r.result === 'win' ? 'VICTORY' : r.result === 'loss' ? 'DEFEAT' : 'DRAW'; t.className = r.result === 'loss' ? 'loss' : ''; }
  let txt = `Damage dealt ${damageDealt} · Successful hits ${successfulHits} · ${Math.floor(elapsed)}s`;
  if (r.ranked && r.elo) txt += ` · RANKED ELO ${r.elo.old} → ${r.elo.new} (${r.elo.delta >= 0 ? '+' : ''}${r.elo.delta})${r.tier ? ' · ' + r.tier : ''}${r.saved === false ? ' · (belum tersimpan)' : ''}`;
  else if (!r.result) txt += ' · Hasil tidak dicatat'; else if (!r.ranked) txt += ' · Online match tercatat';
  d.textContent = txt; finished = true;
}

/* -------------------------------------------------------------------- boot ---- */
window.__fv = { get player() { return player; }, get enemy() { return enemy; }, press, begin, get net() { return net; }, get finished() { return finished; }, get mySide() { return mySide; }, get resultText() { return $('#result-title').textContent + ' | ' + $('#result-detail').textContent; } };
(async () => {
  try {
    initTouch();
    if (online) {
      const m = await runLobby(); if (!m) return;
      matchInfo = m; enemySlug = ROSTER[m.opp.char] ? m.opp.char : enemySlug; arenaId = m.arena; mySide = m.side; showFound(m);
      const t0 = performance.now(); init(); wireOnline(); await wait(Math.max(0, 2600 - (performance.now() - t0)));
      lobbyShow('found'); net.send({ t: 'ready' }); const st = $('#vs-wait'); if (st) st.textContent = 'MENUNGGU LAWAN SIAP…';
    } else init();
  } catch (err) { console.error(err); $('#game-overlay').classList.remove('hidden'); $('#game-overlay h2').innerHTML = 'WEBGL <span>UNAVAILABLE</span>'; $('#game-overlay p').textContent = 'Browser gagal menginisialisasi WebGL. Coba browser desktop terbaru dan aktifkan hardware acceleration.'; $('#start-game').style.display = 'none'; }
})();
