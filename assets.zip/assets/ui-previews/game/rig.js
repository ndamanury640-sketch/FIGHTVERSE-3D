// rig.js — pose data & math (no THREE dependency, so it can be unit-tested in Node).
// Convention: character faces +Z, up is +Y. Character LEFT = +X, RIGHT = -X.
// All joints use Euler order 'YXZ'. Arm/leg hanging down is (0,-1,0):
//   rotation.x < 0  -> swings forward/up   rotation.z (L: +, R: -) -> abducts outward.
export const TAU = Math.PI * 2;

export const D = {
  hipX: .15, hipDrop: .03, thigh: .54, shin: .52, ankle: .10,
  spineJ: .08, chestJ: .30, neckJ: .40, headJ: .30,
  shX: .35, shY: .30, ua: .40, fa: .38, hand: .07
};

export const J = ['hips','spine','chest','neck','head','uaL','uaR','elL','elR','thL','thR','knL','knR','ftL','ftR'];

export const mkPose = () => { const p = { body: [0,0,0], lean: [0,0,0] }; for (const j of J) p[j] = [0,0,0]; return p; };
export const clonePose = p => { const o = {}; for (const k in p) o[k] = p[k].slice(); return o; };
export const copyPose = (d, s) => { for (const k in s) { d[k][0] = s[k][0]; d[k][1] = s[k][1]; d[k][2] = s[k][2]; } return d; };
export const lerpPose = (o, a, b, t) => { for (const k in a) { o[k][0] = a[k][0] + (b[k][0]-a[k][0])*t; o[k][1] = a[k][1] + (b[k][1]-a[k][1])*t; o[k][2] = a[k][2] + (b[k][2]-a[k][2])*t; } return o; };
export const withPose = (base, partial) => { const p = clonePose(base); for (const k in partial) p[k] = partial[k].slice(); return p; };
const flat = (th, kn) => -(th + kn);

// ---- tiny 3x3 math (YXZ euler) used for exact foot grounding; also reused by tests.
const _Rx = a => [[1,0,0],[0,Math.cos(a),-Math.sin(a)],[0,Math.sin(a),Math.cos(a)]];
const _Ry = a => [[Math.cos(a),0,Math.sin(a)],[0,1,0],[-Math.sin(a),0,Math.cos(a)]];
const _Rz = a => [[Math.cos(a),-Math.sin(a),0],[Math.sin(a),Math.cos(a),0],[0,0,1]];
export const m3mul = (A, B) => A.map((r, i) => [0,1,2].map(j => r[0]*B[0][j] + r[1]*B[1][j] + r[2]*B[2][j]));
export const m3ap = (M, v) => [0,1,2].map(i => M[i][0]*v[0] + M[i][1]*v[1] + M[i][2]*v[2]);
export const eulerM = e => m3mul(m3mul(_Ry(e[1]), _Rx(e[0])), _Rz(e[2]));

// Feet keep (most of) their world yaw when the pelvis twists, so punches do not spin the feet.
export const LEG_YAW_KEEP = .85;
export const legYawDelta = p => (p.hips[1] - STANCE_HIPS_Y) * LEG_YAW_KEEP;
let STANCE_HIPS_Y = -.5;

// Height of the hips pivot so the lowest foot point touches y=0 (lean pivots around the hips).
export function groundHips(p) {
  const dy = legYawDelta(p), Mh = m3mul(eulerM(p.lean), eulerM(p.hips));
  let low = 0;
  for (const [s, sx] of [['L', 1], ['R', -1]]) {
    const th = p['th' + s], Mt = m3mul(Mh, eulerM([th[0], th[1] - dy, th[2]]));
    const Mk = m3mul(Mt, eulerM(p['kn' + s])), Mf = m3mul(Mk, eulerM(p['ft' + s]));
    const base = m3ap(Mh, [sx*D.hipX, -D.hipDrop, 0])[1] + m3ap(Mt, [0, -D.thigh, 0])[1] + m3ap(Mk, [0, -D.shin, 0])[1];
    for (const pt of [[0,-.095,-.05],[0,-.095,.24]]) low = Math.min(low, base + m3ap(Mf, pt)[1]);
  }
  return -low;
}

export const STANCE = (() => {
  const p = mkPose();
  Object.assign(p, {
    hips: [0,-.5,0], spine: [.10,.12,0], chest: [.04,.14,0], neck: [-.04,.18,0], head: [-.02,.16,0],
    uaL: [-.8,.35,.32], elL: [-1.85,0,0], uaR: [-.6,.5,-.3], elR: [-2.05,0,0],
    thL: [-.5,.5,.05], knL: [.8,0,0], ftL: [flat(-.5,.8),0,0],
    thR: [.32,.15,-.06], knR: [.55,0,0], ftR: [flat(.32,.55)+.1,0,0]
  });
  return p;
})();

export const EASE = {
  lin: t => t,
  out: t => 1 - Math.pow(1 - t, 3),
  in: t => t * t * t,
  io: t => t < .5 ? 2*t*t : 1 - Math.pow(-2*t + 2, 2) / 2,
  snap: t => 1 - Math.pow(1 - t, 5)
};
const K = (t, partial, ease = 'io') => ({ t, pose: withPose(STANCE, partial), ease });

export function evalKeys(keys, t, out) {
  if (t <= keys[0].t) return copyPose(out, keys[0].pose);
  for (let i = 1; i < keys.length; i++) {
    if (t <= keys[i].t) {
      const a = keys[i-1], b = keys[i];
      return lerpPose(out, a.pose, b.pose, EASE[b.ease || 'io']((t - a.t) / Math.max(1e-4, b.t - a.t)));
    }
  }
  return copyPose(out, keys[keys.length-1].pose);
}

/* ---------------------------------------------------------------- MOVES ---- */
// act: [start,end] active hit window (s). lunge: [t0,t1,speed]. cancel: time after which a connected move may cancel.
export const MOVES = {
  jab: { tier:'light', dur:.34, act:[.10,.19], dmg:6, range:2.2, push:2.2, stun:.24, lunge:[.03,.15,3.8], cancel:.17, energy:4,
    slash:{ roll:-.1, flip:1, scale:1.0, arc:1.9 }, hand:'L',
    keys:[ K(0,{}), 
      K(.06,{ chest:[.04,.30,0], uaL:[-.6,.2,.35], elL:[-2.3,0,0], body:[0,0,-.04], lean:[-.03,0,0] }),
      K(.14,{ hips:[0,-.3,0], chest:[.02,.48,0], uaL:[-1.5,-.3,.08], elL:[-.12,0,0], body:[0,0,.16], lean:[.09,0,0] }, 'snap'),
      K(.20,{ hips:[0,-.3,0], chest:[.02,.48,0], uaL:[-1.5,-.3,.08], elL:[-.12,0,0], body:[0,0,.16], lean:[.09,0,0] }, 'lin'),
      K(.34,{}) ] },
  cross: { tier:'light', dur:.40, act:[.13,.22], dmg:7, range:2.25, push:2.6, stun:.26, lunge:[.05,.18,4.2], cancel:.2, energy:4,
    slash:{ roll:.15, flip:-1, scale:1.1, arc:2.0 }, hand:'R',
    keys:[ K(0,{}),
      K(.08,{ hips:[0,-.95,0], chest:[.04,-.1,0], uaR:[-.5,.3,-.25], elR:[-2.4,0,0], body:[0,0,-.07], lean:[-.04,0,0], thR:[.42,.15,-.06], knR:[.75,0,0] }),
      K(.17,{ hips:[0,.28,0], spine:[.12,.18,0], chest:[.02,.28,0], uaR:[-1.5,-.72,-.08], elR:[-.1,0,0], body:[0,0,.2], lean:[.1,0,0],
              thR:[.1,.15,-.06], knR:[.2,0,0], ftR:[-.3,0,0] }, 'snap'),
      K(.24,{ hips:[0,.28,0], spine:[.12,.18,0], chest:[.02,.28,0], uaR:[-1.5,-.72,-.08], elR:[-.1,0,0], body:[0,0,.2], lean:[.1,0,0],
              thR:[.1,.15,-.06], knR:[.2,0,0], ftR:[-.3,0,0] }, 'lin'),
      K(.40,{}) ] },
  kick: { tier:'light', dur:.56, act:[.20,.31], dmg:9, range:2.55, push:4.4, stun:.34, lunge:[.12,.28,3.0], cancel:.3, energy:5, heavyHit:true,
    slash:{ roll:.35, flip:1, scale:1.45, arc:2.4, horizontal:true }, hand:'footR',
    keys:[ K(0,{}),
      K(.14,{ hips:[0,-.9,0], chest:[.0,-.3,0], thR:[.5,0,-.25], knR:[1.9,0,0], ftR:[.3,0,0], thL:[-.1,.6,.05], knL:[.3,0,0], ftL:[-.2,0,0], lean:[-.03,0,-.08] }),
      K(.27,{ hips:[0,.95,0], chest:[.0,.1,0], spine:[.0,.1,0], thR:[-1.5,.05,-.45], knR:[.12,0,0], ftR:[-.25,0,0],
              thL:[-.1,.6,.05], knL:[.3,0,0], ftL:[-.2,0,0], lean:[-.02,0,-.34], uaL:[-.6,.2,.9], uaR:[-.4,0,-1.0], elL:[-.8,0,0], elR:[-.7,0,0] }, 'snap'),
      K(.34,{ hips:[0,.95,0], chest:[.0,.1,0], spine:[.0,.1,0], thR:[-1.5,.05,-.45], knR:[.12,0,0], ftR:[-.25,0,0],
              thL:[-.1,.6,.05], knL:[.3,0,0], ftL:[-.2,0,0], lean:[-.02,0,-.34], uaL:[-.6,.2,.9], uaR:[-.4,0,-1.0], elL:[-.8,0,0], elR:[-.7,0,0] }, 'lin'),
      K(.56,{}) ] },

  // ---- heavy variants
  uppercut: { tier:'heavy', dur:.68, act:[.24,.38], dmg:14, range:2.2, push:3.0, stun:.5, launch:7.2, lunge:[.12,.3,3.4], cancel:.34, energy:7, heavyHit:true,
    slash:{ roll:1.35, flip:1, scale:1.7, arc:2.4, rising:true }, hand:'R',
    keys:[ K(0,{}),
      K(.20,{ spine:[.42,.1,0], chest:[.14,-.2,0], hips:[0,.1,0], uaR:[.8,.3,-.2], elR:[-.5,0,0], uaL:[-.9,.2,.3], elL:[-1.9,0,0],
              thL:[-.9,.5,.05], knL:[1.6,0,0], ftL:[-.7,0,0], thR:[.35,.15,-.06], knR:[1.35,0,0], ftR:[-.2,0,0], lean:[.1,0,0] }),
      K(.31,{ spine:[-.08,.2,0], chest:[-.25,.3,0], hips:[0,.4,0], uaR:[-2.85,-.1,-.2], elR:[-.2,0,0], uaL:[-.4,0,.5], elL:[-1.4,0,0],
              thL:[-.3,.5,.05], knL:[.25,0,0], ftL:[.3,0,0], thR:[-.1,.15,-.06], knR:[.7,0,0], ftR:[.5,0,0], body:[0,.3,.2], lean:[-.08,0,0] }, 'snap'),
      K(.42,{ spine:[-.1,.2,0], chest:[-.3,.3,0], hips:[0,.4,0], uaR:[-2.95,-.1,-.2], elR:[-.2,0,0], uaL:[-.4,0,.6], elL:[-1.2,0,0],
              thL:[-.5,.5,.05], knL:[.6,0,0], ftL:[.3,0,0], thR:[-.2,.15,-.06], knR:[1.0,0,0], ftR:[.6,0,0], body:[0,.5,.25], lean:[-.1,0,0] }, 'out'),
      K(.68,{}) ] },
  cleave: { tier:'heavy', dur:.74, act:[.31,.43], dmg:14, range:2.6, push:3.4, stun:.5, launch:0, lunge:[.24,.42,4.6], cancel:.38, energy:7, heavyHit:true,
    slash:{ roll:-.35, flip:1, scale:2.3, arc:2.6, vertical:true }, hand:'R',
    keys:[ K(0,{}),
      K(.28,{ hips:[0,.35,0], chest:[-.28,.4,0], spine:[-.08,.1,0], uaR:[-3.0,.1,-.3], elR:[-1.2,0,0], uaL:[-2.2,.2,.3], elL:[-1.0,0,0],
              lean:[-.12,0,0], body:[0,.05,-.1], thL:[-.5,.5,.05], knL:[.9,0,0], thR:[.4,.15,-.06], knR:[.7,0,0] }),
      K(.38,{ hips:[0,-.15,0], chest:[.4,.0,0], spine:[.25,.05,0], uaR:[-1.15,-.1,-.1], elR:[-.2,0,0], uaL:[-1.0,.1,.3], elL:[-.5,0,0],
              lean:[.26,0,0], body:[0,-.04,.38], thL:[-.8,.4,.05], knL:[1.0,0,0], ftL:[-.2,0,0], thR:[.55,.15,-.06], knR:[.25,0,0] }, 'snap'),
      K(.47,{ hips:[0,-.15,0], chest:[.4,.0,0], spine:[.25,.05,0], uaR:[-1.05,-.1,-.1], elR:[-.2,0,0], uaL:[-1.0,.1,.3], elL:[-.5,0,0],
              lean:[.26,0,0], body:[0,-.04,.4], thL:[-.8,.4,.05], knL:[1.0,0,0], ftL:[-.2,0,0], thR:[.55,.15,-.06], knR:[.25,0,0] }, 'lin'),
      K(.74,{}) ] },
  spin: { tier:'heavy', dur:.70, act:[.20,.42], dmg:14, range:2.5, push:4.0, stun:.45, launch:0, lunge:[.1,.4,3.4], cancel:.4, energy:7, heavyHit:true,
    slash:{ roll:.0, flip:1, scale:2.0, arc:3.6, horizontal:true }, hand:'footR',
    keys:[ K(0,{}),
      K(.14,{ chest:[.06,-.5,0], hips:[0,-.9,0], uaL:[-.4,.2,.5], elL:[-1.4,0,0], uaR:[-.4,0,-.5], elR:[-1.4,0,0], thL:[-.7,.5,.05], knL:[1.4,0,0], ftL:[-.5,0,0], thR:[.4,.15,-.06], knR:[1.0,0,0], lean:[.05,0,0] }),
      K(.26,{ lean:[.0,-2.3,-.1], uaL:[-.2,0,1.3], elL:[-.2,0,0], uaR:[-.2,0,-1.3], elR:[-.2,0,0], thR:[-1.4,0,-.5], knR:[.2,0,0], ftR:[-.2,0,0], thL:[-.2,.5,.05], knL:[.5,0,0], chest:[.0,0,0], hips:[0,0,0] }, 'out'),
      K(.46,{ lean:[.0,-TAU,-.1], uaL:[-.2,0,1.3], elL:[-.2,0,0], uaR:[-.2,0,-1.3], elR:[-.2,0,0], thR:[-1.4,0,-.5], knR:[.2,0,0], ftR:[-.2,0,0], thL:[-.2,.5,.05], knL:[.5,0,0], chest:[.0,0,0], hips:[0,0,0] }, 'lin'),
      K(.70,{ lean:[0,-TAU,0] }) ] },

  // ---- specials
  wave: { tier:'special', dur:.70, act:[.34,.36], dmg:0, range:0, stun:0, cancel:99, energy:8, release:.33,
    keys:[ K(0,{}),
      K(.20,{ chest:[.06,-.55,0], hips:[0,-.85,0], uaL:[-.3,.8,.4], elL:[-1.6,0,0], uaR:[-.3,.7,-.2], elR:[-1.8,0,0], thL:[-.6,.5,.05], knL:[1.1,0,0], ftL:[-.5,0,0], lean:[.05,0,0], body:[0,0,-.08] }),
      K(.33,{ chest:[.0,.45,0], hips:[0,-.1,0], uaL:[-1.55,-.38,.1], elL:[-.1,0,0], uaR:[-1.5,-.5,-.1], elR:[-.1,0,0], thL:[-.7,.5,.05], knL:[.8,0,0], lean:[.12,0,0], body:[0,0,.2] }, 'snap'),
      K(.46,{ chest:[.0,.45,0], hips:[0,-.1,0], uaL:[-1.55,-.38,.1], elL:[-.1,0,0], uaR:[-1.5,-.5,-.1], elR:[-.1,0,0], thL:[-.7,.5,.05], knL:[.8,0,0], lean:[.12,0,0], body:[0,0,.2] }, 'lin'),
      K(.70,{}) ] },
  dash: { tier:'special', dur:.72, act:[.20,.40], dmg:8, range:2.3, push:3.0, stun:.4, cancel:99, energy:8, dashMove:[.18,.40,15.5], finisher:{ dmg:9, push:5.0, launch:5.5 },
    slash:{ roll:-.2, flip:1, scale:2.4, arc:2.7 }, hand:'R',
    keys:[ K(0,{}),
      K(.16,{ lean:[.28,0,0], body:[0,0,-.2], chest:[.1,-.6,0], hips:[0,-.9,0], uaR:[.5,.5,-.6], elR:[-.6,0,0], uaL:[-.9,.2,.3], elL:[-1.5,0,0], thL:[-.8,.5,.05], knL:[1.4,0,0], ftL:[-.6,0,0], thR:[.5,.15,-.06], knR:[1.0,0,0] }),
      K(.25,{ lean:[.62,0,0], body:[0,.15,.0], chest:[.0,.2,0], hips:[0,0,0], uaR:[-1.65,-.3,-.2], elR:[-.1,0,0], uaL:[.9,0,.3], elL:[-.3,0,0], thL:[-1.0,.5,.05], knL:[.5,0,0], thR:[.95,.15,-.06], knR:[.35,0,0], ftR:[.5,0,0], head:[-.3,.0,0] }, 'out'),
      K(.42,{ lean:[.4,0,0], body:[0,.05,.1], chest:[.1,-.5,0], hips:[0,.3,0], uaR:[-.9,-.9,-.4], elR:[-.2,0,0], uaL:[.5,0,.4], elL:[-.4,0,0], thL:[-.9,.5,.05], knL:[.7,0,0], thR:[.8,.15,-.06], knR:[.6,0,0] }, 'out'),
      K(.72,{}) ] },
  slam: { tier:'special', dur:.95, act:[.50,.52], dmg:17, range:3.3, push:5.0, stun:.55, launch:5.5, cancel:99, energy:8, aoe:true,
    slash:{ roll:0, flip:1, scale:2.5, arc:2.4, vertical:true }, hand:'R',
    keys:[ K(0,{}),
      K(.40,{ uaL:[-2.9,0,.25], uaR:[-2.9,0,-.25], elL:[-.3,0,0], elR:[-.3,0,0], chest:[-.4,.1,0], spine:[-.12,0,0], hips:[0,-.2,0], lean:[-.2,0,0], body:[0,.12,-.05], thL:[-.4,.5,.05], knL:[.4,0,0], thR:[.2,.15,-.06], knR:[.35,0,0] }),
      K(.50,{ uaL:[-.7,0,.3], uaR:[-.7,0,-.3], elL:[-.5,0,0], elR:[-.5,0,0], chest:[.65,.0,0], spine:[.32,0,0], hips:[0,-.1,0], lean:[.34,0,0], body:[0,-.08,.3], thL:[-1.0,.5,.05], knL:[1.7,0,0], ftL:[-.6,0,0], thR:[.6,.15,-.06], knR:[.4,0,0] }, 'snap'),
      K(.66,{ uaL:[-.7,0,.3], uaR:[-.7,0,-.3], elL:[-.5,0,0], elR:[-.5,0,0], chest:[.65,.0,0], spine:[.32,0,0], hips:[0,-.1,0], lean:[.34,0,0], body:[0,-.08,.3], thL:[-1.0,.5,.05], knL:[1.7,0,0], ftL:[-.6,0,0], thR:[.6,.15,-.06], knR:[.4,0,0] }, 'lin'),
      K(.95,{}) ] }
};
export const LIGHT_CHAIN = ['jab','cross','kick'];
export const HEAVY_MOVES = ['uppercut','cleave','spin'];
export const SPECIAL_MOVES = ['wave','dash','slam'];

/* ---------------------------------------------------------- STATIC POSES ---- */
export const POSES = {
  block: withPose(STANCE, { uaL:[-1.55,.2,.5], elL:[-2.35,0,0], uaR:[-1.5,.3,-.3], elR:[-2.45,0,0], chest:[.2,.0,0], spine:[.16,0,0], lean:[-.06,0,0],
                            thL:[-.6,.5,.05], knL:[1.1,0,0], ftL:[-.5,0,0], thR:[.4,.15,-.06], knR:[.9,0,0], ftR:[-.4,0,0], head:[.1,0,0] }),
  hitLight: withPose(STANCE, { chest:[-.35,-.1,0], spine:[-.15,0,0], head:[-.45,.0,0], neck:[-.15,0,0], uaL:[.3,0,.7], elL:[-.6,0,0], uaR:[.2,0,-.7], elR:[-.7,0,0],
                               body:[0,0,-.14], lean:[-.12,0,0], hips:[0,-.3,0], thL:[-.2,.5,.05], knL:[.4,0,0], thR:[.4,.15,-.06], knR:[.8,0,0] }),
  hitHeavy: withPose(STANCE, { chest:[-.6,-.2,.15], spine:[-.3,0,0], head:[-.7,.2,0], neck:[-.2,0,0], uaL:[.5,0,.9], elL:[-.4,0,0], uaR:[.4,0,-1.0], elR:[-.5,0,0],
                               body:[0,0,-.28], lean:[-.32,0,0], hips:[0,-.2,0], thL:[-.1,.5,.05], knL:[.3,0,0], thR:[.6,.15,-.06], knR:[1.0,0,0] }),
  airUp: withPose(STANCE, { thL:[-1.05,.3,.08], knL:[1.6,0,0], ftL:[-.2,0,0], thR:[-.3,.15,-.1], knR:[1.2,0,0], ftR:[.3,0,0],
                            uaL:[-.5,.2,.95], elL:[-.9,0,0], uaR:[-.6,.2,-.95], elR:[-.9,0,0], chest:[-.1,0,0], hips:[0,-.2,0], lean:[.0,0,0] }),
  airDown: withPose(STANCE, { thL:[-.45,.3,.1], knL:[.45,0,0], ftL:[.3,0,0], thR:[.15,.15,-.15], knR:[.35,0,0], ftR:[.4,0,0],
                              uaL:[-.2,.2,1.25], elL:[-.4,0,0], uaR:[-.2,.2,-1.25], elR:[-.4,0,0], chest:[.12,0,0], hips:[0,-.2,0] }),
  knockAir: withPose(STANCE, { lean:[-1.0,0,0], uaL:[.4,0,.9], elL:[-.3,0,0], uaR:[.4,0,-.9], elR:[-.3,0,0], head:[-.6,0,0], chest:[-.3,0,0],
                               thL:[-.7,.3,.1], knL:[.9,0,0], thR:[-.2,.15,-.15], knR:[.7,0,0], hips:[0,0,0] }),
  down: withPose(STANCE, { lean:[-1.52,0,0], body:[0,.14,0], uaL:[.5,0,.55], elL:[-.2,0,0], uaR:[.4,0,-.65], elR:[-.3,0,0], head:[-.15,0,0], chest:[0,0,0], hips:[0,0,0], spine:[0,0,0],
                           thL:[-.15,.1,.18], knL:[.35,0,0], ftL:[-.1,0,0], thR:[-.05,.1,-.22], knR:[.15,0,0], ftR:[.1,0,0], neck:[0,0,0] }),
  dashRun: withPose(STANCE, { lean:[.5,0,0], chest:[.15,-.2,0], thL:[-1.1,.4,.05], knL:[.9,0,0], thR:[.9,.1,-.06], knR:[.45,0,0], ftR:[.5,0,0], uaL:[.8,.2,.3], elL:[-.6,0,0], uaR:[-.4,.1,-.3], elR:[-1.2,0,0] }),
  victory: withPose(STANCE, { uaR:[-2.9,0,-.35], elR:[-.35,0,0], uaL:[-.3,0,.55], elL:[-.45,0,0], chest:[-.18,.0,0], spine:[-.05,0,0], head:[-.15,-.1,0], hips:[0,-.2,0],
                              thL:[-.2,.45,.12], knL:[.3,0,0], thR:[.1,.0,-.18], knR:[.3,0,0], ftL:[0,0,0], ftR:[.1,0,0], lean:[-.05,0,0] }),
  ultCharge: withPose(STANCE, { chest:[.12,0,0], spine:[.18,0,0], uaL:[.5,.0,.7], uaR:[.5,.0,-.7], elL:[-.7,0,0], elR:[-.7,0,0], head:[.05,0,0], hips:[0,-.2,0],
                                thL:[-.6,.3,.25], knL:[1.1,0,0], ftL:[-.5,0,0], thR:[.2,-.1,-.28], knR:[1.0,0,0], ftR:[-.8,0,0] }),
  ultRise: withPose(STANCE, { chest:[-.25,0,0], head:[-.35,0,0], uaL:[-2.4,0,1.0], uaR:[-2.4,0,-1.0], elL:[-.4,0,0], elR:[-.4,0,0], hips:[0,0,0], spine:[-.1,0,0],
                              thL:[-.2,.2,.18], knL:[.3,0,0], ftL:[.4,0,0], thR:[-.1,0,-.18], knR:[.25,0,0], ftR:[.4,0,0], body:[0,.35,0] }),
  ultSlashA: withPose(STANCE, { chest:[.1,.6,0], hips:[0,-.1,0], uaR:[-1.6,-.9,-.2], elR:[-.1,0,0], uaL:[.4,0,.5], elL:[-.8,0,0], lean:[.25,0,0], body:[0,.05,.3],
                                thL:[-.9,.5,.05], knL:[.9,0,0], thR:[.6,.15,-.06], knR:[.3,0,0] }),
  ultSlashB: withPose(STANCE, { chest:[.1,-.7,0], hips:[0,-1.0,0], uaL:[-1.6,.9,.2], elL:[-.1,0,0], uaR:[.4,0,-.5], elR:[-.8,0,0], lean:[.25,0,0], body:[0,.05,.3],
                                thR:[-1.0,.2,-.2], knR:[.6,0,0], thL:[.4,.5,.05], knL:[.3,0,0] }),
  ultFinish: withPose(STANCE, { chest:[.6,0,0], spine:[.3,0,0], uaL:[-.9,0,.4], uaR:[-.9,0,-.4], elL:[-.3,0,0], elR:[-.3,0,0], lean:[.55,0,0], body:[0,.55,.35],
                                thL:[-1.2,.4,.05], knL:[.8,0,0], thR:[.7,.1,-.06], knR:[.3,0,0], head:[-.2,0,0] })
};

export const GETUP_KEYS = [
  { t:0,   pose: POSES.down, ease:'io' },
  { t:.28, pose: withPose(STANCE, { lean:[-.85,0,0], body:[0,.45,-.2], uaL:[-.4,0,.5], uaR:[-.4,0,-.5], elL:[-.9,0,0], elR:[-.9,0,0], thL:[-1.2,.3,.1], knL:[1.9,0,0], thR:[.3,.1,-.2], knR:[1.9,0,0], chest:[.2,0,0] }), ease:'out' },
  { t:.55, pose: withPose(STANCE, { body:[0,-.05,0], chest:[.25,0,0], spine:[.25,0,0], thL:[-.7,.5,.05], knL:[1.3,0,0], thR:[.3,.15,-.06], knR:[1.0,0,0] }), ease:'out' },
  { t:.8,  pose: STANCE, ease:'io' }
];

/* --------------------------------------------------------- LOCOMOTION ----- */
// phase: walk cycle phase (signed: negative walks backwards). amt: 0..1 move intensity.
export function walkPose(out, phase, amt) {
  copyPose(out, STANCE);
  const s = Math.sin(phase), c = Math.cos(phase), a = amt;
  out.thL[0] = STANCE.thL[0] + s * .42 * a;      out.thR[0] = STANCE.thR[0] - s * .42 * a;
  out.knL[0] = STANCE.knL[0] - .25 * a + Math.max(0, c) * .75 * a;
  out.knR[0] = STANCE.knR[0] - .1 * a + Math.max(0, -c) * .75 * a;
  out.ftL[0] = flat(out.thL[0], out.knL[0]) - Math.max(0, c) * .2 * a;
  out.ftR[0] = flat(out.thR[0], out.knR[0]) + .1 + Math.max(0, -c) * .35 * a;
  out.chest[1] += s * .09 * a; out.hips[1] -= s * .06 * a;
  out.uaL[0] += -s * .1 * a; out.uaR[0] += s * .1 * a;
  out.body[1] = Math.abs(c) * .035 * a;
  out.lean[0] = .06 * a;
  return out;
}
