// vfx.js — anime-style combat effects, all procedural + additive (so the bloom pass makes them glow).
import * as THREE from 'https://cdn.jsdelivr.net/npm/three@0.169.0/build/three.module.js';

const TAU = Math.PI * 2;
const col = c => new THREE.Color(c);
const addMat = (extra = {}) => ({ transparent: true, blending: THREE.AdditiveBlending, depthWrite: false, side: THREE.DoubleSide, ...extra });
const VS_UV = 'varying vec2 vUv; void main(){ vUv=uv; gl_Position=projectionMatrix*modelViewMatrix*vec4(position,1.0); }';

/* ------------------------------------------------------------ particles ---- */
class Particles {
  constructor(scene, max = 3000) {
    this.max = max; this.head = 0;
    this.pos = new Float32Array(max * 3); this.c0 = new Float32Array(max * 3); this.c1 = new Float32Array(max * 3); this.colA = new Float32Array(max * 3);
    this.vel = new Float32Array(max * 3); this.life = new Float32Array(max); this.maxLife = new Float32Array(max); this.s0 = new Float32Array(max); this.s1 = new Float32Array(max);
    this.grav = new Float32Array(max); this.drag = new Float32Array(max); this.size = new Float32Array(max); this.alpha = new Float32Array(max);
    const g = this.geo = new THREE.BufferGeometry();
    this.attrs = {
      position: new THREE.BufferAttribute(this.pos, 3), aColor: new THREE.BufferAttribute(this.colA, 3),
      aSize: new THREE.BufferAttribute(this.size, 1), aAlpha: new THREE.BufferAttribute(this.alpha, 1)
    };
    for (const k in this.attrs) { this.attrs[k].setUsage(THREE.DynamicDrawUsage); g.setAttribute(k, this.attrs[k]); }
    this.uniforms = { uScale: { value: 600 } };
    this.mat = new THREE.ShaderMaterial({
      uniforms: this.uniforms, transparent: true, depthWrite: false, blending: THREE.AdditiveBlending,
      vertexShader: 'attribute vec3 aColor; attribute float aSize; attribute float aAlpha; varying vec3 vC; varying float vA; uniform float uScale;' +
        'void main(){ vC=aColor; vA=aAlpha; vec4 mv=modelViewMatrix*vec4(position,1.0); gl_PointSize=aSize*uScale/max(0.1,-mv.z); gl_Position=projectionMatrix*mv; }',
      fragmentShader: 'varying vec3 vC; varying float vA; void main(){ float d=length(gl_PointCoord-0.5); float a=smoothstep(0.5,0.0,d); a*=a; gl_FragColor=vec4(vC*(1.0+a*0.8)*1.5, a*vA); }'
    });
    this.points = new THREE.Points(g, this.mat); this.points.frustumCulled = false; scene.add(this.points);
  }
  emit(p, v, c0, c1, life, s0, s1, grav, drag) {
    const i = this.head, i3 = i * 3; this.head = (this.head + 1) % this.max;
    this.pos[i3] = p.x; this.pos[i3+1] = p.y; this.pos[i3+2] = p.z; this.vel[i3] = v.x; this.vel[i3+1] = v.y; this.vel[i3+2] = v.z;
    this.c0[i3] = c0.r; this.c0[i3+1] = c0.g; this.c0[i3+2] = c0.b; this.c1[i3] = c1.r; this.c1[i3+1] = c1.g; this.c1[i3+2] = c1.b;
    this.life[i] = this.maxLife[i] = life; this.s0[i] = s0; this.s1[i] = s1; this.grav[i] = grav; this.drag[i] = drag;
  }
  update(dt) {
    for (let i = 0; i < this.max; i++) {
      if (this.life[i] <= 0) { this.alpha[i] = 0; this.size[i] = 0; continue; }
      this.life[i] -= dt; const i3 = i * 3, t = 1 - Math.max(0, this.life[i]) / this.maxLife[i], dr = Math.max(0, 1 - this.drag[i] * dt);
      this.vel[i3] *= dr; this.vel[i3+1] = this.vel[i3+1] * dr - this.grav[i] * dt; this.vel[i3+2] *= dr;
      this.pos[i3] += this.vel[i3] * dt; this.pos[i3+1] += this.vel[i3+1] * dt; this.pos[i3+2] += this.vel[i3+2] * dt;
      this.colA[i3] = this.c0[i3] + (this.c1[i3] - this.c0[i3]) * t; this.colA[i3+1] = this.c0[i3+1] + (this.c1[i3+1] - this.c0[i3+1]) * t; this.colA[i3+2] = this.c0[i3+2] + (this.c1[i3+2] - this.c0[i3+2]) * t;
      this.size[i] = this.s0[i] + (this.s1[i] - this.s0[i]) * t; this.alpha[i] = Math.pow(1 - t, .7);
    }
    for (const k in this.attrs) this.attrs[k].needsUpdate = true;
  }
}

/* ---------------------------------------------------------------- trail ---- */
export class Trail {
  constructor(scene, color, color2, len = 16, life = .32) {
    this.len = len; this.life = life; this.started = false; this.active = false;
    this.pos = new Float32Array(len * 2 * 3); this.age = new Float32Array(len).fill(99);
    const g = this.geo = new THREE.BufferGeometry();
    this.posA = new THREE.BufferAttribute(this.pos, 3); this.posA.setUsage(THREE.DynamicDrawUsage);
    this.aA = new THREE.BufferAttribute(new Float32Array(len * 2), 1); this.aA.setUsage(THREE.DynamicDrawUsage);
    this.eA = new THREE.BufferAttribute(new Float32Array(len * 2), 1);
    for (let i = 0; i < len; i++) { this.eA.array[i*2] = 0; this.eA.array[i*2+1] = 1; }
    g.setAttribute('position', this.posA); g.setAttribute('aA', this.aA); g.setAttribute('aE', this.eA);
    const idx = []; for (let i = 0; i < len - 1; i++) { const a = i*2; idx.push(a, a+1, a+2, a+1, a+3, a+2); } g.setIndex(idx);
    this.mat = new THREE.ShaderMaterial({
      uniforms: { uC: { value: col(color) }, uC2: { value: col(color2 || color) } }, ...addMat(),
      vertexShader: 'attribute float aA; attribute float aE; varying float vA; varying float vE; void main(){ vA=aA; vE=aE; gl_Position=projectionMatrix*modelViewMatrix*vec4(position,1.0); }',
      fragmentShader: 'uniform vec3 uC; uniform vec3 uC2; varying float vA; varying float vE; void main(){ float e=1.0-abs(vE-0.5)*0.0; vec3 c=mix(uC2,uC,vA); c=mix(c,vec3(1.0),pow(vA,3.0)*0.6); gl_FragColor=vec4(c*1.7, vA*vA*0.9); }'
    });
    this.mesh = new THREE.Mesh(g, this.mat); this.mesh.frustumCulled = false; this.mesh.visible = false; scene.add(this.mesh);
  }
  setActive(a) { if (a && !this.active) this.started = false; this.active = a; }
  update(dt, tip, base) {
    let any = false;
    for (let i = 0; i < this.len; i++) this.age[i] += dt;
    if (this.active && tip) {
      if (!this.started) { for (let i = 0; i < this.len; i++) this.put(i, tip, base, 99); this.started = true; }
      for (let i = this.len - 1; i > 0; i--) { for (let k = 0; k < 6; k++) this.pos[i*6+k] = this.pos[(i-1)*6+k]; this.age[i] = this.age[i-1]; }
      this.put(0, tip, base, 0);
    }
    for (let i = 0; i < this.len; i++) { const a = Math.max(0, 1 - this.age[i] / this.life); this.aA.array[i*2] = this.aA.array[i*2+1] = a; if (a > 0) any = true; }
    this.mesh.visible = any; this.posA.needsUpdate = true; this.aA.needsUpdate = true;
  }
  put(i, tip, base, age) { const o = i * 6; this.pos[o] = tip.x; this.pos[o+1] = tip.y; this.pos[o+2] = tip.z; this.pos[o+3] = base.x; this.pos[o+4] = base.y; this.pos[o+5] = base.z; this.age[i] = age; }
}

/* ------------------------------------------------------------------ VFX ---- */
export class VFX {
  constructor(scene, camera, mount) {
    this.scene = scene; this.camera = camera; this.quality = 'medium'; this.list = []; this.time = 0;
    this.particles = new Particles(scene); this.aberr = 0; this.shake = 0; this.speed = 0;
    // screen overlays (CSS) ---------------------------------------------------
    const mk = (cls) => { const d = document.createElement('div'); d.className = cls; mount.appendChild(d); return d; };
    this.flashEl = mk('fx-flash'); this.speedEl = mk('fx-speed'); this.flashA = 0;
    this._v = new THREE.Vector3(); this._v2 = new THREE.Vector3();
  }
  setQuality(q) { this.quality = q; }
  setScale(px, fovDeg) { this.particles.uniforms.uScale.value = px / (2 * Math.tan(fovDeg * Math.PI / 360)); }
  q(n) { return Math.max(1, Math.round(n * (this.quality === 'low' ? .4 : this.quality === 'ultra' ? 1.6 : 1))); }
  add(obj, life, tick, done) { this.scene.add(obj); this.list.push({ obj, life, max: life, tick, done }); return obj; }

  /* generic particle burst */
  burst(pos, o = {}) {
    const n = this.q(o.n || 20), c0 = col(o.color || 0xffffff), c1 = col(o.color2 || o.color || 0xffffff), sp = o.speed || 3, up = o.up || 0, dir = o.dir, cone = o.cone == null ? 1 : o.cone;
    for (let i = 0; i < n; i++) {
      let x = Math.random() * 2 - 1, y = Math.random() * 2 - 1, z = Math.random() * 2 - 1; const l = Math.hypot(x, y, z) || 1; x /= l; y /= l; z /= l;
      if (dir) { x = dir.x + x * cone; y = dir.y + y * cone; z = dir.z + z * cone; }
      const s = sp * (.35 + Math.random() * .85); this._v.set(x * s, y * s + up, z * s);
      this.particles.emit(pos, this._v, c0, c1, (o.life || .6) * (.6 + Math.random() * .7), o.size || .12, o.sizeEnd == null ? .01 : o.sizeEnd, o.grav == null ? 4 : o.grav, o.drag == null ? 1.2 : o.drag);
    }
  }
  ring3(pos, color, o = {}) { // vertical-facing glowing ring of particles
    const n = this.q(o.n || 24), c = col(color);
    for (let i = 0; i < n; i++) { const a = i / n * TAU; this._v.set(Math.cos(a) * (o.speed || 4), (o.up || 0), Math.sin(a) * (o.speed || 4)); this.particles.emit(pos, this._v, c, col(o.color2 || color), o.life || .5, o.size || .14, .01, 0, 2.2); }
  }

  /* anime impact star + radial speed lines (billboard) */
  hitSpark(pos, color, scale = 1, color2 = 0xffffff) {
    const g = new THREE.Group(); g.position.copy(pos);
    const star = new THREE.Mesh(new THREE.PlaneGeometry(2, 2), new THREE.ShaderMaterial({
      uniforms: { uC: { value: col(color) }, uA: { value: 1 }, uN: { value: 5 + Math.floor(Math.random() * 3) * 1 }, uRot: { value: Math.random() * 6 } }, ...addMat(), vertexShader: VS_UV,
      fragmentShader: 'varying vec2 vUv; uniform vec3 uC; uniform float uA; uniform float uN; uniform float uRot;' +
        'void main(){ vec2 p=(vUv-0.5)*2.0; float r=length(p); float a=atan(p.y,p.x)+uRot; float R=0.16+0.84*pow(abs(cos(a*uN*0.5)),9.0);' +
        'float s=smoothstep(R,R*0.25,r); float core=smoothstep(0.32,0.0,r); vec3 c=mix(uC,vec3(1.0),core); gl_FragColor=vec4(c*2.0,(s+core)*uA); }'
    }));
    const lines = new THREE.Mesh(this.radialLines(18), new THREE.MeshBasicMaterial({ color: col(color2), ...addMat({ side: THREE.DoubleSide }) }));
    g.add(star, lines); g.quaternion.copy(this.camera.quaternion);
    this.add(g, .22 + .05 * scale, u => { const s = scale * (.4 + u * 1.7); star.scale.setScalar(s * (u < .15 ? u / .15 : 1)); star.material.uniforms.uA.value = 1 - u * u; lines.scale.setScalar(scale * (.6 + u * 2.4)); lines.material.opacity = 1 - u; g.quaternion.copy(this.camera.quaternion); star.rotation.z = u * 1.2; },
      () => { star.geometry.dispose(); star.material.dispose(); lines.geometry.dispose(); lines.material.dispose(); });
    this.burst(pos, { n: 16 * scale, color, color2, speed: 4.5 * scale, size: .1, life: .45, grav: 3 });
  }
  radialLines(n) {
    const pos = [], idx = [];
    for (let i = 0; i < n; i++) {
      const a = i / n * TAU + Math.random() * .2, r0 = .3 + Math.random() * .25, r1 = r0 + .5 + Math.random() * .8, w = .018 + Math.random() * .02;
      const c = Math.cos(a), s = Math.sin(a), b = pos.length / 3;
      pos.push(c * r0 - s * w, s * r0 + c * w, 0, c * r0 + s * w, s * r0 - c * w, 0, c * r1, s * r1, 0); idx.push(b, b + 1, b + 2);
    }
    const g = new THREE.BufferGeometry(); g.setAttribute('position', new THREE.Float32BufferAttribute(pos, 3)); g.setIndex(idx); return g;
  }

  /* crescent slash — dir: world XZ direction the attacker faces */
  slash(pos, dir, o = {}) {
    const arc = o.arc || 2.2, segs = 30, P = [], T = [], E = [], I = [], inner = o.thick == null ? .42 : o.thick;
    for (let i = 0; i <= segs; i++) {
      const t = i / segs, a = -arc / 2 + t * arc, th = Math.pow(Math.sin(Math.PI * Math.min(1, t * 1.02)), .75) * inner;
      P.push(Math.cos(a), Math.sin(a), 0, Math.cos(a) * (1 - th), Math.sin(a) * (1 - th), 0); T.push(t, t); E.push(1, 0);
      if (i < segs) { const b = i * 2; I.push(b, b + 1, b + 2, b + 1, b + 3, b + 2); }
    }
    const geo = new THREE.BufferGeometry(); geo.setAttribute('position', new THREE.Float32BufferAttribute(P, 3)); geo.setAttribute('aT', new THREE.Float32BufferAttribute(T, 1)); geo.setAttribute('aE', new THREE.Float32BufferAttribute(E, 1)); geo.setIndex(I);
    const mat = new THREE.ShaderMaterial({
      uniforms: { uHead: { value: 0 }, uFade: { value: 1 }, uC1: { value: col(o.color || 0xffffff) }, uC2: { value: col(o.color2 || 0xffffff) } }, ...addMat(),
      vertexShader: 'attribute float aT; attribute float aE; varying float vT; varying float vE; void main(){ vT=aT; vE=aE; gl_Position=projectionMatrix*modelViewMatrix*vec4(position,1.0); }',
      fragmentShader: 'varying float vT; varying float vE; uniform float uHead; uniform float uFade; uniform vec3 uC1; uniform vec3 uC2;' +
        'void main(){ float d=uHead-vT; float tail=d>=0.0?exp(-d*2.4):0.0; float edge=smoothstep(0.0,0.7,vE); float core=smoothstep(0.55,1.0,vE);' +
        'vec3 c=mix(uC1,uC2,core); c=mix(c,vec3(1.0),core*tail*0.8); gl_FragColor=vec4(c*2.0, tail*edge*uFade); }'
    });
    const g = new THREE.Group(); g.position.copy(pos); g.rotation.y = Math.atan2(-dir.z, dir.x);
    const inn = new THREE.Group(); const s = o.scale || 1.6; inn.scale.set(s, s * (o.flip || 1), 1); inn.rotation.z = o.roll || 0;
    if (o.horizontal) { inn.rotation.x = Math.PI / 2 - (o.tilt || .25); }
    inn.add(new THREE.Mesh(geo, mat)); g.add(inn);
    const dur = o.dur || .3;
    this.add(g, dur, u => { mat.uniforms.uHead.value = Math.min(1.3, u * 4.2); mat.uniforms.uFade.value = u < .35 ? 1 : Math.max(0, 1 - (u - .35) / .65); inn.scale.x = s * (1 + u * .12); },
      () => { geo.dispose(); mat.dispose(); });
  }

  ring(pos, color, o = {}) { // flat expanding shockwave on the ground
    const mat = new THREE.ShaderMaterial({
      uniforms: { uC: { value: col(color) }, uA: { value: 1 } }, ...addMat(), vertexShader: 'varying vec3 vP; void main(){ vP=position; gl_Position=projectionMatrix*modelViewMatrix*vec4(position,1.0); }',
      fragmentShader: 'varying vec3 vP; uniform vec3 uC; uniform float uA; void main(){ float r=length(vP.xy); float a=smoothstep(0.55,0.97,r)*(1.0-smoothstep(0.97,1.0,r)); vec3 c=mix(uC,vec3(1.0),smoothstep(0.9,1.0,r)*0.8); gl_FragColor=vec4(c*2.0,a*uA); }'
    });
    const m = new THREE.Mesh(new THREE.RingGeometry(.5, 1, 56), mat); m.rotation.x = -Math.PI / 2; m.position.copy(pos); m.position.y = o.y == null ? .04 : o.y;
    const R = o.radius || 3;
    this.add(m, o.dur || .5, u => { m.scale.setScalar(.2 + (1 - Math.pow(1 - u, 3)) * R); mat.uniforms.uA.value = 1 - u; }, () => { m.geometry.dispose(); mat.dispose(); });
  }

  pillar(pos, color, o = {}) { // energy column (power-up / ultimate)
    const h = o.h || 7, r = o.r || .9;
    const mat = new THREE.ShaderMaterial({
      uniforms: { uC: { value: col(color) }, uA: { value: 0 }, uT: { value: 0 } }, ...addMat(), vertexShader: VS_UV,
      fragmentShader: 'varying vec2 vUv; uniform vec3 uC; uniform float uA; uniform float uT; void main(){ float h=1.0-vUv.y; float st=0.55+0.45*sin(vUv.x*70.0+uT*9.0+vUv.y*12.0); st*=0.6+0.4*sin(vUv.x*23.0-uT*6.0); float a=pow(h,0.8)*(1.0-pow(vUv.y,4.0))*st*uA; gl_FragColor=vec4(mix(uC,vec3(1.0),h*h*0.6)*2.0,a); }'
    });
    const geo = new THREE.CylinderGeometry(r * .75, r, h, 32, 1, true); geo.translate(0, h / 2, 0);
    const m = new THREE.Mesh(geo, mat); m.position.copy(pos); m.position.y = .02;
    const dur = o.dur || 1;
    this.add(m, dur, u => { mat.uniforms.uT.value += .016; mat.uniforms.uA.value = Math.min(1, u * 6) * (1 - Math.pow(u, 3)) * .9; m.scale.set(1 + u * .4, 1, 1 + u * .4); }, () => { geo.dispose(); mat.dispose(); });
  }

  cracks(pos, color, n = 9, len = 2.6) {
    const g = new THREE.Group(); g.position.copy(pos); g.position.y = .03; const mats = [];
    for (let i = 0; i < n; i++) {
      const a = i / n * TAU + Math.random() * .4, l = len * (.5 + Math.random() * .6), m = new THREE.MeshBasicMaterial({ color: col(color).multiplyScalar(1.6), ...addMat() });
      const seg = new THREE.Mesh(new THREE.PlaneGeometry(.07, l), m); seg.rotation.x = -Math.PI / 2; seg.rotation.z = a; seg.position.set(Math.sin(-a) * l / 2, 0, Math.cos(-a) * l / 2 * 0); 
      const holder = new THREE.Group(); holder.rotation.y = a; seg.rotation.z = 0; seg.position.set(0, 0, l / 2); holder.add(seg); g.add(holder); mats.push(m);
    }
    this.add(g, 1.3, u => { for (const m of mats) m.opacity = u < .6 ? 1 : 1 - (u - .6) / .4; g.scale.setScalar(.3 + Math.min(1, u * 6) * .7); }, () => { g.traverse(o => { if (o.isMesh) { o.geometry.dispose(); o.material.dispose(); } }); });
  }

  debris(pos, n = 10, color = 0x2a3550) {
    n = this.q(n);
    for (let i = 0; i < n; i++) {
      const s = .06 + Math.random() * .12, m = new THREE.Mesh(new THREE.BoxGeometry(s, s * .7, s), new THREE.MeshBasicMaterial({ color, transparent: true }));
      m.position.copy(pos).add(this._v.set((Math.random() - .5) * 1.6, 0, (Math.random() - .5) * 1.6));
      const v = new THREE.Vector3((Math.random() - .5) * 4, 3 + Math.random() * 4, (Math.random() - .5) * 4), sp = new THREE.Vector3(Math.random() * 9, Math.random() * 9, Math.random() * 9);
      let t = 0; this.add(m, 1.1, (u) => { t = .016; v.y -= 14 * t; m.position.addScaledVector(v, t); if (m.position.y < .04) { m.position.y = .04; v.multiplyScalar(.4); v.y = Math.abs(v.y) * .3; } m.rotation.x += sp.x * t; m.rotation.y += sp.y * t; m.material.opacity = 1 - Math.pow(u, 3); }, () => { m.geometry.dispose(); m.material.dispose(); });
    }
  }

  lightning(a, b, color, o = {}) {
    const n = o.n || 9, pts = [];
    for (let i = 0; i <= n; i++) { const t = i / n, j = (i === 0 || i === n) ? 0 : (o.jit || .35); pts.push(new THREE.Vector3(a.x + (b.x - a.x) * t + (Math.random() - .5) * j, a.y + (b.y - a.y) * t + (Math.random() - .5) * j, a.z + (b.z - a.z) * t + (Math.random() - .5) * j)); }
    const geo = new THREE.BufferGeometry().setFromPoints(pts), mat = new THREE.LineBasicMaterial({ color: col(color).multiplyScalar(2), ...addMat() });
    this.add(new THREE.Line(geo, mat), o.dur || .14, u => { mat.opacity = 1 - u; }, () => { geo.dispose(); mat.dispose(); });
  }

  ghost(fighter, color, opacity = .5, life = .32) {
    const { group, mat } = fighter.makeGhost(color, opacity);
    this.add(group, life, u => { mat.opacity = opacity * (1 - u); group.scale.multiplyScalar(1.002); }, () => { mat.dispose(); });
  }

  /* projectile visual: returns {group, tick(dt)} */
  projectile(kind, color, color2, dir) {
    const g = new THREE.Group(), mats = [], geos = [];
    const basic = (c, b = 2) => { const m = new THREE.MeshBasicMaterial({ color: col(c).multiplyScalar(b), ...addMat() }); mats.push(m); return m; };
    const mesh = (geo, m) => { geos.push(geo); const o = new THREE.Mesh(geo, m); g.add(o); return o; };
    const core = mesh(new THREE.SphereGeometry(.28, 14, 10), basic(0xffffff, 2.2)); const halo = mesh(new THREE.SphereGeometry(.5, 14, 10), basic(color, 1.2)); halo.material.opacity = .45;
    const spin = [];
    if (kind === 'xSlash') {
      g.remove(core); g.remove(halo);
      for (const r of [.8, -.8]) { const bar = mesh(new THREE.BoxGeometry(.09, 1.7, .09), basic(color, 2)); bar.rotation.z = r; const edge = mesh(new THREE.BoxGeometry(.035, 1.75, .12), basic(0xffffff, 2.4)); edge.rotation.z = r; }
      const ring = mesh(new THREE.TorusGeometry(.8, .035, 6, 30), basic(color2, 1.6)); spin.push(ring);
    } else if (kind === 'glitchBeam') {
      g.remove(halo); const beam = mesh(new THREE.BoxGeometry(2.6, .22, .22), basic(color, 1.8)); beam.position.x = -.8; mesh(new THREE.BoxGeometry(3, .08, .08), basic(0xffffff, 2.4)).position.x = -.8;
      for (let i = 0; i < 6; i++) { const c = mesh(new THREE.BoxGeometry(.16, .16, .16), basic(i % 2 ? color : color2, 2)); c.position.set(-i * .45, (i % 2 ? .3 : -.3), 0); spin.push(c); }
    } else if (kind === 'qiPalm') {
      const r1 = mesh(new THREE.TorusGeometry(.55, .05, 6, 28), basic(color, 1.8)); const r2 = mesh(new THREE.TorusGeometry(.8, .035, 6, 28), basic(color2, 1.4)); r1.rotation.y = r2.rotation.y = Math.PI / 2; spin.push(r1, r2);
    } else if (kind === 'venom') {
      halo.material = basic(color, 1.0); halo.material.opacity = .5; for (let i = 0; i < 3; i++) { const t = mesh(new THREE.ConeGeometry(.12, .7, 5), basic(color, 1.8)); t.position.x = -.5 - i * .1; t.rotation.z = Math.PI / 2; t.rotation.x = i * 2; spin.push(t); }
    }
    g.rotation.y = Math.atan2(-dir.z, dir.x);
    return { group: g, spin, tick: (dt, t) => { for (const s of spin) s.rotation.x += dt * 9; core.scale.setScalar(1 + Math.sin(t * 30) * .12); }, dispose: () => { for (const m of mats) m.dispose(); for (const x of geos) x.dispose(); } };
  }

  /* screen-space */
  flash(color, a = .5) { this.flashEl.style.background = '#' + col(color).getHexString(); this.flashA = Math.max(this.flashA, a); }
  speedLines(on) { this.speed = on ? 1 : 0; }

  update(dt) {
    this.time += dt; this.particles.update(dt);
    for (let i = this.list.length - 1; i >= 0; i--) {
      const f = this.list[i]; f.life -= dt; const u = Math.min(1, 1 - f.life / f.max);
      if (f.tick) f.tick(u);
      if (f.life <= 0) { this.scene.remove(f.obj); if (f.done) f.done(); this.list.splice(i, 1); }
    }
    this.flashA = Math.max(0, this.flashA - dt * 3.2); this.flashEl.style.opacity = this.flashA.toFixed(3);
    this.aberr = Math.max(0, this.aberr - dt * 2.2);
    this.speedEl.style.opacity = this.speed ? '1' : '0';
  }
}
