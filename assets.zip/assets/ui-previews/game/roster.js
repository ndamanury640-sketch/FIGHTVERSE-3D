// roster.js — fighter definitions. `slug` (the key) is kept stable so database rows & asset folders still match;
// only the display names changed.
//
//  slug            old name       -> new name
//  inferno         Inferno        -> RYUGA     (Blaze Brawler)
//  frostbite       Frostbite      -> YUKINE    (Frost Swordmaiden)
//  volt            Volt           -> RAIKO     (Thunder Sprinter)
//  shadow-reaper   Shadow Reaper  -> KAGEMARU  (Shadow Shinobi)
//  titan           Titan          -> DAIGO     (Iron Giant)
//  cyber-x         Cyber-X        -> KAITO-X   (Cyber Blade Assassin)
//  jade-monk       Jade Monk      -> SEIRYU    (Jade Dragon Monk)
//  toxic-fang      Toxic Fang     -> KIBA      (Venom Striker)
//  glitch          Glitch         -> MIRAI     (Digital Idol Hacker)
//  storm-ronin     Storm Ronin    -> ARASHI    (Tempest Ronin)
//
// heavy:   'uppercut' | 'cleave' | 'spin'          special: 'wave' | 'dash' | 'slam'
export const ROSTER = {
  'inferno': {
    name: 'RYUGA', title: 'BLAZE BRAWLER', ult: 'PHOENIX DRIVE',
    desc: 'Petarung api bergauntlet bara dengan tinju menyala',
    skin: 0xf0bf9b, hair: 0xff4b1f, hairHi: 0xffb347, eye: 0xffa11a, outfit: 0x1d1a24, outfit2: 0x2b2330, accent: 0xff6a2a, glow: 0xff6a1f, glow2: 0xffd27a,
    hair_: { style: 'spikyUp', len: 1.15, sweep: [0, .55, -.7] },
    gear: ['vest', 'bracers', 'belt', 'headband', 'flameFists'], build: { bulk: 1.0, height: 1.0, brow: .22 },
    heavy: 'uppercut', special: 'wave', proj: 'fireball', fx: 'flame'
  },
  'frostbite': {
    name: 'YUKINE', title: 'FROST SWORDMAIDEN', ult: 'ABSOLUTE ZERO',
    desc: 'Pendekar es dengan bilah kristal dan langkah sedingin salju',
    skin: 0xfde4d6, hair: 0xcfeaff, hairHi: 0xffffff, eye: 0x4fd6ff, outfit: 0x28477a, outfit2: 0x1a2a4a, accent: 0xe4f7ff, glow: 0x59d8ff, glow2: 0xeaffff,
    hair_: { style: 'long', len: 1 }, gear: ['coat', 'kneeGuards', 'belt', 'iceKatana'], build: { bulk: .9, height: .98, brow: .05, female: true },
    heavy: 'cleave', special: 'dash', proj: 'iceStep', fx: 'ice'
  },
  'volt': {
    name: 'RAIKO', title: 'THUNDER SPRINTER', ult: 'THUNDER GOD STEP',
    desc: 'Petarung secepat kilat dengan jaket penuh listrik',
    skin: 0xeabb98, hair: 0xffe433, hairHi: 0xfffbb0, eye: 0xfff26a, outfit: 0x1f2438, outfit2: 0x171b2e, accent: 0xffd21f, glow: 0xfff23a, glow2: 0xffffff,
    hair_: { style: 'spikyUp', len: 1.3, sweep: [0, .8, -.35] }, gear: ['jacket', 'bracers', 'goggles', 'belt', 'sparkFists'], build: { bulk: .96, height: 1.0, brow: .18 },
    heavy: 'spin', special: 'dash', proj: 'lightning', fx: 'spark'
  },
  'shadow-reaper': {
    name: 'KAGEMARU', title: 'SHADOW SHINOBI', ult: 'VOID CRESCENT',
    desc: 'Shinobi bertopeng dengan dua kunai dan selendang bayangan',
    skin: 0xdcae90, hair: 0x2b2050, hairHi: 0x8a66ff, eye: 0xb86bff, outfit: 0x241b3f, outfit2: 0x17112b, accent: 0x8a63ff, glow: 0xa56bff, glow2: 0xe3c8ff,
    hair_: { style: 'messy', len: 1 }, gear: ['mask', 'scarf', 'wraps', 'belt', 'daggers'], build: { bulk: .93, height: 1.0, brow: .25 },
    heavy: 'spin', special: 'dash', proj: 'shadow', fx: 'void'
  },
  'titan': {
    name: 'DAIGO', title: 'IRON GIANT', ult: 'GIGA CRUSH',
    desc: 'Raksasa berbaju zirah yang menghancurkan lantai arena',
    skin: 0xd09d7a, hair: 0x3a2a22, hairHi: 0x8a6a50, eye: 0xffc65a, outfit: 0x6b7488, outfit2: 0x434a5c, accent: 0xe0a95b, glow: 0xffb44a, glow2: 0xfff0b0,
    hair_: { style: 'crop', len: 1 }, gear: ['armor', 'kneeGuards', 'belt', 'headband', 'bigFists'], build: { bulk: 1.34, height: 1.1, brow: .3 },
    heavy: 'uppercut', special: 'slam', proj: 'quake', fx: 'quake'
  },
  'cyber-x': {
    name: 'KAITO-X', title: 'CYBER BLADE ASSASSIN', ult: 'X-OVERLOAD',
    desc: 'Assassin siber berambut perak dengan dua bilah energi',
    skin: 0xf3d3bb, hair: 0xe9f3ff, hairHi: 0xffffff, eye: 0x37c8ff, outfit: 0x141b2d, outfit2: 0x0f1526, accent: 0x83dfff, glow: 0x2aa8ff, glow2: 0xbff0ff,
    hair_: { style: 'spikyUp', len: 1.05, sweep: [0, .45, -.9] }, gear: ['jacket', 'visor', 'xEmblem', 'reactor', 'bracers', 'belt', 'twinBlades'], build: { bulk: .97, height: 1.02, brow: .2 },
    heavy: 'cleave', special: 'wave', proj: 'xSlash', fx: 'cyber'
  },
  'jade-monk': {
    name: 'SEIRYU', title: 'JADE DRAGON MONK', ult: 'DRAGON ASCENT',
    desc: 'Biksu pendekar dengan energi giok dan manik pelindung',
    skin: 0xe3b189, hair: 0x1f6b52, hairHi: 0x6fe0a8, eye: 0x6dffb2, outfit: 0x2c9a72, outfit2: 0xe9e3c9, accent: 0xb7f7a1, glow: 0x43ffad, glow2: 0xdfffd0,
    hair_: { style: 'topknot', len: 1 }, gear: ['gi', 'sash', 'beads', 'wraps', 'jadeOrbs'], build: { bulk: 1.0, height: 1.0, brow: .12 },
    heavy: 'spin', special: 'wave', proj: 'qiPalm', fx: 'jade'
  },
  'toxic-fang': {
    name: 'KIBA', title: 'VENOM STRIKER', ult: 'VIPER STORM',
    desc: 'Penyerang lincah bercakar racun dan rambut liar',
    skin: 0xcfa680, hair: 0x18331c, hairHi: 0xa6ff3a, eye: 0xc8ff2a, outfit: 0x1e2c20, outfit2: 0x131c15, accent: 0xb7ff3a, glow: 0x9dff35, glow2: 0xf0ffb0,
    hair_: { style: 'spikyUp', len: 1.2, sweep: [0, .3, .5] }, gear: ['jacket', 'claws', 'belt'], build: { bulk: .98, height: 1.0, brow: .3 },
    heavy: 'cleave', special: 'wave', proj: 'venom', fx: 'venom'
  },
  'glitch': {
    name: 'MIRAI', title: 'DIGITAL IDOL HACKER', ult: 'SYSTEM CRASH',
    desc: 'Hacker idol digital dengan kubus data yang mengorbit',
    skin: 0xffe3d3, hair: 0xff4fd8, hairHi: 0x68f7ff, eye: 0x68f7ff, outfit: 0x2b1a49, outfit2: 0x1b1232, accent: 0x68f7ff, glow: 0xff4fd8, glow2: 0x9ffcff,
    hair_: { style: 'twin', len: 1 }, gear: ['jacket', 'headset', 'belt', 'bracers', 'pixelCubes'], build: { bulk: .9, height: .98, brow: .0, female: true },
    heavy: 'spin', special: 'wave', proj: 'glitchBeam', fx: 'glitch'
  },
  'storm-ronin': {
    name: 'ARASHI', title: 'TEMPEST RONIN', ult: 'TEMPEST IAI',
    desc: 'Ronin pengendali badai dengan katana secepat angin',
    skin: 0xdfb28f, hair: 0x2c3c66, hairHi: 0x9fc2ff, eye: 0x8ec8ff, outfit: 0x3a62b0, outfit2: 0x1c2744, accent: 0xe1e9ff, glow: 0x6da9ff, glow2: 0xe6f1ff,
    hair_: { style: 'ponytail', len: 1 }, gear: ['haori', 'sash', 'belt', 'katana'], build: { bulk: 1.0, height: 1.03, brow: .22 },
    heavy: 'cleave', special: 'dash', proj: 'tempest', fx: 'storm'
  }
};
export const SLUGS = Object.keys(ROSTER);
