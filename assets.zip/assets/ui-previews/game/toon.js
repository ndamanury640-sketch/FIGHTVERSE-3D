// toon.js — anime/cel shading helpers: toon material (+rim light), inverted-hull outline, geometry merging.
import * as THREE from 'https://cdn.jsdelivr.net/npm/three@0.169.0/build/three.module.js';

let _grad;
export function gradientMap() {
  if (_grad) return _grad;
  // 4-band cel ramp (soft shadow, shadow, light, highlight)
  const d = new Uint8Array([105,105,105,255, 170,170,170,255, 232,232,232,255, 255,255,255,255]);
  _grad = new THREE.DataTexture(d, 4, 1, THREE.RGBAFormat);
  _grad.minFilter = _grad.magFilter = THREE.NearestFilter;
  _grad.generateMipmaps = false; _grad.needsUpdate = true;
  return _grad;
}

export function toonMat(color, { rim = 0x9fd8ff, rimK = .5, side = THREE.FrontSide, emissive = 0x000000, emissiveIntensity = 1 } = {}) {
  const m = new THREE.MeshToonMaterial({ color, gradientMap: gradientMap(), side, emissive, emissiveIntensity });
  m.userData.outline = true;
  const uni = { uRim: { value: new THREE.Color(rim) }, uRimK: { value: rimK } };
  m.userData.rimUniforms = uni;
  m.onBeforeCompile = sh => {
    sh.uniforms.uRim = uni.uRim; sh.uniforms.uRimK = uni.uRimK;
    sh.fragmentShader = sh.fragmentShader
      .replace('#include <common>', '#include <common>\nuniform vec3 uRim;\nuniform float uRimK;')
      .replace('#include <emissivemap_fragment>',
        '#include <emissivemap_fragment>\n{ float fr = 1.0 - clamp(dot(normalize(normal), normalize(vViewPosition)), 0.0, 1.0); totalEmissiveRadiance += uRim * uRimK * smoothstep(0.56, 0.70, fr); }');
  };
  m.customProgramCacheKey = () => 'fv-toon-rim';
  return m;
}

// HDR basic material for glowing parts (values > 1 feed the bloom pass).
export function glowMat(color, boost = 1.8, extra = {}) {
  const m = new THREE.MeshBasicMaterial({ color: new THREE.Color(color).multiplyScalar(boost), ...extra });
  m.userData.outline = false; m.userData.base = new THREE.Color(color); m.userData.boost = boost;
  return m;
}

const _outlines = new Map();
export function outlineMat(thick, color = 0x0b0d1c) {
  const key = thick + '_' + color;
  if (_outlines.has(key)) return _outlines.get(key);
  const uni = { value: thick };
  const m = new THREE.MeshBasicMaterial({ color, side: THREE.BackSide });
  m.onBeforeCompile = sh => {
    sh.uniforms.uThick = uni;
    sh.vertexShader = sh.vertexShader
      .replace('#include <common>', '#include <common>\nuniform float uThick;')
      .replace('#include <begin_vertex>', 'vec3 transformed = vec3(position) + normalize(normal) * uThick;');
  };
  m.customProgramCacheKey = () => 'fv-outline';
  _outlines.set(key, m);
  return m;
}

// Bake a transform into a cloned geometry.
const _m4 = new THREE.Matrix4(), _q = new THREE.Quaternion(), _e = new THREE.Euler(), _v = new THREE.Vector3(), _s = new THREE.Vector3();
export function bake(geo, pos = [0,0,0], rot = [0,0,0], scl = [1,1,1]) {
  const g = geo.clone();
  _e.set(rot[0], rot[1], rot[2], 'YXZ'); _q.setFromEuler(_e);
  _m4.compose(_v.set(pos[0], pos[1], pos[2]), _q, _s.set(scl[0], scl[1], scl[2]));
  g.applyMatrix4(_m4);
  return g;
}

export function mergeGeos(list) {
  const gs = list.map(g => g.index ? g.toNonIndexed() : g);
  let total = 0; for (const g of gs) total += g.attributes.position.count;
  const pos = new Float32Array(total * 3), nor = new Float32Array(total * 3);
  let o = 0;
  for (const g of gs) {
    pos.set(g.attributes.position.array, o * 3);
    nor.set(g.attributes.normal.array, o * 3);
    o += g.attributes.position.count;
  }
  const out = new THREE.BufferGeometry();
  out.setAttribute('position', new THREE.BufferAttribute(pos, 3));
  out.setAttribute('normal', new THREE.BufferAttribute(nor, 3));
  return out;
}

// Average normals of coincident vertices so the outline hull has no cracks at hard edges.
export function smoothNormals(g) {
  const p = g.attributes.position.array, n = g.attributes.normal.array, cnt = p.length / 3;
  const acc = new Map(), keys = new Array(cnt);
  for (let i = 0; i < cnt; i++) {
    const k = Math.round(p[i*3]*1500) + '_' + Math.round(p[i*3+1]*1500) + '_' + Math.round(p[i*3+2]*1500);
    keys[i] = k;
    let a = acc.get(k); if (!a) { a = [0,0,0]; acc.set(k, a); }
    a[0] += n[i*3]; a[1] += n[i*3+1]; a[2] += n[i*3+2];
  }
  const out = new Float32Array(n.length);
  for (let i = 0; i < cnt; i++) {
    const a = acc.get(keys[i]), l = Math.hypot(a[0], a[1], a[2]) || 1;
    out[i*3] = a[0]/l; out[i*3+1] = a[1]/l; out[i*3+2] = a[2]/l;
  }
  const g2 = new THREE.BufferGeometry();
  g2.setAttribute('position', g.attributes.position);
  g2.setAttribute('normal', new THREE.BufferAttribute(out, 3));
  return g2;
}

// Collects parts that belong to one joint, then emits one merged mesh per material + one outline hull.
export class PartBuilder {
  constructor() { this.parts = []; }
  add(geo, material, pos, rot, scl, outline = true) {
    this.parts.push({ g: bake(geo, pos, rot, scl), m: material, outline: outline && material.userData.outline !== false });
    return this;
  }
  build(parent, thick = .028, { cast = true, outlineColor } = {}) {
    if (!this.parts.length) return;
    const byMat = new Map();
    for (const p of this.parts) { if (!byMat.has(p.m)) byMat.set(p.m, []); byMat.get(p.m).push(p.g); }
    for (const [m, list] of byMat) {
      const mesh = new THREE.Mesh(mergeGeos(list), m);
      mesh.castShadow = cast; mesh.receiveShadow = false;
      parent.add(mesh);
    }
    const hull = this.parts.filter(p => p.outline).map(p => p.g);
    if (hull.length && thick > 0) {
      const o = new THREE.Mesh(smoothNormals(mergeGeos(hull)), outlineMat(thick, outlineColor));
      o.userData.outline = true; o.castShadow = false;
      parent.add(o);
    }
  }
}
