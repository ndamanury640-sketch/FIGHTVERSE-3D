// arenas.js — selectable battle stages. Each builder returns { env, update(dt,t), group }.
// env drives scene background/fog/lights; update() animates props (petals, aurora, lava, lightning...).
import * as THREE from 'https://cdn.jsdelivr.net/npm/three@0.169.0/build/three.module.js';

export const ARENA_LIST = [
  { id: 'crimson-dojo',   name: 'CRIMSON DOJO',      desc: 'Dojo senja dengan gerbang torii, lentera, dan kelopak sakura.' },
  { id: 'frozen-citadel', name: 'FROZEN CITADEL',    desc: 'Benteng es di bawah aurora, lantai kristal, salju turun.' },
  { id: 'volcano-forge',  name: 'VOLCANO FORGE',     desc: 'Lantai obsidian retak, sungai lava, bara beterbangan.' },
  { id: 'storm-peak',     name: 'STORM PEAK TEMPLE', desc: 'Kuil di puncak badai, petir menyambar dan hujan deras.' },
  { id: 'digital-void',   name: 'DIGITAL VOID',      desc: 'Dunia data dengan portal raksasa dan hujan kode.' },
  { id: 'neon-rift',      name: 'NEON RIFT',         desc: 'Arena kota neon klasik.' }
];

const std = (color, roughness = .5, metalness = .2, extra = {}) => new THREE.MeshStandardMaterial({ color, roughness, metalness, ...extra });
const hdr = (c, k = 1.8, extra = {}) => new THREE.MeshBasicMaterial({ color: new THREE.Color(c).multiplyScalar(k), ...extra });
const addMat = (extra = {}) => ({ transparent: true, blending: THREE.AdditiveBlending, depthWrite: false, side: THREE.DoubleSide, ...extra });
const rngFor = seed => { let s = seed; return () => (s = (s * 16807) % 2147483647) / 2147483647; };

function put(parent, geo, mat, pos = [0, 0, 0], rot = [0, 0, 0], scl = [1, 1, 1], shadow = false) {
  const m = new THREE.Mesh(geo, mat); m.position.set(pos[0], pos[1], pos[2]); m.rotation.set(rot[0], rot[1], rot[2]); m.scale.set(scl[0], scl[1], scl[2]);
  m.castShadow = shadow; m.receiveShadow = false; parent.add(m); return m;
}
function floorPlane(g, color, rough = .4, metal = .4, w = 30, d = 22) {
  const f = put(g, new THREE.PlaneGeometry(w, d), std(color, rough, metal), [0, -.03, 0], [-Math.PI / 2, 0, 0]); f.receiveShadow = true; return f;
}
function skyPlane(g, top, bot, z = -34, w = 160, h = 80, y = 16) {
  const m = new THREE.ShaderMaterial({ uniforms: { uT: { value: new THREE.Color(top) }, uB: { value: new THREE.Color(bot) } }, fog: false, depthWrite: false,
    vertexShader: 'varying vec2 vUv; void main(){ vUv=uv; gl_Position=projectionMatrix*modelViewMatrix*vec4(position,1.0); }',
    fragmentShader: 'varying vec2 vUv; uniform vec3 uT; uniform vec3 uB; void main(){ gl_FragColor=vec4(mix(uB,uT,pow(vUv.y,0.8)),1.0); }' });
  return put(g, new THREE.PlaneGeometry(w, h), m, [0, y, z]);
}
// drifting particle field; vel [x,y,z]; wobble sideways
function field(g, n, o) {
  const pos = new Float32Array(n * 3), rnd = rngFor(o.seed || 3), [ax, ay, az] = o.area, [cx, cy, cz] = o.center || [0, 0, 0], ph = new Float32Array(n);
  for (let i = 0; i < n; i++) { pos[i*3] = cx + (rnd() - .5) * ax; pos[i*3+1] = cy + rnd() * ay; pos[i*3+2] = cz + (rnd() - .5) * az; ph[i] = rnd() * 6; }
  const geo = new THREE.BufferGeometry(); const attr = new THREE.BufferAttribute(pos, 3); geo.setAttribute('position', attr);
  const mat = new THREE.PointsMaterial({ color: new THREE.Color(o.color).multiplyScalar(o.boost || 1), size: o.size || .1, transparent: true, opacity: o.opacity || .9, blending: THREE.AdditiveBlending, depthWrite: false, sizeAttenuation: true });
  const pts = new THREE.Points(geo, mat); pts.frustumCulled = false; g.add(pts);
  let t = 0;
  return { pts, update(dt) {
    t += dt; const v = o.vel;
    for (let i = 0; i < n; i++) {
      const k = i * 3; pos[k] += (v[0] + Math.sin(t * (o.wob || 1) + ph[i]) * (o.wobble || 0)) * dt; pos[k+1] += v[1] * dt; pos[k+2] += (v[2] + Math.cos(t * .8 + ph[i]) * (o.wobble || 0) * .5) * dt;
      if (pos[k+1] < cy - 1 || pos[k+1] > cy + ay + 1) pos[k+1] = v[1] < 0 ? cy + ay : cy; if (pos[k] < cx - ax / 2) pos[k] += ax; else if (pos[k] > cx + ax / 2) pos[k] -= ax;
    }
    attr.needsUpdate = true;
  } };
}
function shaderBand(color, speed = .6, freq = 7) {
  return new THREE.ShaderMaterial({ uniforms: { uC: { value: new THREE.Color(color) }, uT: { value: 0 } }, ...addMat(), fog: false,
    vertexShader: 'varying vec2 vUv; void main(){ vUv=uv; gl_Position=projectionMatrix*modelViewMatrix*vec4(position,1.0); }',
    fragmentShader: `varying vec2 vUv; uniform vec3 uC; uniform float uT; void main(){ float w=sin(vUv.x*${freq.toFixed(1)}+uT*${speed.toFixed(2)}+sin(vUv.x*3.0+uT*.7)*2.0); float a=(0.45+0.55*w)*smoothstep(0.0,0.25,vUv.y)*(1.0-smoothstep(0.35,1.0,vUv.y)); a*=0.5+0.5*sin(vUv.x*40.0+uT*2.0)*0.4+0.2; gl_FragColor=vec4(uC*1.5,a*0.55); }` });
}

/* ------------------------------------------------------------- CRIMSON DOJO ---- */
function crimsonDojo(scene) {
  const g = new THREE.Group(); scene.add(g); const R = rngFor(11);
  skyPlane(g, 0x1c0b2a, 0xff7a3a);
  put(g, new THREE.CircleGeometry(6, 48), hdr(0xffd27a, 1.5, { fog: false }), [0, 6.5, -30]);
  put(g, new THREE.CircleGeometry(10, 48), hdr(0xff8a3d, .6, { fog: false, transparent: true, opacity: .4 }), [0, 6.5, -30.5]);
  for (let i = 0; i < 9; i++) put(g, new THREE.ConeGeometry(5 + R() * 5, 8 + R() * 8, 5), std(0x2a0f24, .9, 0), [-34 + i * 8.5, 3, -24 - R() * 4]);
  const wood = std(0x4a2418, .8, .1), light = std(0x6a3a26, .8, .1);
  floorPlane(g, 0x3a1c14, .7, .15);
  for (let i = -6; i <= 6; i++) put(g, new THREE.BoxGeometry(.04, .01, 22), std(0x24100c, .9, 0), [i * 2, 0, 0]);
  for (let i = -5; i <= 5; i++) put(g, new THREE.BoxGeometry(30, .01, .03), std(0x24100c, .9, 0), [0, 0, i * 2]);
  const red = std(0xc4262e, .5, .2, { emissive: 0x3a0508, emissiveIntensity: .8 });
  for (const s of [-1, 1]) put(g, new THREE.CylinderGeometry(.34, .4, 7.2, 14), red, [s * 4.6, 3.6, -7.5], [0, 0, 0], [1, 1, 1], true);
  put(g, new THREE.BoxGeometry(12.6, .45, .8), red, [0, 7, -7.5]); put(g, new THREE.BoxGeometry(10.6, .3, .6), red, [0, 6.1, -7.5]); put(g, new THREE.BoxGeometry(1, 1.2, .5), std(0x1a0a0a), [0, 6.6, -7.5]);
  put(g, new THREE.BoxGeometry(13.6, .2, 1.2), std(0x1a0a0a), [0, 7.4, -7.5]);
  const lanterns = [];
  for (let i = 0; i < 8; i++) { const x = -11 + i * 3.15, y = 4.6 + (i % 2) * .5; put(g, new THREE.CylinderGeometry(.02, .02, 5 - y + 3, 4), std(0x111111), [x, y + 1.4, -5]);
    const l = put(g, new THREE.SphereGeometry(.36, 12, 10), hdr(i % 3 ? 0xff5a3a : 0xffb347, 1.7), [x, y, -5], [0, 0, 0], [1, 1.25, 1]); lanterns.push(l); }
  for (const s of [-1, 1]) for (let i = 0; i < 3; i++) put(g, new THREE.CylinderGeometry(.3, .3, 5.2, 12), wood, [s * (9 + i * 2.4), 2.6, -4 + i * -1.8], [0, 0, 0], [1, 1, 1], true);
  put(g, new THREE.BoxGeometry(30, .3, .6), light, [0, 5.4, -9]);
  const petals = field(g, 160, { area: [26, 12, 16], center: [0, 0, -2], color: 0xffa6c4, boost: 1.1, size: .16, vel: [.5, -.8, .1], wobble: 1.1, wob: 1.2, seed: 5 });
  return { group: g, env: { bg: 0x2a0f1e, fog: [0x3a1428, .02], hemi: [0xffb59a, 0x2a1020, 1.3], key: [0xffd2a8, 2.4], rim1: [0xff6a4a, 1.5], rim2: [0xffa05a, 1], exposure: 1.15 },
    update(dt, t) { petals.update(dt); lanterns.forEach((l, i) => { l.position.y += Math.sin(t * 1.6 + i) * .002; l.scale.y = 1.25 + Math.sin(t * 3 + i * 2) * .04; }); } };
}

/* ----------------------------------------------------------- FROZEN CITADEL ---- */
function frozenCitadel(scene) {
  const g = new THREE.Group(); scene.add(g); const R = rngFor(21);
  skyPlane(g, 0x040a1e, 0x1b6a8a);
  const bands = [[0x3dffb0, -26, 14, 60, .5, 6], [0xa56bff, -28, 17, 70, .35, 5], [0x59d8ff, -25, 11, 50, .6, 8]].map(([c, z, y, w, sp, fr]) => { const m = shaderBand(c, sp, fr); put(g, new THREE.PlaneGeometry(w, 16), m, [0, y, z]); return m; });
  // citadel silhouette
  const dark = std(0x0a2238, .6, .3);
  for (const [x, w, h] of [[-9, 3, 9], [-5, 2.2, 12], [0, 4, 15], [5.5, 2.4, 11], [10, 3.2, 8]]) { put(g, new THREE.BoxGeometry(w, h, 2.2), dark, [x, h / 2, -15]); for (let j = 1; j < h / 2; j++) put(g, new THREE.BoxGeometry(.25, .5, .05), hdr(0x7ae0ff, 1.3), [x + (j % 2 ? .4 : -.4), j * 1.6, -13.85]); }
  put(g, new THREE.ConeGeometry(2.2, 5, 4), dark, [0, 17.5, -15]);
  const ice = std(0x7fd0ff, .12, .5, { emissive: 0x0b4a7a, emissiveIntensity: .9, transparent: true, opacity: .92 });
  const f = floorPlane(g, 0x8fd0ff, .06, .75); f.material.emissive = new THREE.Color(0x0a2a44); f.material.emissiveIntensity = .5;
  for (let i = 0; i < 14; i++) { const a = R() * 6.28, x = Math.cos(a) * (6 + R() * 6), z = -2 - Math.abs(Math.sin(a)) * 8; if (Math.abs(x) < 3.5 && z > -5) continue; const h = 1.8 + R() * 5; put(g, new THREE.ConeGeometry(.55 + R() * .6, h, 5), ice, [x, h / 2, z], [0, R() * 3, (R() - .5) * .25], [1, 1, 1], true); }
  const crystals = []; for (let i = 0; i < 5; i++) { const c = put(g, new THREE.OctahedronGeometry(.4, 0), hdr(0xbff0ff, 1.7), [-8 + i * 4, 4 + R() * 3, -8 - R() * 3]); crystals.push(c); }
  const snow = field(g, 220, { area: [30, 14, 20], center: [0, 0, -3], color: 0xffffff, size: .09, vel: [.15, -.9, 0], wobble: .5, seed: 8 });
  return { group: g, env: { bg: 0x06122a, fog: [0x0b2a46, .024], hemi: [0xaee0ff, 0x10304a, 1.7], key: [0xe6f6ff, 2.6], rim1: [0x6fd8ff, 1.8], rim2: [0xa56bff, 1.2], exposure: 1.2 },
    update(dt, t) { snow.update(dt); bands.forEach(m => { m.uniforms.uT.value = t; }); crystals.forEach((c, i) => { c.rotation.y += dt * (1 + i * .2); c.position.y += Math.sin(t * 1.4 + i) * .004; }); } };
}

/* ------------------------------------------------------------ VOLCANO FORGE ---- */
function volcanoForge(scene) {
  const g = new THREE.Group(); scene.add(g); const R = rngFor(31);
  skyPlane(g, 0x0a0305, 0x8a2410);
  put(g, new THREE.ConeGeometry(12, 14, 7), std(0x1a0a0c, .9, .1), [0, 7, -24]);
  const crater = put(g, new THREE.ConeGeometry(3.2, 1.6, 7), hdr(0xff5a1a, 1.6), [0, 14.6, -24]);
  put(g, new THREE.CircleGeometry(14, 32), hdr(0xff4a1a, .8, { fog: false, transparent: true, opacity: .35 }), [0, 16, -26]);
  const rock = std(0x14070a, .85, .15, { emissive: 0x2a0a04, emissiveIntensity: .4 });
  const floor = floorPlane(g, 0x120809, .5, .5);
  const cracks = [], crackMat = hdr(0xff6a1a, 1.7);
  for (let i = 0; i < 26; i++) { const x = (R() - .5) * 22, z = (R() - .5) * 16, l = 1.2 + R() * 3; cracks.push(put(g, new THREE.BoxGeometry(.07, .02, l), crackMat, [x, .01, z], [0, R() * 3.14, 0])); }
  const lava = new THREE.ShaderMaterial({ uniforms: { uT: { value: 0 } }, fog: false, vertexShader: 'varying vec2 vUv; void main(){ vUv=uv; gl_Position=projectionMatrix*modelViewMatrix*vec4(position,1.0); }',
    fragmentShader: 'varying vec2 vUv; uniform float uT; void main(){ float n=sin(vUv.x*14.0+uT*.9)*.5+sin(vUv.y*20.0-uT*1.3+vUv.x*6.0)*.5; vec3 c=mix(vec3(.9,.18,.02),vec3(1.0,.8,.25),smoothstep(-.4,.9,n)); gl_FragColor=vec4(c*1.4,1.0); }' });
  for (const s of [-1, 1]) put(g, new THREE.PlaneGeometry(5, 22), lava, [s * 10.5, .02, 0], [-Math.PI / 2, 0, 0]);
  put(g, new THREE.PlaneGeometry(34, 4), lava, [0, .02, -10], [-Math.PI / 2, 0, 0]);
  for (let i = 0; i < 11; i++) { const x = -15 + i * 3 + R(), h = 3 + R() * 6; put(g, new THREE.ConeGeometry(.9 + R() * .8, h, 5), rock, [x, h / 2, -7 - R() * 3], [0, R() * 3, 0], [1, 1, 1], true); }
  const embers = field(g, 200, { area: [30, 14, 18], center: [0, 0, -3], color: 0xff8a2a, boost: 1.5, size: .12, vel: [.2, 1.1, 0], wobble: .8, seed: 13 });
  return { group: g, env: { bg: 0x12060a, fog: [0x2a0a0c, .028], hemi: [0xff8a5a, 0x2a0808, 1], key: [0xffb27a, 2.2], rim1: [0xff4a1a, 2.4], rim2: [0xff7a2a, 1.8], exposure: 1.1 },
    update(dt, t) { embers.update(dt); lava.uniforms.uT.value = t; const p = 1.5 + Math.sin(t * 2.4) * .4; crackMat.color.setRGB(1 * p, .42 * p, .1 * p); crater.scale.y = 1 + Math.sin(t * 3) * .1; } };
}

/* --------------------------------------------------------------- STORM PEAK ---- */
function stormPeak(scene, ctx) {
  const g = new THREE.Group(); scene.add(g); const R = rngFor(41);
  skyPlane(g, 0x04060c, 0x2a3a52);
  const clouds = []; for (let i = 0; i < 12; i++) { const c = put(g, new THREE.SphereGeometry(1, 10, 8), std(0x0e1522, 1, 0, { transparent: true, opacity: .9 }), [(i - 6) * 7 + R() * 3, 11 + R() * 7, -24 - R() * 6], [0, 0, 0], [7 + R() * 5, 2.2 + R(), 3]); clouds.push(c); }
  const stone = std(0x8b97ad, .75, .12), floorM = floorPlane(g, 0x2a3446, .35, .5);
  const rune = new THREE.ShaderMaterial({ uniforms: { uT: { value: 0 } }, ...addMat(), vertexShader: 'varying vec3 vP; void main(){ vP=position; gl_Position=projectionMatrix*modelViewMatrix*vec4(position,1.0); }',
    fragmentShader: 'varying vec3 vP; uniform float uT; void main(){ float r=length(vP.xy); float a=smoothstep(.93,.97,r)*(1.0-smoothstep(.97,1.0,r)); a+=smoothstep(.6,.62,r)*(1.0-smoothstep(.62,.64,r))*.7; float ang=atan(vP.y,vP.x); a*=.6+.4*sin(ang*18.0+uT*2.0); gl_FragColor=vec4(vec3(.45,.85,1.0)*1.8,a); }' });
  put(g, new THREE.CircleGeometry(7, 64), rune, [0, .03, 0], [-Math.PI / 2, 0, 0]);
  for (const s of [-1, 1]) for (let i = 0; i < 3; i++) { const x = s * (7 + i * 2.6), h = 6 - i * 1.2 - (i === 2 ? 1.5 : 0); put(g, new THREE.CylinderGeometry(.55, .65, h, 14), stone, [x, h / 2, -4 - i * 1.4], [0, 0, 0], [1, 1, 1], true); put(g, new THREE.BoxGeometry(1.5, .35, 1.5), stone, [x, h + .15, -4 - i * 1.4]); }
  put(g, new THREE.BoxGeometry(6.2, .5, 1.4), stone, [-9.6, 6.5, -4]); put(g, new THREE.BoxGeometry(6.2, .5, 1.4), stone, [9.6, 6.5, -4]);
  const rocks = []; for (let i = 0; i < 6; i++) rocks.push(put(g, new THREE.OctahedronGeometry(.7 + R() * .6, 0), std(0x3a4660, .9, .1), [-12 + i * 5, 5 + R() * 5, -12 - R() * 4]));
  const rain = field(g, 320, { area: [30, 16, 20], center: [0, 0, -3], color: 0xa8c8ff, size: .07, opacity: .6, vel: [-1.2, -16, 0], seed: 17 });
  const flashMat = new THREE.MeshBasicMaterial({ color: 0xcfe6ff, transparent: true, opacity: 0, depthWrite: false, fog: false }); put(g, new THREE.PlaneGeometry(160, 80), flashMat, [0, 16, -33]);
  let bolt = null, boltLife = 0, next = 2 + R() * 3;
  const strike = () => {
    const pts = []; let x = (R() - .5) * 16, y = 22; const tx = x + (R() - .5) * 4; for (let i = 0; i <= 10; i++) { pts.push(new THREE.Vector3(x, y, -12)); x += (R() - .5) * 2.2 + (tx - x) * .12; y -= 2.2; }
    if (bolt) { g.remove(bolt); bolt.geometry.dispose(); }
    bolt = new THREE.Line(new THREE.BufferGeometry().setFromPoints(pts), new THREE.LineBasicMaterial({ color: new THREE.Color(0xdff0ff).multiplyScalar(2.2), transparent: true, blending: THREE.AdditiveBlending })); g.add(bolt); boltLife = .22;
    if (ctx && ctx.flash) ctx.flash(1);
  };
  return { group: g, env: { bg: 0x0a0f1a, fog: [0x121a2a, .03], hemi: [0x9fb8e0, 0x141a28, 1.2], key: [0xdce8ff, 2.2], rim1: [0x6fb0ff, 1.8], rim2: [0x8a8aff, 1], exposure: 1.05 },
    update(dt, t) {
      rain.update(dt); rune.uniforms.uT.value = t; clouds.forEach((c, i) => { c.position.x += Math.sin(t * .1 + i) * .004; });
      rocks.forEach((r, i) => { r.rotation.y += dt * .4; r.position.y += Math.sin(t * .8 + i) * .004; });
      next -= dt; if (next <= 0) { strike(); next = 2.5 + R() * 4; }
      if (boltLife > 0) { boltLife -= dt; flashMat.opacity = Math.max(0, boltLife / .22) * .35; if (bolt) bolt.material.opacity = Math.min(1, boltLife / .12); if (boltLife <= 0 && bolt) { g.remove(bolt); bolt.geometry.dispose(); bolt = null; flashMat.opacity = 0; } }
    } };
}

/* ------------------------------------------------------------- DIGITAL VOID ---- */
function digitalVoid(scene) {
  const g = new THREE.Group(); scene.add(g); const R = rngFor(51);
  skyPlane(g, 0x02030a, 0x1a0a3a);
  const portal = put(g, new THREE.TorusGeometry(5, .16, 10, 72), hdr(0xff4fd8, 1.9, { fog: false }), [0, 6.5, -14]);
  const portal2 = put(g, new THREE.TorusGeometry(3.6, .1, 8, 60), hdr(0x68f7ff, 1.8, { fog: false }), [0, 6.5, -14]);
  const core = put(g, new THREE.CircleGeometry(3.4, 40), hdr(0x68f7ff, .6, { fog: false, transparent: true, opacity: .22 }), [0, 6.5, -14.1]);
  floorPlane(g, 0x070a1c, .3, .7);
  const grid = new THREE.GridHelper(30, 60, 0x68f7ff, 0x1b2a6a); grid.position.y = .01; g.add(grid);
  const pulse = put(g, new THREE.RingGeometry(.95, 1, 64), hdr(0x68f7ff, 1.8, { transparent: true, opacity: .8, side: THREE.DoubleSide }), [0, .05, 0], [-Math.PI / 2, 0, 0]);
  const streams = field(g, 260, { area: [34, 18, 12], center: [0, 0, -9], color: 0x3dffb0, boost: 1.5, size: .12, vel: [0, -4.5, 0], wobble: 0, seed: 23 });
  const streams2 = field(g, 90, { area: [34, 18, 12], center: [0, 0, -9], color: 0x68f7ff, boost: 1.6, size: .2, vel: [0, -2.2, 0], seed: 29 });
  const cubes = []; for (let i = 0; i < 14; i++) cubes.push(put(g, new THREE.BoxGeometry(.7, .7, .7), new THREE.MeshBasicMaterial({ color: new THREE.Color(i % 2 ? 0xff4fd8 : 0x68f7ff).multiplyScalar(1.6), wireframe: true }), [(R() - .5) * 28, 1 + R() * 9, -4 - R() * 9], [R() * 3, R() * 3, 0], [1 + R(), 1 + R(), 1 + R()]));
  for (const s of [-1, 1]) for (let i = 0; i < 2; i++) { put(g, new THREE.CylinderGeometry(.35, .35, 6, 6), std(0x0a1030, .4, .8), [s * (8 + i * 3), 3, -4 - i * 2], [0, 0, 0], [1, 1, 1], true); put(g, new THREE.TorusGeometry(.5, .05, 6, 20), hdr(s < 0 ? 0x68f7ff : 0xff4fd8, 1.8), [s * (8 + i * 3), 1.5 + i, -4 - i * 2], [Math.PI / 2, 0, 0]); }
  let pt = 0;
  return { group: g, env: { bg: 0x04050e, fog: [0x080a1c, .02], hemi: [0x8aa0ff, 0x10082a, 1.3], key: [0xe6e0ff, 2.3], rim1: [0x68f7ff, 2], rim2: [0xff4fd8, 1.8], exposure: 1.15 },
    update(dt, t) {
      streams.update(dt); streams2.update(dt); portal.rotation.z += dt * .5; portal2.rotation.z -= dt * .9; core.scale.setScalar(1 + Math.sin(t * 2) * .05);
      cubes.forEach((c, i) => { c.rotation.x += dt * (.4 + i * .03); c.rotation.y += dt * .6; c.position.y += Math.sin(t + i) * .005; });
      pt = (pt + dt * .45) % 1; pulse.scale.setScalar(.5 + pt * 13); pulse.material.opacity = (1 - pt) * .8;
    } };
}

/* ---------------------------------------------------------------- NEON RIFT ---- */
function neonRift(scene) {
  const g = new THREE.Group(); scene.add(g); const rnd = rngFor(7);
  put(g, new THREE.PlaneGeometry(26, 20), std(0x0f1828, .28, .65), [0, -.03, 0], [-Math.PI / 2, 0, 0]);
  const grid = new THREE.GridHelper(26, 52, 0x3a74a0, 0x1c2d46); grid.position.y = .005; g.add(grid);
  for (let i = 0; i < 3; i++) put(g, new THREE.TorusGeometry(4.6 + i * .62, .02, 6, 100), new THREE.MeshBasicMaterial({ color: new THREE.Color(i === 1 ? 0xff496d : 0x44dbe8).multiplyScalar(1.5), transparent: true, opacity: .6 - i * .1 }), [0, .015 + i * .006, 0], [Math.PI / 2, 0, 0]);
  const cyan = std(0x3be4e4, .25, .5, { emissive: 0x087d9c, emissiveIntensity: 1.6 }), red = std(0xff4b6b, .25, .5, { emissive: 0x8e1232, emissiveIntensity: 1.4 }), dark = std(0x11192a, .48, .72), light = std(0x6e83a8, .38, .68);
  for (const s of [-1, 1]) { put(g, new THREE.BoxGeometry(.65, 3.4, .65), dark, [s * 7.4, 1.7, -2.3], [0, 0, 0], [1, 1, 1], true); put(g, new THREE.BoxGeometry(1.15, .12, 1.15), light, [s * 7.4, 3.45, -2.3]); put(g, new THREE.BoxGeometry(.12, 1.2, .05), s < 0 ? cyan : red, [s * 7.4, 2.2, -1.96]); }
  const wins = [];
  for (let i = 0; i < 22; i++) { const x = (i - 10.5) * 1.2, z = -8.2 - rnd() * 2, h = 1.6 + rnd() * 5, w = .55 + rnd() * .8; put(g, new THREE.BoxGeometry(w, h, .65), std(i % 3 === 0 ? 0x172a43 : 0x101a2d, .7, .25), [x, h / 2, z]);
    for (let j = 0; j < Math.floor(h * 1.4); j++) wins.push(put(g, new THREE.BoxGeometry(.055, .18, .02), new THREE.MeshBasicMaterial({ color: new THREE.Color(i % 2 ? 0x39cde1 : 0xf14b77).multiplyScalar(1.4) }), [x - w * .25 + (j % 2) * w * .5, .35 + j * .52, z + .34])); }
  for (const s of [-1, 1]) put(g, new THREE.TorusGeometry(2.4, .085, 10, 64), new THREE.MeshStandardMaterial({ color: s < 0 ? 0x49d9ed : 0xff4b70, emissive: s < 0 ? 0x49d9ed : 0xff4b70, emissiveIntensity: 1.5, metalness: .6, roughness: .25 }), [s * 5.6, 2.7, -5.2], [0, .12 * s, 0]);
  put(g, new THREE.CircleGeometry(2.1, 40), new THREE.MeshBasicMaterial({ color: new THREE.Color(0xbfd8ff).multiplyScalar(1.6), fog: false }), [2.5, 8.2, -16]);
  const sparks = field(g, 70, { area: [24, 8, 14], center: [0, 0, -2], color: 0x6fd8ff, boost: 1.4, size: .07, vel: [0, .5, 0], wobble: .4, seed: 9 });
  return { group: g, env: { bg: 0x070b16, fog: [0x070b16, .022], hemi: [0xa8c4ff, 0x1a1a2e, 1.5], key: [0xfff4ea, 2.7], rim1: [0x6fd8ff, 1.6], rim2: [0xff6f9a, 1.3], exposure: 1.12 }, update(dt) { sparks.update(dt); } };
}

const BUILDERS = { 'crimson-dojo': crimsonDojo, 'frozen-citadel': frozenCitadel, 'volcano-forge': volcanoForge, 'storm-peak': stormPeak, 'digital-void': digitalVoid, 'neon-rift': neonRift };
export function buildArena(id, scene, ctx = {}) { const b = BUILDERS[id] || neonRift; return b(scene, ctx); }
export const arenaName = id => (ARENA_LIST.find(a => a.id === id) || ARENA_LIST[5]).name;
