// fighter.js — builds an anime-styled, skeletally rigged fighter out of toon-shaded primitives and animates it.
// Skeleton/pose math lives in rig.js. Everything visual here (hair, eyes, clothes, weapons) is procedural.
import * as THREE from 'https://cdn.jsdelivr.net/npm/three@0.169.0/build/three.module.js';
import { D, J, STANCE, clonePose, groundHips, legYawDelta, TAU } from './rig.js';
import { toonMat, glowMat, PartBuilder } from './toon.js';

const G = {
  sph: (r, w = 14, h = 10) => new THREE.SphereGeometry(r, w, h),
  cap: (r, len) => new THREE.CapsuleGeometry(r, Math.max(.001, len), 4, 10),
  cyl: (rt, rb, h, s = 10) => new THREE.CylinderGeometry(rt, rb, h, s),
  box: (w, h, d) => new THREE.BoxGeometry(w, h, d),
  cone: (r, h, s = 6) => new THREE.ConeGeometry(r, h, s).translate(0, h / 2, 0),
  torus: (r, t, rs = 6, ts = 22, arc = TAU) => new THREE.TorusGeometry(r, t, rs, ts, arc),
  sphPart: (r, phiS, phiL, thS, thL) => new THREE.SphereGeometry(r, 18, 10, phiS, phiL, thS, thL)
};
function quadGeo(w0, w1, len) {
  const g = new THREE.BufferGeometry();
  g.setAttribute('position', new THREE.BufferAttribute(new Float32Array([-w0/2,0,0, w0/2,0,0, w1/2,-len,0, -w1/2,-len,0]), 3));
  g.setAttribute('normal', new THREE.BufferAttribute(new Float32Array([0,0,1, 0,0,1, 0,0,1, 0,0,1]), 3));
  g.setIndex([0, 2, 1, 0, 3, 2]);
  return g;
}
const _q = new THREE.Quaternion(), _e = new THREE.Euler(), _up = new THREE.Vector3(0, 1, 0), _d = new THREE.Vector3();
function rotFromDir(dir) { _d.set(dir[0], dir[1], dir[2]).normalize(); _q.setFromUnitVectors(_up, _d); _e.setFromQuaternion(_q, 'YXZ'); return [_e.x, _e.y, _e.z]; }
const lerp = (a, b, t) => a + (b - a) * t;
const clamp = (v, a, b) => Math.max(a, Math.min(b, v));
const grp = (parent, pos) => { const g = new THREE.Group(); g.rotation.order = 'YXZ'; if (pos) g.position.set(pos[0], pos[1], pos[2]); if (parent) parent.add(g); return g; };

/* ------------------------------------------------ secondary-motion chain ---- */
class Chain {
  constructor(parent, anchor, spec, mat) {
    this.n = spec.n; this.len = spec.len; this.base = spec.base || new Array(spec.n).fill(0); this.baseB = spec.baseB || 0;
    this.k = spec.k || 120; this.damp = spec.damp || 7; this.kv = spec.kv || .1; this.wind = spec.wind == null ? .06 : spec.wind; this.phase = Math.random() * 6;
    this.root = grp(parent, anchor); this.segs = [];
    let up = this.root;
    for (let i = 0; i < this.n; i++) {
      const g = grp(up, i ? [0, -this.len, 0] : null);
      const t0 = i / this.n, t1 = (i + 1) / this.n, pb = new PartBuilder();
      if (spec.flat) pb.add(quadGeo(lerp(spec.w0, spec.w1, t0), lerp(spec.w0, spec.w1, t1), this.len), mat, [0, 0, 0], [0, 0, 0], [1, 1, 1], false);
      else pb.add(G.cyl(lerp(spec.r0, spec.r1, t0), lerp(spec.r0, spec.r1, t1), this.len, 7), mat, [0, -this.len / 2, 0], [0, 0, 0], [1, 1, spec.flatZ || .7]);
      pb.build(g, spec.flat ? 0 : .02, { cast: false });
      g.rotation.set(this.base[i], 0, i === 0 ? this.baseB : 0);
      this.segs.push({ g, a: this.base[i], b: i === 0 ? this.baseB : 0, va: 0, vb: 0, i });
      up = g;
    }
  }
  kick(a, b) { for (const s of this.segs) { s.va += a * (1 + s.i * .4); s.vb += b * (1 + s.i * .4); } }
  update(dt, vx, vy, vz, t) {
    vz = clamp(vz, -9, 9); vx = clamp(vx, -9, 9);
    for (const s of this.segs) {
      const lag = 1 + s.i * .22, w = Math.sin(t * (2.1 + s.i * .33) + this.phase + s.i * .9) * this.wind * (.4 + s.i * .3);
      const ta = clamp(this.base[s.i] + vz * this.kv * lag + w, this.base[s.i] - 1.3, this.base[s.i] + 1.3);
      const tb = clamp((s.i === 0 ? this.baseB : 0) - vx * this.kv * lag * .8 + w * .6, -1.2, 1.2);
      s.va += ((ta - s.a) * this.k - s.va * this.damp) * dt; s.a += s.va * dt;
      s.vb += ((tb - s.b) * this.k - s.vb * this.damp) * dt; s.b += s.vb * dt;
      s.g.rotation.x = s.a; s.g.rotation.z = s.b;
    }
  }
}

/* ---------------------------------------------------------------- Fighter ---- */
export class Fighter {
  constructor(scene, data, { isPlayer = true } = {}) {
    this.data = data; this.isPlayer = isPlayer; this.scene = scene;
    this.cur = clonePose(STANCE); this.time = Math.random() * 10; this.chains = []; this.orbiters = []; this.toonMats = [];
    this.fxVel = new THREE.Vector3(); this.glowBoost = 1; this.hitFlash = 0; this.viewYaw = 0;
    this.expr = { name: 'normal', eye: 1, brow: 0, mouthW: 1, mouthH: .5, mouthY: 0 }; this.blinkT = 2 + Math.random() * 3; this.blink = 0;
    const b = data.build || {}, B = b.bulk || 1, hs = b.height || 1; this.B = B;
    this.root = new THREE.Group(); scene.add(this.root);
    this.viewG = grp(this.root); this.viewG.scale.setScalar(hs);
    this.bodyG = grp(this.viewG); this.leanG = grp(this.bodyG);
    const j = this.j = {};
    j.hips = grp(this.leanG);
    j.spine = grp(j.hips, [0, D.spineJ, 0]); j.chest = grp(j.spine, [0, D.chestJ, 0]);
    j.neck = grp(j.chest, [0, D.neckJ, 0]); j.head = grp(j.neck, [0, D.headJ, 0]);
    for (const [s, sx] of [['L', 1], ['R', -1]]) {
      j['ua' + s] = grp(j.chest, [sx * D.shX * (b.female ? .93 : B > 1 ? 1.12 : 1), D.shY, 0]);
      j['el' + s] = grp(j['ua' + s], [0, -D.ua, 0]); j['hand' + s] = grp(j['el' + s], [0, -D.fa, 0]);
      j['th' + s] = grp(j.hips, [sx * D.hipX * (B > 1 ? 1.1 : 1), -D.hipDrop, 0]);
      j['kn' + s] = grp(j['th' + s], [0, -D.thigh, 0]); j['ft' + s] = grp(j['kn' + s], [0, -D.shin, 0]);
    }
    this.buildMaterials(); this.buildBody(); this.buildHead(); this.buildGear();
    // blob shadow + point light (rim colour pulse)
    const sh = new THREE.Mesh(new THREE.CircleGeometry(.9, 28), new THREE.MeshBasicMaterial({ color: 0x02040a, transparent: true, opacity: .55, depthWrite: false }));
    sh.rotation.x = -Math.PI / 2; sh.position.y = .015; sh.scale.set(1.15, .8, 1); sh.userData.noGhost = true; this.root.add(sh); this.shadow = sh;
    this.light = new THREE.PointLight(data.glow, 6, 5, 2); this.light.position.set(0, 1.7, .6); this.root.add(this.light);
  }

  /* ------------------------------------------------------------ materials ---- */
  buildMaterials() {
    const d = this.data, rim = new THREE.Color(d.glow).lerp(new THREE.Color(0xffffff), .3).getHex();
    const T = (c, k = .45, side) => { const m = toonMat(c, { rim, rimK: k, side }); this.toonMats.push(m); return m; };
    this.M = {
      skin: T(d.skin, .22), hair: T(d.hair, .8, THREE.DoubleSide), hairHi: T(d.hairHi, .3, THREE.DoubleSide),
      outfit: T(d.outfit, .5), outfit2: T(d.outfit2, .45), accent: T(d.accent, .35), dark: T(0x14161f, .3), metal: T(0xaab6c8, .9), white: T(0xf4f6fa, .3),
      cloth: T(d.outfit, .5, THREE.DoubleSide), clothAcc: T(d.accent, .4, THREE.DoubleSide), clothDark: T(d.outfit2, .4, THREE.DoubleSide),
      glow: glowMat(d.glow, 1.9), glow2: glowMat(d.glow2 || d.accent, 1.7)
    };
    this.glowMats = [this.M.glow, this.M.glow2];
  }

  /* ----------------------------------------------------------------- body ---- */
  buildBody() {
    const { M, j, B } = this, g = this.data.gear, has = k => g.includes(k), b = this.data.build || {};
    const sleeveless = has('vest') || has('gi') || has('armor');
    const armMat = sleeveless ? M.skin : M.outfit;
    // hips / waist / chest
    const hips = new PartBuilder();
    hips.add(G.sph(.2 * B, 14, 10), M.outfit2, [0, 0, 0], [0, 0, 0], [1.18, .82, .98]);
    hips.add(G.cyl(.215 * B, .21 * B, .075, 14), M.dark, [0, .07, 0]);
    hips.add(G.box(.11, .085, .04), M.accent, [0, .07, .21 * B]);
    hips.build(j.hips, .03);
    const spine = new PartBuilder();
    spine.add(G.cyl(.2 * B, .215 * B, .36, 14), has('gi') ? M.skin : M.outfit, [0, .16, 0], [0, 0, 0], [1.05, 1, .82]);
    if (has('sash') || has('gi')) spine.add(G.cyl(.22 * B, .22 * B, .1, 14), M.accent, [0, .03, 0], [0, 0, 0], [1.05, 1, .84]);
    spine.build(j.spine, .03);
    const chest = new PartBuilder();
    chest.add(G.sph(.3 * B, 18, 12), has('gi') ? M.skin : M.outfit, [0, .17, 0], [0, 0, 0], [1.12, .88, .74]);
    if (has('jacket') || has('coat') || has('haori')) {
      chest.add(G.box(.035, .3, .03), M.accent, [0, .15, .215 * B]);
      for (const s of [-1, 1]) { chest.add(G.box(.13, .12, .05), M.outfit, [s * .12, .36, .12 * B], [-.5, 0, s * -.3]); chest.add(G.box(.05, .22 * B, .02), M.clothAcc || M.accent, [s * .2 * B, .15, .2 * B]); }
      chest.add(G.sph(.24 * B, 14, 10), M.outfit2, [0, .1, -.02], [0, 0, 0], [1.1, .6, .85]);
    }
    if (has('gi')) for (const s of [-1, 1]) chest.add(G.box(.15, .42, .035), M.outfit, [s * .1, .2, .205 * B], [0, 0, s * -.42]);
    if (has('vest')) { for (const s of [-1, 1]) chest.add(G.box(.12 * B, .38, .05), M.outfit, [s * .17 * B, .18, .19 * B], [0, 0, s * -.12]); chest.add(G.sph(.065, 8, 6), M.accent, [0, .02, .2], [0, 0, 0], [1, 1, .4]); }
    if (has('armor')) {
      chest.add(G.sph(.31 * B, 16, 12), M.metal, [0, .19, .04], [0, 0, 0], [1.12, .78, .7]);
      chest.add(G.box(.5 * B, .06, .1), M.accent, [0, .02, .2 * B]); chest.add(G.sph(.1, 10, 8), M.glow, [0, .2, .26 * B], [0, 0, 0], [1, 1, .4]);
    }
    if (has('xEmblem')) for (const s of [-1, 1]) chest.add(G.box(.05, .34, .025), M.glow, [0, .17, .222 * B], [0, 0, s * .72], [1, 1, 1], false);
    if (has('reactor')) { chest.add(G.torus(.2, .028, 8, 28), M.glow, [0, .17, -.26 * B], [Math.PI / 2 - .1, 0, 0], [1, 1, 1], false); chest.add(G.torus(.12, .02, 6, 20), M.glow2, [0, .17, -.27 * B], [Math.PI / 2 - .1, 0, 0], [1, 1, 1], false); }
    if (has('beads')) { for (let i = 0; i < 12; i++) { const a = i / 12 * TAU; chest.add(G.sph(.034, 6, 5), i % 3 ? M.accent : M.glow, [Math.sin(a) * .2 * B, .32 - Math.abs(Math.sin(a)) * .06 + Math.cos(a) * .0, Math.cos(a) * .15 * B], [0, 0, 0], [1, 1, 1], i % 3 !== 0); } }
    chest.build(j.chest, .03);
    const neck = new PartBuilder();
    neck.add(G.cyl(.07, .082, .2, 10), M.skin, [0, .07, 0]);
    if (has('scarf') || has('mask')) neck.add(G.torus(.125, .05, 8, 20), has('scarf') ? M.clothAcc : M.dark, [0, .06, 0], [Math.PI / 2, 0, 0]);
    neck.build(j.neck, .025);
    // arms & legs
    for (const [s, sx] of [['L', 1], ['R', -1]]) {
      const ua = new PartBuilder();
      ua.add(G.sph(.105 * B, 12, 8), armMat, [0, 0, 0]);
      ua.add(G.cap(.072 * B, D.ua - .15 * B), armMat, [0, -.2, 0]);
      if (has('armor')) { ua.add(G.sph(.2, 12, 9), M.metal, [sx * .04, .06, 0], [0, 0, sx * -.3], [1.15, .8, 1.1]); ua.add(G.torus(.17, .03, 6, 16), M.accent, [sx * .04, .0, 0], [Math.PI / 2, 0, sx * -.3]); }
      if (has('haori')) ua.add(G.box(.2, .32, .26), M.cloth, [sx * .06, -.26, 0], [0, 0, sx * -.12], [1, 1, 1], false);
      ua.build(j['ua' + s], .028);
      const el = new PartBuilder();
      el.add(G.sph(.068 * B, 10, 8), armMat, [0, 0, 0]);
      el.add(G.cap(.063 * B, D.fa - .13 * B), has('wraps') ? M.accent : M.skin, [0, -.19, 0]);
      if (has('bracers') || has('claws') || has('twinBlades') || has('daggers')) el.add(G.cyl(.082 * B, .074 * B, .2, 12), M.dark, [0, -.27, 0]);
      if (has('bracers')) el.add(G.torus(.08 * B, .014, 6, 14), M.glow, [0, -.2, 0], [Math.PI / 2, 0, 0], [1, 1, 1], false);
      if (has('twinBlades')) el.add(G.box(.13, .2, .15), M.metal, [0, -.27, .0]);
      el.build(j['el' + s], .026);
      const hand = new PartBuilder(), big = has('bigFists'), fire = has('flameFists') || has('sparkFists');
      hand.add(G.sph((big ? .15 : fire ? .115 : .088) * B, 12, 9), big ? M.metal : fire ? M.outfit2 : (has('gi') || has('wraps') ? M.skin : M.dark), [0, -.055, 0], [0, 0, 0], [1, 1.12, 1]);
      if (big) hand.add(G.box(.2, .06, .06), M.accent, [0, -.1, .13], [0, 0, 0]);
      if (fire) hand.add(G.torus(.095 * B, .02, 6, 16), M.glow, [0, .0, 0], [Math.PI / 2, 0, 0], [1, 1, 1], false);
      hand.build(j['hand' + s], .024);
      const th = new PartBuilder();
      th.add(G.cap(.108 * B, D.thigh - .2 * B), M.outfit2, [0, -.27, 0], [0, 0, 0], [1, 1, 1.02]);
      th.add(G.sph(.115 * B, 12, 8), M.outfit2, [0, 0, 0]);
      if (has('jacket') || has('coat') || has('haori')) th.add(G.cyl(.12 * B, .11 * B, .05, 12), M.accent, [0, -.12, 0]);
      th.build(j['th' + s], .03);
      const kn = new PartBuilder();
      kn.add(G.sph(.095 * B, 10, 8), M.outfit2, [0, 0, 0]);
      kn.add(G.cap(.088 * B, D.shin - .16 * B), M.outfit2, [0, -.25, 0]);
      kn.add(G.cyl(.098 * B, .112 * B, .24, 12), M.dark, [0, -.4, 0]);
      kn.add(G.torus(.1 * B, .016, 6, 14), M.accent, [0, -.29, 0], [Math.PI / 2, 0, 0]);
      if (has('kneeGuards')) kn.add(G.sph(.115 * B, 10, 8), M.metal, [0, -.01, .08 * B], [0, 0, 0], [1, 1.1, .8]);
      kn.build(j['kn' + s], .03);
      const ft = new PartBuilder();
      ft.add(G.sph(1, 12, 9), M.dark, [0, -.02, .07], [0, 0, 0], [.1 * B, .078, .2]);
      ft.add(G.box(.17 * B, .022, .36), M.accent, [0, -.095, .07]);
      ft.build(j['ft' + s], .026);
    }
    // trail anchor points (set in buildGear for weapons)
    this.trailPts = {};
    this.sock = {};
    for (const s of ['L', 'R']) {
      const tip = new THREE.Object3D(), base = new THREE.Object3D();
      tip.position.set(0, -.14, .06); base.position.set(0, -.0, -.02); j['hand' + s].add(tip, base);
      this.trailPts['hand' + s] = { tip, base };
      const ft = new THREE.Object3D(), fb = new THREE.Object3D(); ft.position.set(0, -.05, .3); fb.position.set(0, -.07, -.1); j['ft' + s].add(ft, fb);
      this.trailPts['foot' + s] = { tip: ft, base: fb };
      this.sock['hand' + s] = j['hand' + s]; this.sock['foot' + s] = j['ft' + s];
    }
    this.sock.head = j.head; this.sock.chest = j.chest;
  }

  /* ----------------------------------------------------------------- head ---- */
  buildHead() {
    const { M, j } = this, d = this.data, b = d.build || {}, hair = d.hair_ || {}, hl = hair.len || 1, has = k => d.gear.includes(k);
    const head = new PartBuilder();
    head.add(G.sph(.285, 22, 16), M.skin, [0, 0, 0], [0, 0, 0], [.93, 1.0, .96]);
    head.add(G.sph(.2, 16, 12), M.skin, [0, -.125, .055], [0, 0, 0], [.84, .84, .82]);
    for (const s of [-1, 1]) head.add(G.sph(.05, 8, 6), M.skin, [s * .265, -.02, -.01], [0, 0, 0], [.55, 1, .8]);
    head.add(G.sph(.017, 6, 5), M.skin, [0, -.07, .27]);
    // hair cap (front hairline is kept clear of the eyes), back cap, shine band
    const hp = [0, .02, -.02], hsx = [.97, 1, .99];
    head.add(G.sphPart(.305, 0, TAU, 0, Math.PI * .4), M.hair, hp, [0, 0, 0], hsx);
    head.add(G.sphPart(.313, Math.PI, Math.PI, 0, Math.PI * .74), M.hair, [0, .015, -.02], [0, 0, 0], hsx);
    head.add(G.sphPart(.31, 0, TAU, Math.PI * .16, Math.PI * .045), M.hairHi, hp, [0, 0, 0], hsx, false);
    const skull = (th, ph, r = .29) => [r * Math.sin(th) * Math.sin(ph) * .96, r * Math.cos(th) + .02, r * Math.sin(th) * Math.cos(ph) * .98 - .02];
    const nrm = (th, ph) => [Math.sin(th) * Math.sin(ph), Math.cos(th), Math.sin(th) * Math.cos(ph)];
    const spike = (th, ph, len, rad, sw, mat = M.hair) => {
      const n = nrm(th, ph), dir = [n[0] + sw[0] * (n[0] < 0 ? -1 : 1) * 0, n[1] + sw[1], n[2] + sw[2]];
      head.add(G.cone(rad, len * hl, 6), mat, skull(th, ph), rotFromDir(dir), [1, 1, 1]);
    };
    const bang = (ph, len, rad, th = .95) => {
      const n = nrm(th, ph), p = skull(th, ph);
      head.add(G.cone(rad, len, 5), M.hair, p, rotFromDir([n[0] * .5, -1, n[2] * .35 + .22]), [1, 1, 1]);
    };
    const style = hair.style || 'spikyUp', sw = hair.sweep || [0, .55, -.7];
    const crown = [[.15, 0, .46, .1], [.35, .8, .44, .1], [.35, -.8, .44, .1], [.5, 1.6, .4, .1], [.5, -1.6, .4, .1], [.55, 2.5, .46, .11], [.55, -2.5, .46, .11], [.8, 3.14, .38, .11], [.3, 3.14, .5, .12], [.25, 1.7, .4, .09], [.25, -1.7, .4, .09]];
    if (style === 'spikyUp') { for (const c of crown) spike(c[0], c[1], c[2], c[3], sw); }
    if (style === 'messy') { for (const c of crown) spike(c[0], c[1], c[2] * .7, c[3] * .85, [0, .25, -.5]); }
    if (style === 'crop') { for (const c of crown) spike(c[0] + .1, c[1], .17, .075, [0, .1, -.1]); }
    if (style === 'topknot') {
      head.add(G.sph(.095, 10, 8), M.hair, [0, .33, -.03]); head.add(G.cyl(.05, .05, .09, 8), M.hair, [0, .27, -.03]);
      head.add(G.torus(.08, .018, 6, 14), M.accent, [0, .285, -.03], [Math.PI / 2, 0, 0]);
    }
    // bangs framing the face
    const bl = style === 'crop' || style === 'topknot' ? .7 : 1;
    bang(-1.0, .26 * bl, .05); bang(1.0, .26 * bl, .05); bang(0, .21 * bl, .055); bang(-.45, .11, .045, .88); bang(.45, .11, .045, .88);
    if (style === 'spikyUp' || style === 'messy') { bang(-.18, .12, .04, .9); bang(.2, .13, .04, .9); }
    // headgear
    if (has('headband')) { head.add(G.torus(.292, .026, 6, 28), M.accent, [0, .105, -.01], [Math.PI / 2 - .12, 0, 0], [.95, .98, 1], false); }
    if (has('goggles')) {
      head.add(G.torus(.298, .022, 6, 28), M.dark, [0, .125, -.01], [Math.PI / 2 - .2, 0, 0], [.95, .98, 1]);
      for (const s of [-1, 1]) { head.add(G.cyl(.07, .07, .05, 14), M.dark, [s * .105, .2, .22], [Math.PI / 2 - .55, 0, 0]); head.add(G.cyl(.052, .052, .056, 14), M.glow2, [s * .105, .202, .226], [Math.PI / 2 - .55, 0, 0], [1, 1, 1], false); }
    }
    if (has('visor')) {
      head.add(G.torus(.292, .03, 6, 26, Math.PI * .9), M.glow, [0, .13, 0], [Math.PI / 2 - .35, 0, Math.PI * 1.05], [.96, .98, 1], false);
      for (const s of [-1, 1]) { head.add(G.cyl(.062, .062, .06, 12), M.dark, [s * .285, -.0, -.0], [0, 0, Math.PI / 2]); head.add(G.cyl(.034, .034, .066, 10), M.glow, [s * .286, 0, 0], [0, 0, Math.PI / 2], [1, 1, 1], false); }
      head.add(G.box(.04, .2, .04), M.dark, [-.26, -.1, .06], [0, 0, .3]); head.add(G.sph(.02, 6, 5), M.glow, [-.235, -.19, .1], [0, 0, 0], [1, 1, 1], false);
    }
    if (has('headset')) {
      head.add(G.torus(.31, .022, 6, 28, Math.PI), M.dark, [0, .02, -.02], [0, 0, Math.PI]);
      for (const s of [-1, 1]) { head.add(G.cyl(.09, .09, .07, 14), M.accent, [s * .292, -.02, -.01], [0, 0, Math.PI / 2]); head.add(G.cyl(.052, .052, .076, 12), M.glow, [s * .296, -.02, -.01], [0, 0, Math.PI / 2], [1, 1, 1], false); }
    }
    if (has('mask')) { head.add(G.sph(.215, 14, 10), M.dark, [0, -.125, .045], [0, 0, 0], [.9, .66, .86]); head.add(G.box(.09, .012, .02), M.glow, [0, -.1, .235], [0, 0, 0], [1, 1, 1], false); }
    head.build(j.head, .03);
    // dynamic hair chains
    const hm = M.hair, bnd = hair.style;
    const mkChain = (a, spec, mat = hm) => this.chains.push(new Chain(j.head, a, spec, mat));
    if (bnd === 'long') {
      mkChain([0, .12, -.25], { n: 6, len: .18, r0: .17, r1: .035, base: [.2, .08, .06, .04, .03, .02], flatZ: .6, k: 90, damp: 6, kv: .09 });
      for (const s of [-1, 1]) mkChain([s * .245, .0, .06], { n: 3, len: .13, r0: .055, r1: .018, base: [.02, .03, .03], baseB: s * .05, kv: .06 });
    }
    if (bnd === 'twin') {
      for (const s of [-1, 1]) {
        mkChain([s * .27, .14, -.06], { n: 6, len: .16, r0: .12, r1: .025, base: [.25, .1, .08, .05, .04, .03], baseB: s * -.25, k: 100, kv: .1 });
        const tie = new PartBuilder(); tie.add(G.sph(.065, 10, 8), M.accent, [s * .27, .15, -.06]); tie.add(G.torus(.075, .02, 6, 14), M.glow, [s * .27, .15, -.06], [0, Math.PI / 2, 0], [1, 1, 1], false); tie.build(j.head, .02);
      }
    }
    if (bnd === 'ponytail') {
      mkChain([0, .2, -.27], { n: 5, len: .19, r0: .1, r1: .028, base: [1.9, -.8, -.6, -.45, -.3], flatZ: .7, k: 85, damp: 5.5, kv: .12 });
      const tie = new PartBuilder(); tie.add(G.torus(.075, .022, 6, 14), M.accent, [0, .2, -.27], [Math.PI / 2 - .4, 0, 0]); tie.build(j.head, .02);
    }
    if (bnd === 'spikyUp' && d.slug === 'cyber-x') { /* handled by hair spikes */ }
    // headband / scarf tails
    if (has('headband')) { for (const s of [-1, 1]) mkChain([s * .06, .09, -.3], { n: 3, len: .14, flat: true, w0: .06, w1: .035, base: [.6, .2, .1], baseB: s * .25, kv: .16, wind: .1 }, M.clothAcc); }
    if (has('scarf')) mkChain([0, .1, -.12], { n: 6, len: .2, flat: true, w0: .17, w1: .1, base: [.35, .1, .06, .05, .04, .03], baseB: 0, kv: .13, wind: .1, k: 80, damp: 5 }, M.clothAcc);
    if (has('scarf')) mkChain([.07, .1, -.1], { n: 4, len: .17, flat: true, w0: .1, w1: .06, base: [.2, .08, .05, .04], baseB: .3, kv: .13, wind: .12, k: 80, damp: 5 }, M.clothAcc);
    this.buildFace();
  }

  buildFace() {
    const d = this.data, b = d.build || {}, head = this.j.head, fem = !!b.female, face = this.face = { eyes: [], brows: [] };
    const flat = (geoR, color, pos, rot, scl, layer, parent) => {
      const m = new THREE.Mesh(new THREE.CircleGeometry(geoR, 20), new THREE.MeshBasicMaterial({ color, polygonOffset: true, polygonOffsetFactor: -layer * 2, polygonOffsetUnits: -layer * 2 }));
      m.position.set(pos[0], pos[1], pos[2]); m.rotation.set(rot[0], rot[1], rot[2]); m.scale.set(scl[0], scl[1], 1); m.userData.noGhost = true; parent.add(m); return m;
    };
    const hairDark = new THREE.Color(d.hair).multiplyScalar(.45).getHex();
    const eyeC = new THREE.Color(d.eye), eyeLight = eyeC.clone().lerp(new THREE.Color(0xffffff), .5), eyeDark = eyeC.clone().multiplyScalar(.45);
    const ew = fem ? 1.08 : 1, eh = fem ? 1.08 : 1;
    for (const s of [1, -1]) {
      const eg = grp(head, [s * .108, -.012, .255]); eg.rotation.set(-.04, s * .4, 0); eg.userData.noGhost = true;
      flat(.5, 0xffffff, [0, 0, 0], [0, 0, 0], [.135 * ew, .168 * eh], 1, eg);
      flat(.5, eyeDark.getHex(), [0, -.002, 0], [0, 0, 0], [.108 * ew, .156 * eh], 2, eg);
      flat(.5, eyeC.getHex(), [0, -.014, 0], [0, 0, 0], [.1 * ew, .13 * eh], 3, eg);
      flat(.5, eyeLight.getHex(), [0, -.05, 0], [0, 0, 0], [.074 * ew, .058 * eh], 4, eg);
      flat(.5, 0x0c0d14, [0, -.006, 0], [0, 0, 0], [.044 * ew, .09 * eh], 5, eg);
      flat(.5, 0xffffff, [-s * .026, .05, 0], [0, 0, 0], [.036, .042], 6, eg);
      flat(.5, 0xffffff, [s * .024, -.05, 0], [0, 0, 0], [.018, .02], 6, eg);
      flat(.5, 0x0c0d14, [0, .081 * eh, 0], [0, 0, s * .16], [.168 * ew, fem ? .05 : .038], 7, eg);
      if (fem) flat(.5, 0x0c0d14, [s * .075, .06, 0], [0, 0, s * .6], [.05, .02], 7, eg);
      face.eyes.push(eg);
      const br = new THREE.Mesh(new THREE.BoxGeometry(.105, fem ? .014 : .022, .01), new THREE.MeshBasicMaterial({ color: hairDark }));
      br.position.set(s * .112, .1, .243); br.rotation.set(-.3, s * .4, s * (b.brow || 0)); br.userData.noGhost = true; br.userData.side = s; head.add(br); face.brows.push(br);
    }
    face.mouth = flat(.5, 0x6a2430, [0, -.152, .237], [.5, 0, 0], [.05, .014], 3, head);
  }

  /* ----------------------------------------------------------------- gear ---- */
  buildGear() {
    const { M, j, B } = this, d = this.data, has = k => d.gear.includes(k), root = this.root;
    const body = this.leanG; // used for coat tails (hang from hips)
    if (has('jacket') || has('coat') || has('haori')) {
      const long = has('coat') ? 4 : has('haori') ? 4 : 2;
      for (const s of [-1, 1]) {
        this.chains.push(new Chain(j.hips, [s * .13 * B, -.03, -.14 * B], { n: long, len: has('coat') || has('haori') ? .22 : .17, flat: true, w0: .2 * B, w1: .16 * B, base: [.12, .08, .06, .05], baseB: s * .06, kv: .11, wind: .05, k: 95, damp: 6 }, has('haori') ? M.cloth : M.clothDark));
      }
      this.chains.push(new Chain(j.hips, [0, -.03, -.17 * B], { n: long, len: has('coat') || has('haori') ? .24 : .18, flat: true, w0: .22 * B, w1: .17 * B, base: [.1, .08, .06, .05], kv: .11, wind: .06, k: 95, damp: 6 }, M.clothAcc));
    }
    if (has('gi') || has('sash')) for (const s of [-1, 1]) this.chains.push(new Chain(j.hips, [s * .11, .02, .02], { n: 4, len: .17, flat: true, w0: .09, w1: .06, base: [.04, .04, .03, .03], baseB: s * .1, kv: .12, wind: .08 }, has('gi') ? M.clothAcc : M.clothAcc));
    // weapons ---------------------------------------------------------------
    const weapon = (hand, kind, tilt) => {
      const wg = grp(j['hand' + hand]); wg.rotation.x = tilt;
      const pb = new PartBuilder();
      let len = 1, baseAt = -.4;
      if (kind === 'katana' || kind === 'iceKatana') {
        const ice = kind === 'iceKatana';
        pb.add(G.cyl(.026, .026, .3, 8), M.dark, [0, -.1, 0]); pb.add(G.cyl(.075, .075, .026, 12), ice ? M.accent : M.metal, [0, -.26, 0], [0, 0, 0], [1, 1, .6]);
        pb.add(G.box(.014, .86, .07), ice ? M.white : M.metal, [0, -.7, 0]); pb.add(G.cone(.035, .16, 4), ice ? M.white : M.metal, [0, -1.13, 0], [Math.PI, 0, 0], [.5, 1, 1.5]);
        pb.add(G.box(.008, .86, .018), M.glow2, [0, -.7, .036], [0, 0, 0], [1, 1, 1], false);
        if (ice) for (let i = 0; i < 5; i++) pb.add(G.cone(.03, .15 - i * .01, 4), M.glow, [0, -.5 - i * .15, i % 2 ? .04 : -.04], [i % 2 ? .6 : -.6, 0, 0], [.6, 1, .6], false);
        len = 1.2;
      } else if (kind === 'twinBlade') {
        pb.add(G.box(.04, 1.0, .09), M.glow, [0, -.62, 0], [0, 0, 0], [1, 1, 1], false);
        pb.add(G.box(.016, 1.0, .05), M.white, [0, -.62, .0], [0, 0, 0], [1, 1, 1], false);
        pb.add(G.cone(.045, .22, 4), M.glow, [0, -1.21, 0], [Math.PI, 0, 0], [.5, 1, 1.4], false);
        pb.add(G.box(.09, .06, .14), M.metal, [0, -.14, 0]);
        len = 1.25;
      } else if (kind === 'dagger') {
        pb.add(G.cyl(.022, .022, .2, 8), M.dark, [0, -.06, .0]); pb.add(G.torus(.05, .012, 6, 12), M.accent, [0, .03, 0]);
        pb.add(G.box(.012, .4, .06), M.metal, [0, -.34, 0]); pb.add(G.cone(.03, .1, 4), M.metal, [0, -.58, 0], [Math.PI, 0, 0], [.4, 1, 1.5]);
        pb.add(G.box(.007, .4, .015), M.glow, [0, -.34, .03], [0, 0, 0], [1, 1, 1], false);
        len = .6; baseAt = -.2;
      } else if (kind === 'claw') {
        for (const x of [-.045, 0, .045]) pb.add(G.cone(.017, .36 - Math.abs(x) * 1.2, 4), M.glow, [x, -.12, .07], [Math.PI - .35, 0, x * 3], [1, 1, 1], false);
        len = .5; baseAt = -.15;
      }
      pb.build(wg, .018);
      const tip = new THREE.Object3D(), base = new THREE.Object3D(); tip.position.set(0, -len, 0); base.position.set(0, baseAt, 0); wg.add(tip, base);
      this.trailPts['hand' + hand] = { tip, base };
      return wg;
    };
    this.weapons = [];
    if (has('katana') || has('iceKatana')) this.weapons.push(weapon('R', has('iceKatana') ? 'iceKatana' : 'katana', -.55));
    if (has('twinBlades')) { this.weapons.push(weapon('R', 'twinBlade', -.1), weapon('L', 'twinBlade', -.1)); }
    if (has('daggers')) { this.weapons.push(weapon('R', 'dagger', -.3), weapon('L', 'dagger', -.3)); }
    if (has('claws')) { this.weapons.push(weapon('R', 'claw', 0), weapon('L', 'claw', 0)); }
    if (has('katana')) { // saya on hip
      const pb = new PartBuilder(); pb.add(G.cyl(.032, .028, .9, 8), M.dark, [0, -.1, 0], [0, 0, 0]); pb.add(G.cyl(.04, .04, .06, 8), M.accent, [0, .36, 0]);
      const sg = grp(j.hips, [.26 * B, .02, -.05]); sg.rotation.set(1.25, .2, 0); pb.build(sg, .018);
    }
    // orbiting accessories ----------------------------------------------------
    if (has('jadeOrbs') || has('pixelCubes')) {
      const cubes = has('pixelCubes'), n = cubes ? 5 : 3;
      for (let i = 0; i < n; i++) {
        const o = new THREE.Group(), mat = glowMat(i % 2 ? d.accent : d.glow, 1.7);
        const core = new THREE.Mesh(cubes ? G.box(.16, .16, .16) : G.sph(.11, 12, 9), mat); const shell = new THREE.Mesh(cubes ? G.box(.2, .2, .2) : G.torus(.15, .012, 6, 20), new THREE.MeshBasicMaterial({ color: d.glow2, wireframe: true, transparent: true, opacity: .6 }));
        o.add(core, shell); o.userData.noGhost = true; root.add(o); this.orbiters.push({ g: o, a: i / n * TAU, r: .95 + (i % 2) * .15, h: 1.15 + (i % 3) * .38, spd: 1.2 + i * .15, cubes });
      }
    }
  }

  /* -------------------------------------------------------------- animation ---- */
  // Smoothly chase a target pose. rate: higher = snappier.
  trackPose(target, dt, rate = 16) {
    const k = 1 - Math.exp(-rate * dt), c = this.cur;
    for (const key in target) { const a = c[key], b = target[key]; a[0] += (b[0] - a[0]) * k; a[1] += (b[1] - a[1]) * k; a[2] += (b[2] - a[2]) * k; }
  }
  snapPose(target) { for (const key in target) { const a = this.cur[key], b = target[key]; a[0] = b[0]; a[1] = b[1]; a[2] = b[2]; } }
  normalizeSpin() { const y = this.cur.lean[1]; if (Math.abs(y) > Math.PI) this.cur.lean[1] = y - TAU * Math.round(y / TAU); }

  setExpression(name) {
    const E = { normal: [1, 0, .5, 1, 0], focus: [.82, .16, .4, 1, 0], attack: [.78, .32, 1.1, 1.9, -.004], hurt: [.08, -.18, 1.1, 2.1, -.004], win: [.28, -.1, 1.7, .9, .0], ko: [.05, -.15, .8, 1, 0] };
    const e = E[name] || E.normal; this.expr.name = name; this.expr.t = e;
  }

  update(dt, vlocal) {
    this.time += dt;
    const c = this.cur, j = this.j, dy = legYawDelta(c);
    this.bodyG.position.set(c.body[0], groundHips(c) + c.body[1], c.body[2]);
    this.leanG.rotation.set(c.lean[0], c.lean[1], c.lean[2]);
    for (const k of J) {
      const r = c[k]; if (k === 'thL' || k === 'thR') j[k].rotation.set(r[0], r[1] - dy, r[2]); else j[k].rotation.set(r[0], r[1], r[2]);
    }
    this.viewG.rotation.y = this.viewYaw;
    // chains
    const v = vlocal || this.fxVel; this.fxVel.multiplyScalar(Math.exp(-dt * 5));
    for (const ch of this.chains) ch.update(dt, v.x + this.fxVel.x, v.y + this.fxVel.y, v.z + this.fxVel.z, this.time);
    // orbiters
    for (const o of this.orbiters) { o.a += dt * o.spd; o.g.position.set(Math.cos(o.a) * o.r, o.h + Math.sin(o.a * 1.7) * .08, Math.sin(o.a) * o.r); o.g.rotation.y += dt * 2; o.g.rotation.x += dt * (o.cubes ? 1.4 : 0); }
    // glow pulse + hit flash
    const gb = (1.6 + Math.sin(this.time * 3.2) * .25) * this.glowBoost;
    for (const m of this.glowMats) m.color.copy(m.userData.base).multiplyScalar(gb * (m === this.M.glow2 ? .9 : 1));
    this.hitFlash = Math.max(0, this.hitFlash - dt * 6);
    for (const m of this.toonMats) m.emissive.setRGB(this.hitFlash * .7, this.hitFlash * .7, this.hitFlash * .75);
    this.light.intensity = 4 + Math.sin(this.time * 3) + (this.glowBoost - 1) * 10;
    // face
    this.blinkT -= dt; if (this.blinkT <= 0) { this.blink = .14; this.blinkT = 2.4 + Math.random() * 3.2; }
    this.blink = Math.max(0, this.blink - dt);
    const t = this.expr.t || [1, 0, .5, 1, 0], e = this.expr, kf = 1 - Math.exp(-dt * 18);
    e.eye += (t[0] - e.eye) * kf; e.brow += (t[1] - e.brow) * kf; e.mouthW += (t[2] - e.mouthW) * kf; e.mouthH += (t[3] - e.mouthH) * kf;
    const open = this.blink > 0 ? .08 : Math.max(.08, e.eye);
    for (const eg of this.face.eyes) eg.scale.y = open;
    for (const br of this.face.brows) { const base = (this.data.build?.brow || 0), s = br.userData.side; br.rotation.z = s * (base + e.brow); br.position.y = .1 - e.brow * .05; }
    this.face.mouth.scale.set(.05 * e.mouthW, .014 * e.mouthH, 1);
    this.face.mouth.position.y = -.152 + (t[4] || 0) * 3;
  }

  // World-space positions for effects (call after update + matrices).
  worldPos(name, out) { const o = this.sock[name] || this.root; o.updateWorldMatrix(true, false); return out.setFromMatrixPosition(o.matrixWorld); }
  trailWorld(name, tipOut, baseOut) {
    const t = this.trailPts[name]; if (!t) return false;
    t.tip.updateWorldMatrix(true, false); t.base.updateWorldMatrix(true, false);
    tipOut.setFromMatrixPosition(t.tip.matrixWorld); baseOut.setFromMatrixPosition(t.base.matrixWorld); return true;
  }
  // Additive "after-image" clone for dash / ultimate.
  makeGhost(color, opacity = .55) {
    this.root.updateMatrixWorld(true);
    const g = this.root.clone(true), kill = [];
    const mat = new THREE.MeshBasicMaterial({ color, transparent: true, opacity, blending: THREE.AdditiveBlending, depthWrite: false });
    g.traverse(o => { if (o.userData.outline || o.userData.noGhost || o.isLight) kill.push(o); else if (o.isMesh) o.material = mat; });
    for (const o of kill) if (o.parent) o.parent.remove(o);
    g.traverse(o => { o.castShadow = false; });
    return { group: g, mat };
  }
}
