// net.js — tiny WebSocket client for the FIGHTVERSE online server.
export class Net {
  constructor(url, token) { this.url = url; this.token = token; this.h = {}; this.ws = null; this.open = false; this.rtt = 0; this._ping = null; }
  on(type, fn) { this.h[type] = fn; return this; }
  connect(timeout = 6000) {
    return new Promise((resolve, reject) => {
      let settled = false, ws;
      const fail = e => { if (!settled) { settled = true; reject(e); } };
      try { ws = this.ws = new WebSocket(this.url); } catch (e) { return fail(e); }
      const to = setTimeout(() => { fail(new Error('timeout')); try { ws.close(); } catch (e) {} }, timeout);
      ws.onopen = () => { this.open = true; this.send({ t: 'auth', token: this.token }); };
      ws.onerror = () => fail(new Error('connection error'));
      ws.onclose = ev => { this.open = false; clearInterval(this._ping); clearTimeout(to); if (!settled) fail(new Error('closed')); else if (this.h.close) this.h.close(ev); };
      ws.onmessage = ev => {
        let d; try { d = JSON.parse(ev.data); } catch (e) { return; }
        if (d.t === 'hello' && !settled) { settled = true; clearTimeout(to); this._ping = setInterval(() => this.send({ t: 'ping', ts: performance.now() }), 4000); resolve(d); }
        else if (d.t === 'err' && !settled) { fail(new Error(d.msg || 'rejected')); }
        else if (d.t === 'pong') this.rtt = Math.round(performance.now() - d.ts);
        if (this.h[d.t]) this.h[d.t](d);
      };
    });
  }
  send(o) { if (this.open && this.ws.readyState === 1) this.ws.send(JSON.stringify(o)); }
  close() { try { this.ws && this.ws.close(); } catch (e) {} }
}
